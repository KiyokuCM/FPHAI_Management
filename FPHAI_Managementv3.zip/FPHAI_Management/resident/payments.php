<?php
require_once __DIR__ . '/../config/database.php'; require_once __DIR__ . '/../includes/auth.php'; require_once __DIR__ . '/../includes/functions.php';
require_role('Resident'); $pageTitle='My Payments';
$stmt=$pdo->prepare('SELECT homeowner_id,household_name FROM homeowners WHERE user_id=:uid LIMIT 1');$stmt->execute(['uid'=>current_user_id()]);$home=$stmt->fetch();
$payments=[]; $total=0;
if($home){
 $stmt=$pdo->prepare('SELECT p.payment_date,p.si_number,p.amount,p.payment_method,p.reference_number,p.description,p.proof_image_path,p.status,p.created_at,"Regular Payment" AS source_label,p.payment_id AS source_id FROM payments p WHERE p.homeowner_id=:hid
 UNION ALL
 SELECT rp.payment_date,rp.si_number,rp.amount,rp.payment_method,rp.reference_number,CONCAT("Facility Reservation #",rp.reservation_id," — Reservation Payment") AS description,rp.proof_image_path,CASE WHEN r.status="Cancelled" THEN "Cancelled" WHEN r.status="Rejected" THEN "Rejected" ELSE rp.status END AS status,rp.created_at,"Reservation Payment" AS source_label,rp.reservation_payment_id AS source_id FROM reservation_payments rp INNER JOIN reservations r ON r.reservation_id=rp.reservation_id WHERE rp.homeowner_id=:hid2
 ORDER BY payment_date DESC');
 $stmt->execute(['hid'=>$home['homeowner_id'],'hid2'=>$home['homeowner_id']]); $payments=$stmt->fetchAll();
 foreach($payments as $p){if($p['status']==='Validated')$total+=(float)$p['amount'];}
}
$availableYears=[]; foreach($payments as $p){$y=(int)date('Y',strtotime($p['payment_date']));$availableYears[$y]=true;} $currentYear=(int)date('Y'); $availableYears[$currentYear]=true; $availableYears=array_keys($availableYears); rsort($availableYears); $selectedYear=(int)($_GET['year']??$currentYear); if(!in_array($selectedYear,$availableYears,true))$selectedYear=$currentYear; $displayPayments=array_values(array_filter($payments,fn($p)=>(int)date('Y',strtotime($p['payment_date']))===$selectedYear));

require __DIR__.'/../includes/header.php';$flash=get_flash();
?>
<?php if($flash):?><div class="alert alert-<?=e($flash['type'])?>"><?=e($flash['message'])?></div><?php endif;?>
<section class="section-card"><div class="section-heading"><div><span class="section-kicker">Private Records</span><h2>My Payment Records</h2></div><button type="button" class="qr-tool-button" data-open-receipt-qr title="Scan Receipt QR" aria-label="Scan Receipt QR">⌗ <span>Scan Receipt QR</span></button></div>
<div class="record-search-bar"><div class="form-group"><label for="resident-payment-year">Year</label><select id="resident-payment-year" onchange="window.location.href='payments.php?year='+this.value"><option value="all">Present year</option><?php foreach($availableYears as $yr): ?><option value="<?=e((string)$yr)?>" <?=($selectedYear===$yr)?'selected':''?>><?=e((string)$yr)?></option><?php endforeach; ?></select></div><div class="form-group"><label for="resident-payment-search">Search My Payments</label><input id="resident-payment-search" type="search" placeholder="Search date, SI number, method, reference, description, amount, or status…" autocomplete="off"></div></div>
<?php foreach([['Regular Payment','Collections Payments'],['Reservation Payment','Reservation Payments']] as $section): $sectionRows=array_values(array_filter($displayPayments,fn($p)=>$p['source_label']===$section[0])); ?>
<div class="payment-history-section"><div class="section-heading compact"><div><h3><?=e($section[1])?></h3><p><?=e($section[0]==='Regular Payment'?'':'')?></p></div></div><div class="data-table-wrap"><table class="data-table resident-payment-subtable"><thead><tr><th>Date</th><th>SI Number</th><th>Amount</th><th>Method</th><th>Reference</th><th>Description</th><th>Proof</th><th>Status</th><th>Details</th></tr></thead><tbody>
<?php foreach($sectionRows as $p): $proofUrl=($p['source_label']==='Reservation Payment'?'../reservation_payment_proof_download.php':'../payment_proof_download.php'); $detail=['Date'=>$p['payment_date'],'Record Type'=>$p['source_label'],'SI Number'=>$p['si_number'],'Amount'=>'₱'.number_format((float)$p['amount'],2),'Payment Method'=>$p['payment_method'],'Reference'=>$p['reference_number']?:'—','Description'=>$p['description']?:'—','Status'=>$p['status'],'Recorded At'=>$p['created_at']?:'—']; ?><tr class="clickable-record-row" data-payment-search="<?=e(strtolower(implode(' ',array_map('strval',$detail))))?>" data-payment-detail="<?=e(json_encode($detail,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES))?>" data-receipt-type="<?= $p['source_label']==='Reservation Payment' ? 'reservation' : 'collection' ?>" data-receipt-id="<?= (int)$p['source_id'] ?>"><td><?=e($p['payment_date'])?></td><td><?=e($p['si_number'])?></td><td>₱<?=number_format((float)$p['amount'],2)?></td><td><?=e($p['payment_method'])?></td><td><?=e($p['reference_number']?:'—')?></td><td class="table-description"><?=e($p['description']?:'—')?></td><td><?php if(!empty($p['proof_image_path'])): ?><a class="btn btn-secondary btn-small payment-proof-link" target="_blank" href="<?=e($proofUrl)?>?id=<?= (int)$p['source_id'] ?>">View proof</a><?php else: ?><span class="form-note">—</span><?php endif; ?></td><td><span class="status-pill <?=e(status_class($p['status']))?>"><?=e($p['status'])?></span></td><td><button type="button" class="btn btn-secondary btn-small resident-payment-details-button">View Details</button></td></tr><?php endforeach; ?><?php if(!$sectionRows):?><tr><td colspan="9" class="empty-state">No <?=e(strtolower($section[1]))?> have been recorded.</td></tr><?php endif;?></tbody></table></div></div>
<?php endforeach; ?></section><div id="resident-payment-detail-modal" class="record-detail-overlay" aria-hidden="true" hidden><div class="record-detail-modal" role="dialog" aria-modal="true" aria-labelledby="resident-payment-detail-title"><div class="section-heading"><div><span class="section-kicker">Private Transaction</span><h2 id="resident-payment-detail-title">Payment Details</h2></div><button type="button" class="btn btn-secondary btn-small" id="close-resident-payment-detail">Close</button></div><div class="receipt-detail-layout"><div id="resident-payment-detail-grid" class="record-detail-grid"></div><aside class="receipt-preview-panel"><h3>Receipt Verification QR</h3><div id="resident-receipt-qr" class="receipt-qr-canvas" aria-label="Receipt verification QR code"></div><p class="form-note"></p><a id="resident-receipt-verify-link" class="btn btn-secondary btn-small" href="#" target="_blank" rel="noopener">Open Verification</a><button type="button" class="btn btn-primary btn-small" onclick="window.print()">Print Receipt</button></aside></div></div></div>
<script>
(function(){
 const init=function(){
  const input=document.getElementById('resident-payment-search');
  const tables=Array.from(document.querySelectorAll('.resident-payment-subtable'));
  const modal=document.getElementById('resident-payment-detail-modal');
  const grid=document.getElementById('resident-payment-detail-grid');
  const close=document.getElementById('close-resident-payment-detail');
  const qrBox=document.getElementById('resident-receipt-qr');const verifyLink=document.getElementById('resident-receipt-verify-link');
  if(!tables.length || !modal || !grid) return;
  const rows=tables.flatMap(t=>Array.from(t.querySelectorAll('tbody tr.clickable-record-row')));
  const escapeHtml=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const openRow=row=>{
   try{
    const data=JSON.parse(row.dataset.paymentDetail||'{}');
    grid.innerHTML=Object.entries(data).map(([k,v])=>`<div><span>${escapeHtml(k)}</span><strong>${escapeHtml(v)}</strong></div>`).join('');
    const url=new URL('../receipt-verify.php',window.location.href);url.searchParams.set('type',row.dataset.receiptType||'collection');url.searchParams.set('id',row.dataset.receiptId||'0');if(verifyLink)verifyLink.href=url.href;if(qrBox){qrBox.innerHTML='';if(window.QRCode){new QRCode(qrBox,{text:url.href,width:180,height:180,colorDark:'#10271b',colorLight:'#ffffff',correctLevel:QRCode.CorrectLevel.M});}else{qrBox.textContent='QR generator unavailable. Use Open Verification.';}}
    modal.removeAttribute('hidden');
    modal.classList.add('is-visible');
    modal.setAttribute('aria-hidden','false');
    document.body.classList.add('modal-open');
   }catch(e){ console.error('Unable to open payment details.',e); }
  };
  const closeModal=()=>{
   modal.classList.remove('is-visible');
   modal.setAttribute('hidden','hidden');
   modal.setAttribute('aria-hidden','true');
   document.body.classList.remove('modal-open');
  };
  if(input) input.addEventListener('input',function(){const q=this.value.trim().toLowerCase();rows.forEach(r=>{r.hidden=!!q && !(r.dataset.paymentSearch||'').includes(q);});});
  rows.forEach(row=>{
   row.tabIndex=0;
   row.addEventListener('click',e=>{ if(e.target.closest('a,button,input,select')) return; openRow(row); });
   row.addEventListener('keydown',e=>{ if((e.key==='Enter'||e.key===' ') && !e.target.closest('a,button,input,select')){e.preventDefault();openRow(row);} });
   const btn=row.querySelector('.resident-payment-details-button');
   if(btn) btn.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();openRow(row);});
  });
  if(close) close.addEventListener('click',closeModal);
  modal.addEventListener('click',e=>{if(e.target===modal)closeModal();});
  document.addEventListener('keydown',e=>{if(e.key==='Escape' && !modal.hasAttribute('hidden')) closeModal();});
 };
 if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init,{once:true}); else init();
})();
</script>
<?php require __DIR__.'/../includes/footer.php'; ?>


