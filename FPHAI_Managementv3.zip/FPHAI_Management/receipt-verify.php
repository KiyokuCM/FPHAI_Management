<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';
require_login();
$type=(string)($_GET['type']??''); $id=(int)($_GET['id']??0); if($id<1||!in_array($type,['collection','reservation'],true)){http_response_code(400);exit('Invalid receipt QR.');}
if($type==='collection'){
 $sql='SELECT p.payment_id AS id,p.homeowner_id,p.si_number,p.payment_date,p.amount,p.payment_method,p.reference_number,p.description,p.status,h.household_name,h.address,h.street,h.block,h.lot FROM payments p JOIN homeowners h ON h.homeowner_id=p.homeowner_id WHERE p.payment_id=:id';
}else{
 $sql='SELECT rp.reservation_payment_id AS id,rp.homeowner_id,rp.reservation_id,rp.si_number,rp.payment_date,rp.amount,rp.payment_method,rp.reference_number,rp.status,r.facility,r.reservation_date,r.start_time,r.end_time,r.requester_name,r.requester_type,r.status AS reservation_status,h.household_name,h.address,h.street,h.block,h.lot FROM reservation_payments rp JOIN reservations r ON r.reservation_id=rp.reservation_id LEFT JOIN homeowners h ON h.homeowner_id=rp.homeowner_id WHERE rp.reservation_payment_id=:id';
}
$stmt=$pdo->prepare($sql);$stmt->execute(['id'=>$id]);$row=$stmt->fetch();
// A rejected/cancelled reservation must not appear as Pending just because its linked payment row was never updated.
if ($row && $type === 'reservation' && in_array((string)($row['reservation_status'] ?? ''), ['Rejected','Cancelled'], true)) { $row['status'] = (string)$row['reservation_status']; }
if(!$row){http_response_code(404);exit('This receipt is not recorded in FPHAI.');}
$role=(string)($_SESSION['role']??'');$uid=current_user_id();
if($role==='Resident'){$hs=$pdo->prepare('SELECT homeowner_id FROM homeowners WHERE user_id=:uid LIMIT 1');$hs->execute(['uid'=>$uid]);$hid=(int)$hs->fetchColumn();if(!$hid||empty($row['homeowner_id'])||(int)$row['homeowner_id']!==$hid){http_response_code(403);exit('This receipt does not belong to your account.');}}
if($role==='Clerk'||$role==='Administrator'){}else if($role!=='Resident'){http_response_code(403);exit('Access denied.');}
$pageTitle='Receipt Verification';require __DIR__.'/includes/header.php';
?>
<section class="section-card"><div class="section-heading"><div><span class="section-kicker">Receipt Verification</span><h2><?=e($row['si_number'])?></h2><p>This receipt record was found in the FPHAI system.</p></div><span class="status-pill <?=e(status_class($row['status']))?>"><?=e($row['status'])?></span></div><div class="record-detail-grid">
<?php foreach($row as $key=>$value): if(in_array($key,['id','homeowner_id'],true)||$value===null||$value==='')continue; ?><div><span><?=e(ucwords(str_replace('_',' ',$key)))?></span><strong><?=e((string)$value)?></strong></div><?php endforeach; ?></div><div class="qr-modal-actions" style="margin-top:18px"><button class="btn btn-primary" type="button" onclick="window.print()">Print Receipt Details</button><a class="btn btn-secondary" href="<?=e((function(){ $role=(string)($_SESSION['role']??''); $type=(string)($_GET['type']??''); $route=($type==='reservation'?'reservations.php':($role==='Resident'?'payments.php':'collections.php')); $fallback=APP_URL.'/'.($role==='Administrator'?'admin':($role==='Clerk'?'clerk':'resident')).'/'.$route; $ref=(string)($_GET['return']??''); $allowed=['admin/collections.php','admin/reservations.php','clerk/payments.php','clerk/reservations.php','resident/payments.php','resident/reservations.php']; $ref=ltrim(str_replace('\\','/',$ref),'/'); return in_array($ref,$allowed,true) ? APP_URL.'/'.$ref : $fallback; })())?>">Return</a></div></section>
<?php require __DIR__.'/includes/footer.php'; ?>
