<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';
require_login();
$provider=strtolower((string)($_GET['provider']??''));
$key=$provider==='gcash'?'gcash_qr_path':($provider==='maya'?'maya_qr_path':'online_payment_qr_path');
$stmt=$pdo->prepare('SELECT setting_value FROM app_settings WHERE setting_key=:key LIMIT 1');$stmt->execute(['key'=>$key]);$path=(string)$stmt->fetchColumn();
if(!$path && $provider==='gcash'){$stmt->execute(['key'=>'online_payment_qr_path']);$path=(string)$stmt->fetchColumn();}
if(!$path || !preg_match('#^payment-qr/[a-f0-9]{32}\.(jpg|png|webp)$#',$path)){http_response_code(404);exit('No payment QR configured.');}
$file=UPLOAD_DIR.$path;if(!is_file($file)){http_response_code(404);exit('Payment QR image not found.');}
$mime=(new finfo(FILEINFO_MIME_TYPE))->file($file);if(!in_array($mime,['image/jpeg','image/png','image/webp'],true)){http_response_code(404);exit;}
header('Content-Type: '.$mime);header('Content-Length: '.filesize($file));header('Cache-Control: private, max-age=60');readfile($file);
