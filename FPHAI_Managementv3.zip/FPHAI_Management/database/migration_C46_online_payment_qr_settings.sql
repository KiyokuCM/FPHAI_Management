-- C46: separate wallet QR images and configurable payment contact; preserves existing legacy QR as GCash fallback.
INSERT INTO app_settings(setting_key,setting_value) VALUES
('gcash_qr_path',NULL),('maya_qr_path',NULL),('payment_contact','09958601337')
ON DUPLICATE KEY UPDATE setting_key=VALUES(setting_key);
