-- FPHAI C43 migration. Back up the database before applying.
-- Existing address values are migrated to Lot only where Lot is blank; existing Lot data is preserved.
ALTER TABLE homeowners MODIFY lot VARCHAR(100) NULL;
UPDATE homeowners SET lot = NULLIF(TRIM(address), '') WHERE (lot IS NULL OR TRIM(lot) = '') AND address IS NOT NULL AND TRIM(address) <> '';
UPDATE homeowners SET address = '' WHERE address IS NOT NULL;
INSERT INTO app_settings(setting_key,setting_value) VALUES ('monthly_due_amount','400.00') ON DUPLICATE KEY UPDATE setting_key=VALUES(setting_key);
