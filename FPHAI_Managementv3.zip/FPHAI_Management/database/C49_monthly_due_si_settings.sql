-- Run after backing up the database. Adds defaults for SI behavior.
INSERT INTO app_settings (setting_key, setting_value) VALUES
 ('monthly_due_allow_duplicate_si','0'),
 ('monthly_due_auto_generate_si','0')
ON DUPLICATE KEY UPDATE setting_key=VALUES(setting_key);
-- The application toggles the payments.si_number unique index when the
-- administrator changes the duplicate-SI setting. Existing duplicates must
-- be resolved before turning duplicate SI numbers back off.
