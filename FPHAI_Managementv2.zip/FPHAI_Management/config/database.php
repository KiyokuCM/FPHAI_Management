<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

/*
 * MySQL connection.
 * Change these values to match the local XAMPP/WAMP MySQL setup.
 */
$dbHost = '127.0.0.1';
$dbName = 'u201025533_fairmontfphai';
$dbUser = 'u201025533_fairmontfphai';
$dbPass = 'fairmontfphaiSystem1';

$dsn = "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    // Keep native prepared statements enabled. Search queries use unique placeholders.
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $dbUser, $dbPass, $options);
    // Keep MySQL NOW(), DATE_ADD(), and DATETIME comparisons aligned with the
    // application's Philippine time zone. This prevents temporary passwords and
    // 2FA challenges from appearing to expire hours early on hosted servers.
    $pdo->exec("SET time_zone = '+08:00'");
} catch (PDOException $exception) {
    http_response_code(500);
    exit(
        'Database connection failed. Check config/database.php and make sure MySQL is running.'
    );
}
