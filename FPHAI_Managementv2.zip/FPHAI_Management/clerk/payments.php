<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('Clerk');

$pageTitle = 'Payments';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request token. Please try again.';
    } else {
        try {
            $homeownerId = (int)($_POST['homeowner_id'] ?? 0);
            $siNumber = trim($_POST['si_number'] ?? '');
            $paymentDate = $_POST['payment_date'] ?? '';
            $amount = $_POST['amount'] ?? '';
            $method = $_POST['payment_method'] ?? '';
            $reference = trim($_POST['reference_number'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $proofPath = null;
            if (in_array($method, ['Bank Transfer','Cheque'], true) && !empty($_FILES['proof_image']['name'])) {
                $proofPath = save_uploaded_payment_proof($_FILES['proof_image']);
            }

            if ($homeownerId < 1 || $siNumber === '' || $paymentDate === '' || $amount === '' || !in_array($method, ['Cash','Bank Transfer','Cheque'], true)) {
                throw new RuntimeException('Please complete the required payment information.');
            }

            if (!preg_match('/^\d+$/', $siNumber)) {
                throw new RuntimeException('SI Number must contain numbers only.');
            }

            if (!preg_match('/^\d+$/', trim((string)$amount))) {
                throw new RuntimeException('Payment amount must be a whole peso amount with no decimals.');
            }
            $amountInt = (int)$amount;
            if ($amountInt < 400 || $amountInt % 400 !== 0) {
                throw new RuntimeException('For regular homeowner dues, the amount must be ₱400 for one month, ₱800 for two months, ₱1,200 for three months, and so on. Amounts such as ₱450, ₱600, or ₱700 are not accepted.');
            }

            $stmt = $pdo->prepare(
                'INSERT INTO payments
                 (homeowner_id,si_number,payment_date,amount,payment_method,reference_number,description,proof_image_path,status,encoded_by)
                 VALUES (:homeowner_id,:si_number,:payment_date,:amount,:payment_method,:reference_number,:description,:proof_image_path,"Pending",:encoded_by)'
            );
            $stmt->execute([
                'homeowner_id'=>$homeownerId,
                'si_number'=>$siNumber,
                'payment_date'=>$paymentDate,
                'amount'=>$amountInt,
                'payment_method'=>$method,
                'reference_number'=>$reference ?: null,
                'description'=>$description ?: null,
                'proof_image_path'=>$proofPath,
                'encoded_by'=>current_user_id()
            ]);

            $id = (int)$pdo->lastInsertId();
            audit_log($pdo, current_user_id(), 'Created', 'Payments', $id, 'Encoded payment for Administrator validation.');
            $homeownerNameStmt = $pdo->prepare('SELECT household_name FROM homeowners WHERE homeowner_id=:id LIMIT 1');
            $homeownerNameStmt->execute(['id'=>$homeownerId]);
            $homeownerName = (string)$homeownerNameStmt->fetchColumn();
            notify_staff($pdo, 'Awaiting Collection Validation', ($homeownerName !== '' ? $homeownerName.' submitted ' : 'A collection payment was submitted. ').'payment SI '.$siNumber.' for Administrator validation.', 'Info', 'Collections', $id);
            flash('success', 'Payment encoded and submitted for Administrator validation.');
            header('Location: payments.php');
            exit;
        } catch (PDOException $ex) {
            $error = $ex->errorInfo[1] === 1062 ? 'That SI number already exists.' : 'The payment could not be saved.';
        } catch (RuntimeException $ex) {
            $error = $ex->getMessage();
        }
    }
}

$streetBlocks = [
    'Adrian Street'=>[], 'Banning Street'=>['39','40'], 'Bronx Street'=>['34','40','41','46'],
    'Burney Street'=>['48','50','53'], 'Badger Street'=>['44','50'], 'Boles Street'=>['45','53'],
    'Bryant Street'=>['49','50','51'], 'Butler Street'=>['33','34'], 'Bremen Street'=>['34','39','40'],
    'Bronson Street'=>['45','46','47','48','49','51','53'], 'Burke Street'=>['48','49'], 'Baker Street'=>['38'],
    'Byron Street'=>['45','48'], 'Bonner Street'=>['41','44','50','53']
];
$streetOptions = array_keys($streetBlocks);
$streetFilter = trim($_GET['street'] ?? '');
if ($streetFilter !== '' && !array_key_exists($streetFilter, $streetBlocks)) $streetFilter = '';
$streetCounts = array_fill_keys($streetOptions, 0);
$streetCountStmt = $pdo->query('SELECT street, COUNT(*) AS total FROM homeowners WHERE membership_status <> "Inactive" GROUP BY street');
foreach ($streetCountStmt->fetchAll() as $row) {
    $street = (string)($row['street'] ?? '');
    if (isset($streetCounts[$street])) $streetCounts[$street] = (int)$row['total'];
}

$homeownerSql = 'SELECT homeowner_id, household_name, address, street, block
                 FROM homeowners
                 WHERE membership_status <> "Inactive"';
$homeownerParams = [];
$homeownerSql .= ' ORDER BY street, block, household_name';
$homeownerStmt = $pdo->prepare($homeownerSql);
$homeownerStmt->execute($homeownerParams);
$homeowners = $homeownerStmt->fetchAll();

$homeownersByBlock = [];
foreach ($homeowners as $h) {
    $blockLabel = trim((string)($h['block'] ?? ''));
    if ($blockLabel === '') $blockLabel = 'No Block';
    $groupKey = ($streetFilter !== '' ? $streetFilter : ((string)($h['street'] ?? '') ?: 'Unassigned Street')) . ' — ' . $blockLabel;
    $homeownersByBlock[$groupKey][] = $h;
}


$payments = $pdo->query(
    'SELECT p.*, h.household_name, u.username AS encoded_username
     FROM payments p
     JOIN homeowners h ON h.homeowner_id=p.homeowner_id
     LEFT JOIN users u ON u.user_id=p.encoded_by
     ORDER BY p.payment_date DESC, p.payment_id DESC
     LIMIT 100'
)->fetchAll();

require __DIR__ . '/../includes/header.php';
$flash = get_flash();
?>
<?php if ($flash): ?><div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>

<details class="section-card foldable-panel">
    <summary><span><strong>Encode Payment</strong><small>Open this section when you need to record a payment.</small></span><span class="fold-chevron">⌄</span></summary>
    <div class="foldable-content">
    <h2>Encode Payment</h2>
    <p class="form-note">Encoded payments remain Pending until reviewed by the Administrator.</p>

    <form method="POST" class="form-grid" enctype="multipart/form-data">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">

        <div class="form-group full homeowner-picker">
            <label for="homeowner_search">Search Homeowner</label>
            <input id="homeowner_search" type="search" placeholder="Search household name, address, street, or block..." autocomplete="off">
            <p class="form-note">Select a street below to narrow the list. Homeowners are grouped by block for easier identification.</p>
            <div class="street-count-panel payment-street-filter">
                <div class="street-count-heading"><strong>Homeowners by Street</strong><span><?= $streetFilter !== '' ? 'Showing: '.e($streetFilter) : 'Select a street to filter' ?></span></div>
                <div class="street-count-grid" role="list" aria-label="Homeowners by Street">
                    <?php foreach ($streetOptions as $streetOption): $isSelected = $streetFilter === $streetOption; $streetHref = $isSelected ? 'payments.php' : 'payments.php?street='.rawurlencode($streetOption); ?>
                        <a class="street-count-item payment-street-choice <?= $isSelected ? 'is-selected' : '' ?>" href="<?= e($streetHref) ?>" data-street="<?= e($streetOption) ?>" role="listitem" aria-pressed="<?= $isSelected ? 'true' : 'false' ?>"><span><?= e($streetOption) ?></span><strong><?= number_format($streetCounts[$streetOption] ?? 0) ?></strong></a>
                    <?php endforeach; ?>
                </div>
            </div>
            <label for="homeowner_id">Selected Homeowner</label>
            <select id="homeowner_id" name="homeowner_id" size="8" required>
                <?php foreach ($homeownersByBlock as $groupLabel => $groupHomeowners): ?>
                    <optgroup label="<?= e($groupLabel) ?>">
                    <?php foreach ($groupHomeowners as $h): ?>
                        <option value="<?= (int)$h['homeowner_id'] ?>" data-household="<?= e($h['household_name']) ?>" data-street="<?= e($h['street'] ?? '') ?>" data-block="<?= e($h['block'] ?? '') ?>" data-search="<?= e(strtolower($h['household_name'].' '.$h['address'].' '.($h['street'] ?? '').' '.($h['block'] ?? ''))) ?>">
                            <?= e($h['household_name']) ?> — <?= e($h['address'].' '.($h['street'] ?? '')) ?><?= !empty($h['block']) ? ' — Block '.e($h['block']) : '' ?>
                        </option>
                    <?php endforeach; ?>
                    </optgroup>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="si_number">SI Number</label>
            <input id="si_number" name="si_number" type="text" inputmode="numeric" pattern="[0-9]+" maxlength="100" autocomplete="off" required>
        </div>

        <div class="form-group">
            <label for="payment_date">Payment Date</label>
            <input id="payment_date" name="payment_date" type="date" value="<?= e(date('Y-m-d')) ?>" required>
        </div>

        <div class="form-group">
            <label for="amount">Amount</label>
            <input id="amount" name="amount" type="number" min="400" step="400" required>
        </div>

        <div class="form-group full">
            <div class="payment-coverage-panel" id="payment-coverage-panel">
                <strong>Monthly Due Coverage</strong>
                <span id="payment-coverage-text">Select a homeowner and enter the payment amount to preview the credited months.</span><strong id="payment-coverage-due" style="display:none;">Projected next due date: <span id="payment-coverage-due-value"></span></strong>
            </div>
        </div>

        <div class="form-group">
            <label for="payment_method">Payment Method</label>
            <select id="payment_method" name="payment_method" required>
                <?php foreach (['Cash','Bank Transfer','Cheque'] as $method): ?>
                    <option value="<?= e($method) ?>"><?= e($method) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="reference_number">Reference Number</label>
            <input id="reference_number" name="reference_number" type="text" maxlength="150">
            
        </div>

        <div class="form-group proof-image-field" id="proof-image-field" style="display:none;">
            <label for="proof_image">Proof of Payment Image</label>
            <input id="proof_image" name="proof_image" type="file" accept="image/jpeg,image/png,image/webp">
            <p class="form-note">Optional for Bank Transfer and Cheque. JPG, PNG, or WEBP, up to 25 MB.</p>
        </div>

        <div class="form-group full">
            <label for="description">Transaction Description</label>
            <textarea id="description" name="description" rows="3" maxlength="120"></textarea>
        </div>

        <div class="full">
            <button class="btn btn-primary" type="submit">Save Payment</button>
        </div>
    </form>
    </div>
</details>

<section class="section-card" style="margin-top:22px;">
    <h2>Recent Encoded Payments</h2>
    <div class="data-table-wrap">
        <table class="data-table">
            <thead><tr><th>Date</th><th>Homeowner</th><th>SI Number</th><th>Amount</th><th>Method</th><th>Transaction Description</th><th>Proof</th><th>Status</th></tr></thead>
            <tbody>
            <?php foreach ($payments as $p): ?>
                <?php $paymentDetail = [
                        'Payment Date' => $p['payment_date'],
                        'Homeowner' => $p['household_name'],
                        'SI Number' => $p['si_number'],
                        'Amount' => '₱'.number_format((float)$p['amount'], 2),
                        'Payment Method' => $p['payment_method'],
                        'Reference Number' => $p['reference_number'] ?: '—',
                        'Transaction Description' => $p['description'] ?: '—',
                        'Status' => $p['status'],
                        'Encoded By' => $p['encoded_username'] ?? '—',
                        'Created At' => $p['created_at'] ?? '—',
                    ]; ?>
                <tr class="interactive-data-row" tabindex="0" data-payment-details="<?= e(json_encode($paymentDetail, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) ?>">
                    <td><?= e($p['payment_date']) ?></td>
                    <td><?= e($p['household_name']) ?></td>
                    <td><?= e($p['si_number']) ?></td>
                    <td>₱<?= number_format((float)$p['amount'],2) ?></td>
                    <td><?= e($p['payment_method']) ?></td>
                    <td class="table-description" title="<?= e($p['description'] ?? '') ?>"><?= e(mb_strimwidth($p['description'] ?? '—', 0, 72, '…', 'UTF-8')) ?></td>
                    <td><?= !empty($p['proof_image_path']) ? '<a class="btn btn-secondary btn-small" target="_blank" href="../payment_proof_download.php?id='.(int)$p['payment_id'].'">View proof</a>' : '<span class="form-note">—</span>' ?></td>
                    <td><span class="status-pill <?= e(status_class($p['status'])) ?>"><?= e($p['status']) ?></span></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$payments): ?><tr><td colspan="8" class="empty-state">No payment records found.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</section>

<div class="record-detail-overlay" id="payment-detail-overlay" aria-hidden="true">
  <div class="record-detail-modal" role="dialog" aria-modal="true" aria-labelledby="payment-detail-title">
    <button type="button" class="record-detail-close" aria-label="Close" onclick="closePaymentDetail()">×</button>
    <h2 id="payment-detail-title">Payment Details</h2>
    <div id="payment-detail-content" class="record-detail-grid"></div>
  </div>
</div>
<script>
(function(){
 const overlay=document.getElementById('payment-detail-overlay'), content=document.getElementById('payment-detail-content');
 function open(row){
   try{ const data=JSON.parse(row.dataset.paymentDetails||'{}'); content.innerHTML=Object.entries(data).map(([k,v])=>'<div><span>'+escapeHtml(k)+'</span><strong>'+escapeHtml(String(v))+'</strong></div>').join(''); overlay.classList.add('is-visible'); overlay.setAttribute('aria-hidden','false'); }catch(e){}
 }
 function escapeHtml(v){return v.replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c]));}
 window.closePaymentDetail=function(){overlay.classList.remove('is-visible');overlay.setAttribute('aria-hidden','true');};
 document.addEventListener('click',e=>{const row=e.target.closest('.interactive-data-row'); if(!row || e.target.closest('a,button,form,input,select,textarea')) return; open(row);});
 document.addEventListener('keydown',e=>{const row=e.target.closest('.interactive-data-row'); if(row && (e.key==='Enter'||e.key===' ')){e.preventDefault();open(row);} if(e.key==='Escape') closePaymentDetail();});
 overlay.addEventListener('click',e=>{if(e.target===overlay) closePaymentDetail();});
})();
</script>

<script>
document.addEventListener('DOMContentLoaded', function(){
    const si = document.getElementById('si_number');
    if (!si) return;
    const digitsOnly = () => { si.value = si.value.replace(/\D/g, ''); };
    si.addEventListener('input', digitsOnly);
    si.addEventListener('paste', () => setTimeout(digitsOnly, 0));
});
</script>
<?php require __DIR__ . '/../includes/footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function(){
  const method=document.getElementById('payment_method');
  const proofWrap=document.getElementById('proof-image-field');
  const proofInput=document.getElementById('proof_image');
  const updateProof=()=>{ const show=method && ['Bank Transfer','Cheque'].includes(method.value); if(proofWrap) proofWrap.style.display=show?'block':'none'; if(proofInput) proofInput.required=false; };
  if(method){ method.addEventListener('change', updateProof); updateProof(); }
  const search=document.getElementById('homeowner_search');
  const select=document.getElementById('homeowner_id');
  const streetChoices=[...document.querySelectorAll('.payment-street-choice')];
  if(!search||!select)return;

  const allOptions=[...select.querySelectorAll('option')].map(o=>({
    value:o.value,
    text:o.textContent.trim(),
    household:o.dataset.household||o.textContent.trim().split(' — ')[0],
    search:o.dataset.search||o.textContent.toLowerCase(),
    street:o.dataset.street||'',
    block:o.dataset.block||'',
    group:o.parentElement?.tagName==='OPTGROUP'?o.parentElement.label:''
  }));
  let activeStreet=<?= json_encode($streetFilter) ?>;
  let selectedHomeownerValue='';

  const getSelectedItem=()=>allOptions.find(item=>item.value===selectedHomeownerValue)||null;

  const rebuild=()=>{
    const q=search.value.trim().toLowerCase();
    const matches=allOptions.filter(item=>(!activeStreet||item.street===activeStreet)&&(!q||item.search.includes(q)));
    const keepSelected=selectedHomeownerValue && matches.some(item=>item.value===selectedHomeownerValue);
    const groups=new Map();
    matches.forEach(item=>{if(!groups.has(item.group))groups.set(item.group,[]);groups.get(item.group).push(item);});

    select.innerHTML='';
    const placeholder=document.createElement('option');
    placeholder.value='';
    placeholder.textContent=matches.length?'Select a homeowner...':'No homeowners match this search.';
    placeholder.disabled=matches.length>0;
    placeholder.selected=!keepSelected;
    select.appendChild(placeholder);

    groups.forEach((items,label)=>{
      const og=document.createElement('optgroup');
      og.label=label;
      items.forEach(item=>{
        const o=document.createElement('option');
        o.value=item.value;
        o.textContent=item.text;
        o.dataset.household=item.household;
        o.dataset.search=item.search;
        o.dataset.street=item.street;
        o.dataset.block=item.block;
        o.selected=keepSelected&&item.value===selectedHomeownerValue;
        og.appendChild(o);
      });
      select.appendChild(og);
    });

    streetChoices.forEach(btn=>{
      const selectedStreet=btn.dataset.street===activeStreet;
      btn.classList.toggle('is-selected',selectedStreet);
      btn.setAttribute('aria-pressed',selectedStreet?'true':'false');
    });
  };

  const applyStreet=(street)=>{
    activeStreet=activeStreet===street?'':street;
    const selected=getSelectedItem();
    if(selected && activeStreet && selected.street!==activeStreet){
      selectedHomeownerValue='';
      search.value='';
    }
    rebuild();
    const activeButton=streetChoices.find(btn=>btn.dataset.street===activeStreet);
    const heading=activeButton?.closest('.payment-street-filter')?.querySelector('.street-count-heading span')
      ||document.querySelector('.payment-street-filter .street-count-heading span');
    if(heading)heading.textContent=activeStreet?'Showing: '+activeStreet:'Select a street to filter';
  };

  streetChoices.forEach(btn=>btn.addEventListener('click',e=>{
    e.preventDefault();
    applyStreet(btn.dataset.street||'');
  }));

  search.addEventListener('input',()=>{
    rebuild();
  });

  select.addEventListener('change',()=>{
    const o=select.options[select.selectedIndex];
    if(o && !o.disabled && o.value){
      selectedHomeownerValue=o.value;
      search.value=o.dataset.household||o.textContent.trim().split(' — ')[0];
    } else {
      selectedHomeownerValue='';
    }
    rebuild();
  });

  rebuild();
  const amount=document.getElementById('amount'), date=document.getElementById('payment_date'), coverage=document.getElementById('payment-coverage-text'), duePanel=document.getElementById('payment-coverage-due'), dueValue=document.getElementById('payment-coverage-due-value'), homeowner=document.getElementById('homeowner_id');
  let dueRequestTimer=null, dueRequestToken=0;
  function formatDueDate(value){ const d=new Date(value+'T00:00:00'); return d.toLocaleDateString('en-PH',{year:'numeric',month:'long',day:'numeric'}); }
  function updateCoverage(){
    if(!coverage||!amount||!date)return;
    const a=parseFloat(amount.value||'0');
    const months=Math.floor(a/400);
    if(duePanel){duePanel.style.display='none';}
    if(months<1){ coverage.textContent='Payments below ₱400 do not add a full monthly credit. Minimum monthly due: ₱400.'; return; }
    coverage.textContent=months+' month'+(months===1?'':'s')+' credited by this payment. Calculating the projected next due date using the resident\'s existing validated payment coverage…';
    clearTimeout(dueRequestTimer);
    dueRequestTimer=setTimeout(async()=>{
      const token=++dueRequestToken;
      if(!homeowner || !homeowner.value){ coverage.textContent=months+' month'+(months===1?'':'s')+' credited by this payment. Select a homeowner to calculate the projected next due date.'; return; }
      try{
        const url='payment_due_preview.php?homeowner_id='+encodeURIComponent(homeowner.value)+'&amount='+encodeURIComponent(a)+'&payment_date='+encodeURIComponent(date.value||new Date().toISOString().slice(0,10));
        const response=await fetch(url,{credentials:'same-origin',headers:{'Accept':'application/json'}});
        const data=await response.json();
        if(token!==dueRequestToken)return;
        if(!response.ok||data.error)throw new Error(data.error||'Unable to calculate the due date.');
        coverage.textContent=data.payment_credited_months+' month'+(data.payment_credited_months===1?'':'s')+' credited by this payment. Existing validated payments are included in the projection.';
        if(duePanel&&dueValue){ dueValue.textContent=formatDueDate(data.due_date); duePanel.style.display='block'; }
      }catch(err){
        if(token!==dueRequestToken)return;
        coverage.textContent=months+' month'+(months===1?'':'s')+' credited by this payment. The projected due date could not be calculated right now.';
      }
    },180);
  }
  ['input','change'].forEach(ev=>{if(amount)amount.addEventListener(ev,updateCoverage);if(date)date.addEventListener(ev,updateCoverage);if(homeowner)homeowner.addEventListener(ev,updateCoverage);}); updateCoverage();
});
</script>
