<?php
// Front page: always show the public About FPHAI page.
// Authenticated users can still access their role dashboard through the normal navigation.
header('Location: about.php?public=1');
exit;
