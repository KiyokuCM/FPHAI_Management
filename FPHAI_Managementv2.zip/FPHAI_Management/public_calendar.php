<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store, max-age=0');
$month=trim((string)($_GET['month']??date('Y-m')));
if(!preg_match('/^\d{4}-\d{2}$/',$month))$month=date('Y-m');
$start=$month.'-01';$end=(new DateTimeImmutable($start))->modify('+1 month')->format('Y-m-d');
$stmt=$pdo->prepare('SELECT facility,reservation_date,start_time,end_time,status,requester_type FROM reservations WHERE reservation_date>=:start AND reservation_date<:end AND status IN ("Pending","Approved","Completed") ORDER BY facility,reservation_date,start_time');
$stmt->execute(['start'=>$start,'end'=>$end]);
$data=['month'=>$month,'facilities'=>['Court 1'=>[],'Court 2'=>[]]];
foreach($stmt->fetchAll() as $r){$date=$r['reservation_date'];$data['facilities'][$r['facility']][$date][]=['start_time'=>$r['start_time'],'end_time'=>$r['end_time'],'status'=>$r['status'],'requester_type'=>$r['requester_type']];}
echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
