<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';
require_login();
$id=(int)($_GET['id']??0);
$stmt=$pdo->prepare('SELECT rp.proof_image_path,r.reservation_id,r.homeowner_id FROM reservation_payments rp INNER JOIN reservations r ON r.reservation_id=rp.reservation_id WHERE rp.reservation_payment_id=:id LIMIT 1');
$stmt->execute(['id'=>$id]); $row=$stmt->fetch();
if(!$row || empty($row['proof_image_path'])){http_response_code(404);exit('Not found');}
$role=current_role();
if($role==='Resident' && (int)$row['homeowner_id']!==(int)($_SESSION['homeowner_id']??0)){
    $h=$pdo->prepare('SELECT homeowner_id FROM homeowners WHERE user_id=:uid LIMIT 1');$h->execute(['uid'=>current_user_id()]);
    if((int)$h->fetchColumn()!==(int)$row['homeowner_id']){http_response_code(403);exit('Forbidden');}
}
$path=UPLOAD_DIR.$row['proof_image_path'];
if(!is_file($path)){http_response_code(404);exit('File not found');}
$finfo=new finfo(FILEINFO_MIME_TYPE);$mime=$finfo->file($path);if(!in_array($mime,['image/jpeg','image/png','image/webp'],true)){http_response_code(415);exit('Unsupported file');}
header('Content-Type: '.$mime);header('Content-Length: '.filesize($path));header('X-Content-Type-Options: nosniff');readfile($path);
