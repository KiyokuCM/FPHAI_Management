<?php
// LOCAL DEVELOPMENT ONLY.
// Delete or rename this file after creating the initial Administrator account.
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$message = '';
$error = '';

$count = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request token. Please refresh the page and try again.';
    } else {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';
        $email = trim($_POST['email'] ?? '');

        if ($username === '' || $password === '') {
            $error = 'Username and password are required.';
        } elseif ($email === '' || !validate_email_address($email)) {
            $error = 'Please enter a valid email address for the Administrator account.';
        } elseif (strlen($password) < 8) {
            $error = 'Password must contain at least 8 characters.';
        } elseif ($password !== $confirm) {
            $error = 'Passwords do not match.';
        } else {
            $stmt = $pdo->prepare('SELECT COUNT(*) FROM users WHERE username = :username');
            $stmt->execute(['username' => $username]);

            if ((int)$stmt->fetchColumn() > 0) {
                $error = 'That username already exists.';
            } else {
                // Local setup accounts start with 2FA disabled for easier first access.
                // Administrator can enable 2FA later from User Accounts.
                $stmt = $pdo->prepare(
                    'INSERT INTO users (username, email, mobile_number, two_factor_enabled, password_hash, role, status, account_source, must_change_password)
                     VALUES (:username, :email, NULL, 0, :password_hash, "Administrator", "Active", "Manual", 0)'
                );

                $stmt->execute([
                    'username' => $username,
                    'email' => $email,
                    'password_hash' => password_hash($password, PASSWORD_DEFAULT),
                ]);

                $message = 'Administrator account created with 2FA disabled. Delete setup_admin.php before using the system normally.';
                $count++;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Initial Administrator Setup | Fairmont Park HOA</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="login-page">
<main class="login-shell">
    <section class="login-card">
        <img src="assets/images/logo.png" alt="Fairmont Park HOA logo" class="login-logo">
        <h1>Initial Administrator Setup</h1>
        <p class="login-subtitle">Create the first Administrator account.</p>

        <?php if ($message): ?>
            <div class="alert alert-warning"><?= e($message) ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-error"><?= e($error) ?></div>
        <?php endif; ?>

        <?php if ($count > 0 && !$message): ?>
            <div class="alert alert-warning">
                An account already exists. Use the login page or create additional accounts from the Administrator module later.
            </div>
        <?php else: ?>
            <form method="POST" class="form-stack">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <div class="form-group">
                    <label for="username">Administrator Username</label>
                    <input id="username" name="username" type="text" maxlength="100" required>
                </div>
                <div class="form-group">
                    <label for="email">Administrator Email</label>
                    <input id="email" name="email" type="email" maxlength="190" autocomplete="email" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input id="password" name="password" type="password" minlength="8" required>
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input id="confirm_password" name="confirm_password" type="password" minlength="8" required>
                </div>
                <button class="btn btn-primary btn-large" type="submit">Create Administrator</button>
            </form>
        <?php endif; ?>

        <p class="login-footer"><a href="login.php">Return to Login</a></p>
    </section>
</main>
</body>
</html>
