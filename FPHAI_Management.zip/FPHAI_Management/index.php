<?php
session_start();

if (isset($_SESSION['user_id'], $_SESSION['role'])) {
    switch ($_SESSION['role']) {
        case 'Administrator':
            header('Location: admin/dashboard.php');
            break;
        case 'Clerk':
            header('Location: clerk/dashboard.php');
            break;
        case 'Resident':
            header('Location: resident/dashboard.php');
            break;
        default:
            header('Location: login.php');
    }
    exit;
}

header('Location: login.php');
exit;
