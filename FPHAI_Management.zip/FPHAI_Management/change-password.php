<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';
require_login();

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request token. Please try again.';
    } else {
        $currentPassword = $_POST['current_password'] ?? '';
        $password = $_POST['password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        $userStmt = $pdo->prepare('SELECT password_hash, username, role FROM users WHERE user_id=:user_id LIMIT 1');
        $userStmt->execute(['user_id'=>current_user_id()]);
        $currentUser = $userStmt->fetch();

        if (!$currentUser || !password_verify($currentPassword, $currentUser['password_hash'])) {
            $error = 'Your current password is incorrect.';
        } elseif (strlen($password) < 8) {
            $error = 'Password must contain at least 8 characters.';
        } elseif ($password !== $confirm) {
            $error = 'Passwords do not match.';
        } else {
            $stmt = $pdo->prepare(
                'UPDATE users SET password_hash=:password_hash, must_change_password=0, temporary_password_expires_at=NULL, status="Active" WHERE user_id=:user_id'
            );
            $stmt->execute([
                'password_hash' => password_hash($password, PASSWORD_DEFAULT),
                'user_id' => current_user_id(),
            ]);
            audit_log($pdo, current_user_id(), 'Changed Password', 'Authentication', current_user_id(), 'Completed required password change.');
            notify_staff($pdo, 'Resident account password changed', 'Resident account '.($currentUser['username'] ?? current_username()).' has completed the required password change and is now using a new password.', 'Success', 'User Accounts', current_user_id());
            flash('success', 'Password changed successfully. Your Resident account is now active with your new password.');
            redirect_by_role();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password | Fairmont Park HOA</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="login-page">
<main class="login-shell first-login-password-shell">
    <section class="login-card first-login-password-modal">
        <img src="assets/images/logo.png" alt="Fairmont Park HOA logo" class="login-logo">
        <h1>Set Your New Password</h1>
        <p class="login-subtitle">For security, enter your temporary/current password first, then create your new password. Your HOA office will be notified after the change.</p>
        <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
        <form method="POST" class="form-stack" autocomplete="off">
            <div class="form-group">
                <label for="current_password">Current / Temporary Password</label>
                <input id="current_password" name="current_password" type="password" minlength="8" required autocomplete="current-password">
            </div>
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <div class="form-group">
                <label for="password">New Password</label>
                <input id="password" name="password" type="password" minlength="8" required autocomplete="new-password">
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirm New Password</label>
                <input id="confirm_password" name="confirm_password" type="password" minlength="8" required autocomplete="new-password">
            </div>
            <button class="btn btn-primary btn-large" type="submit">Save New Password</button>
        </form>
    </section>
</main>
</body>
</html>
