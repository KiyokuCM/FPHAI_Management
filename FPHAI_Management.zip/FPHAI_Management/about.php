<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

$loggedIn = is_logged_in();
$canEdit = $loggedIn && in_array(current_role(), ['Administrator', 'Clerk'], true);
$canDownloadAboutImages = $loggedIn && in_array(current_role(), ['Administrator', 'Clerk'], true);
$error = '';

// Keep the About page usable on databases that were created before the About module migration was imported.
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS about_content (
        about_id TINYINT UNSIGNED PRIMARY KEY,
        title VARCHAR(200) NOT NULL,
        body TEXT NOT NULL,
        gallery_mode ENUM('slideshow','album','collage') NOT NULL DEFAULT 'album',
        updated_by INT UNSIGNED NULL,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        CONSTRAINT fk_about_updated_by FOREIGN KEY (updated_by) REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
    ) ENGINE=InnoDB");
    $pdo->exec("CREATE TABLE IF NOT EXISTS login_slides (
        slide_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(200) NULL,
        image_path VARCHAR(500) NOT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        uploaded_by INT UNSIGNED NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_login_slides_uploaded_by FOREIGN KEY (uploaded_by) REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE,
        INDEX idx_login_slides_active (is_active, sort_order)
    ) ENGINE=InnoDB");
    $pdo->exec("ALTER TABLE about_content ADD COLUMN IF NOT EXISTS gallery_mode ENUM('slideshow','album','collage') NOT NULL DEFAULT 'album' AFTER body");
    $pdo->exec("CREATE TABLE IF NOT EXISTS about_media (
        media_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(200) NOT NULL,
        media_type ENUM('image') NOT NULL,
        file_path VARCHAR(500) NOT NULL,
        original_name VARCHAR(255) NULL,
        sort_order INT NOT NULL DEFAULT 0,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        uploaded_by INT UNSIGNED NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_about_media_uploaded_by FOREIGN KEY (uploaded_by) REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE,
        INDEX idx_about_media_display (is_active, sort_order, media_id)
    ) ENGINE=InnoDB");
} catch (PDOException $ex) {
    $error = 'The About FPHAI storage is not available yet. Please make sure the database user can create tables or run the latest database update script.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$canEdit) {
        http_response_code(403);
        exit('403 Forbidden: You are not authorized to edit this section.');
    }
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request token. Please try again.';
    } else {
        $action = $_POST['action'] ?? '';
        try {
            if ($action === 'save_about') {
                $title = trim($_POST['title'] ?? '');
                $body = sanitize_about_html(trim($_POST['body'] ?? ''));
                if ($body === '') $body = '<p></p>'; 
                $galleryMode = $_POST['gallery_mode'] ?? 'album';
                if (!in_array($galleryMode, ['slideshow','album','collage'], true)) $galleryMode = 'album';
                if ($title === '' || $body === '') throw new RuntimeException('The About title and information are required.');
                $stmt = $pdo->prepare('INSERT INTO about_content (about_id,title,body,gallery_mode,updated_by,updated_at) VALUES (1,:title,:body,:gallery_mode,:updated_by,NOW()) ON DUPLICATE KEY UPDATE title=VALUES(title), body=VALUES(body), gallery_mode=VALUES(gallery_mode), updated_by=VALUES(updated_by), updated_at=NOW()');
                $stmt->execute(['title'=>$title,'body'=>$body,'gallery_mode'=>$galleryMode,'updated_by'=>current_user_id()]);
                audit_log($pdo, current_user_id(), 'Updated', 'About FPHAI', 1, 'Updated the public FPHAI About section.');
                flash('success', 'About FPHAI information updated.');
                header('Location: about.php'); exit;
            }
            if ($action === 'add_slide') {
                $title = trim($_POST['slide_title'] ?? '');
                $path = save_uploaded_slide($_FILES['slide_image'] ?? []);
                $order = (int)$pdo->query('SELECT COALESCE(MAX(sort_order),0)+1 FROM login_slides')->fetchColumn();
                $stmt = $pdo->prepare('INSERT INTO login_slides (title,image_path,sort_order,is_active,uploaded_by) VALUES (:title,:image_path,:sort_order,1,:uploaded_by)');
                $stmt->execute(['title'=>$title ?: null,'image_path'=>$path,'sort_order'=>$order,'uploaded_by'=>current_user_id()]);
                $id = (int)$pdo->lastInsertId();
                audit_log($pdo, current_user_id(), 'Uploaded', 'About FPHAI', $id, 'Added a login background image.');
                flash('success', 'Login background image added.');
                header('Location: about.php'); exit;
            }
            if ($action === 'add_about_media') {
                $title = trim($_POST['media_title'] ?? '');
                if ($title === '') throw new RuntimeException('Please provide a title for the image.');
                $media = save_uploaded_about_media($_FILES['about_media_file'] ?? []);
                $order = (int)$pdo->query('SELECT COALESCE(MAX(sort_order),0)+1 FROM about_media')->fetchColumn();
                $stmt = $pdo->prepare('INSERT INTO about_media (title,media_type,file_path,original_name,sort_order,is_active,uploaded_by) VALUES (:title,:media_type,:file_path,:original_name,:sort_order,1,:uploaded_by)');
                $stmt->execute(['title'=>$title,'media_type'=>$media['media_type'],'file_path'=>$media['stored_name'],'original_name'=>$media['original_name'],'sort_order'=>$order,'uploaded_by'=>current_user_id()]);
                $id=(int)$pdo->lastInsertId();
                audit_log($pdo,current_user_id(),'Uploaded','About FPHAI',$id,'Added About FPHAI media: '.$media['original_name']);
                flash('success', 'About FPHAI media added.');
                header('Location: about.php'); exit;
            }
            if ($action === 'reorder_about_media') {
                $order = $_POST['media_order'] ?? [];
                if (!is_array($order)) $order = [];
                $stmt = $pdo->prepare('UPDATE about_media SET sort_order=:sort_order WHERE media_id=:id');
                foreach ($order as $position => $id) {
                    $id=(int)$id; if ($id>0) $stmt->execute(['sort_order'=>$position+1,'id'=>$id]);
                }
                audit_log($pdo,current_user_id(),'Updated','About FPHAI',null,'Reordered About FPHAI images.');
                flash('success','About FPHAI image order updated.');
                header('Location: about.php'); exit;
            }
            if ($action === 'toggle_about_media') {
                $id=(int)($_POST['media_id'] ?? 0);
                $pdo->prepare('UPDATE about_media SET is_active=IF(is_active=1,0,1) WHERE media_id=:id')->execute(['id'=>$id]);
                audit_log($pdo,current_user_id(),'Updated','About FPHAI',$id,'Changed About FPHAI media visibility.');
                flash('success','About FPHAI media visibility updated.');
                header('Location: about.php'); exit;
            }
            if ($action === 'delete_about_media') {
                $id=(int)($_POST['media_id'] ?? 0);
                $stmt=$pdo->prepare('SELECT file_path FROM about_media WHERE media_id=:id');
                $stmt->execute(['id'=>$id]); $media=$stmt->fetch();
                if (!$media) throw new RuntimeException('The selected About FPHAI media was not found.');
                $pdo->prepare('DELETE FROM about_media WHERE media_id=:id')->execute(['id'=>$id]);
                if (!empty($media['file_path'])) @unlink(UPLOAD_DIR.$media['file_path']);
                audit_log($pdo,current_user_id(),'Deleted','About FPHAI',$id,'Removed About FPHAI media.');
                flash('success','About FPHAI media removed.');
                header('Location: about.php'); exit;
            }
            if ($action === 'delete_slide') {
                $id = (int)($_POST['slide_id'] ?? 0);
                $stmt = $pdo->prepare('SELECT image_path FROM login_slides WHERE slide_id=:id');
                $stmt->execute(['id'=>$id]); $slide = $stmt->fetch();
                if (!$slide) throw new RuntimeException('The selected login background image was not found.');
                $pdo->prepare('DELETE FROM login_slides WHERE slide_id=:id')->execute(['id'=>$id]);
                audit_log($pdo, current_user_id(), 'Deleted', 'About FPHAI', $id, 'Removed a login background image.');
                if (!empty($slide['image_path'])) @unlink(UPLOAD_DIR . $slide['image_path']);
                flash('success', 'Login background image removed.');
                header('Location: about.php'); exit;
            }
            if ($action === 'toggle_slide') {
                $id = (int)($_POST['slide_id'] ?? 0);
                $stmt = $pdo->prepare('UPDATE login_slides SET is_active=IF(is_active=1,0,1) WHERE slide_id=:id');
                $stmt->execute(['id'=>$id]);
                audit_log($pdo, current_user_id(), 'Updated', 'About FPHAI', $id, 'Changed login background visibility.');
                flash('success', 'Login background visibility updated.');
                header('Location: about.php'); exit;
            }
            if ($action === 'reorder_slides') {
                $order=$_POST['slide_order']??[]; if(!is_array($order))$order=[];
                $stmt=$pdo->prepare('UPDATE login_slides SET sort_order=:sort_order WHERE slide_id=:id');
                foreach($order as $position=>$id){$id=(int)$id;if($id>0)$stmt->execute(['sort_order'=>$position+1,'id'=>$id]);}
                audit_log($pdo,current_user_id(),'Updated','About FPHAI',null,'Reordered login background images.');
                flash('success','Login background order updated.'); header('Location: about.php'); exit;
            }
        } catch (RuntimeException $ex) {
            $error = $ex->getMessage();
        } catch (PDOException $ex) {
            $error = 'The About or login background information could not be saved. Please verify the database migration was imported.';
        }
    }
}

$about = null;
if ($error === '') {
    $about = $pdo->query('SELECT * FROM about_content WHERE about_id=1')->fetch();
}
if (!$about) {
    $about = [
        'title' => "About Fairmont Park Homeowners' Association, Inc.",
        'gallery_mode' => 'album',
        'body' => "Fairmont Park Homeowners' Association, Inc. (FPHAI) is a non-profit, non-government homeowners association located at Boles Street, Fairmont North Fairview, Quezon City.

FPHAI works to maintain a peaceful and orderly residential community and provides services such as homeowner records management, monthly dues collection, facility reservations, community announcements, clearances, and other association services.

This centralized management system is designed to help organize records, improve collection reporting, and manage facility reservations more efficiently."
    ];
}
$allSlides = ($canEdit && $error === '') ? $pdo->query('SELECT * FROM login_slides ORDER BY sort_order, slide_id')->fetchAll() : [];
$aboutMedia = ($error === '') ? $pdo->query('SELECT * FROM about_media WHERE is_active=1 ORDER BY sort_order, media_id')->fetchAll() : [];
$allAboutMedia = ($canEdit && $error === '') ? $pdo->query('SELECT * FROM about_media ORDER BY sort_order, media_id')->fetchAll() : [];

if ($loggedIn) {
    $pageTitle = 'About FPHAI';
    require __DIR__ . '/includes/header.php';
    $flash = get_flash();
    ?>
    <?php if ($flash): ?><div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>

    <div class="about-layout about-page-shell">
        <section class="section-card about-card about-display about-hero">
            <div class="section-heading">
                <div><span class="section-kicker">Fairmont Park HOA</span><h2><?= e($about['title']) ?></h2></div>
                <?php if ($canEdit): ?><span class="status-pill status-success">Editable</span><?php endif; ?>
            </div>
            <div class="about-body rich-about-body"><?= render_about_body($about['body']) ?></div>
        </section>

        <?php if ($aboutMedia): ?>
        <section class="section-card about-media-public about-gallery-mode-<?= e($about['gallery_mode'] ?? 'album') ?>">
            <div class="section-heading"><div><span class="section-kicker">Fairmont Park HOA</span><h2>FPHAI Images</h2><p>Community images, announcements, certifications, and other visual information shared by FPHAI.</p></div></div>
            <?php if (($about['gallery_mode'] ?? 'album') === 'slideshow'): ?>
                <div class="about-public-slideshow">
                    <?php foreach ($aboutMedia as $index=>$media): ?>
                        <?php if ($media['media_type']==='image'): ?><figure class="about-public-slide<?= $index===0?' is-visible':'' ?>"><button type="button" class="about-image-button" data-about-image="uploads/<?= e($media['file_path']) ?>" data-about-title="<?= e($media['title']) ?>"><img src="about_media_download.php?id=<?= (int)$media['media_id'] ?>" alt="<?= e($media['title']) ?>"></button><figcaption><?= e($media['title']) ?><?php if($canDownloadAboutImages): ?><a class="about-image-download" href="about_media_download.php?id=<?= (int)$media['media_id'] ?>&download=1">Download image</a><?php endif; ?></figcaption></figure><?php endif; ?>
                    <?php endforeach; ?>
                </div>
            <?php elseif (($about['gallery_mode'] ?? 'album') === 'collage'): ?>
                <div class="about-public-collage">
                    <?php foreach ($aboutMedia as $media): ?><?php if($media['media_type']==='image'): ?><figure><button type="button" class="about-image-button" data-about-image="about_media_download.php?id=<?= (int)$media['media_id'] ?>" data-about-title="<?= e($media['title']) ?>"><img src="about_media_download.php?id=<?= (int)$media['media_id'] ?>" alt="<?= e($media['title']) ?>"></button><figcaption><?= e($media['title']) ?><?php if($canDownloadAboutImages): ?><a class="about-image-download" href="about_media_download.php?id=<?= (int)$media['media_id'] ?>&download=1">Download image</a><?php endif; ?></figcaption></figure><?php endif; ?><?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="about-public-album">
                    <?php foreach ($aboutMedia as $media): ?><?php if($media['media_type']==='image'): ?><figure><button type="button" class="about-image-button" data-about-image="about_media_download.php?id=<?= (int)$media['media_id'] ?>" data-about-title="<?= e($media['title']) ?>"><img src="about_media_download.php?id=<?= (int)$media['media_id'] ?>" alt="<?= e($media['title']) ?>"></button><figcaption><?= e($media['title']) ?><?php if($canDownloadAboutImages): ?><a class="about-image-download" href="about_media_download.php?id=<?= (int)$media['media_id'] ?>&download=1">Download image</a><?php endif; ?></figcaption></figure><?php endif; ?><?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
        <div id="about-image-lightbox" class="about-lightbox" hidden><div class="about-lightbox-inner" role="dialog" aria-modal="true" aria-label="FPHAI image viewer"><button type="button" class="about-lightbox-close" onclick="closeAboutLightbox()" aria-label="Close image viewer">×</button><img id="about-lightbox-image" src="" alt=""><div id="about-lightbox-caption"></div></div></div>
        <?php endif; ?>

        <?php if ($canEdit): ?>
        <details class="section-card about-editor-card foldable-panel">
            <summary><span><strong>Edit About FPHAI</strong><small>Open this section when you need to update the public information.</small></span><span class="fold-chevron">⌄</span></summary>
            <div class="foldable-content"><div class="section-heading"><div><h2>Edit About FPHAI</h2><p>Changes are visible to all logged-in users and visitors.</p></div></div>
            <form method="POST" class="form-grid">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="save_about">
                <div class="form-group full"><label for="title">Title</label><input id="title" name="title" maxlength="200" value="<?= e($about['title']) ?>" required></div>
                <div class="form-group full"><label>Visual Page Editor</label><div class="about-editor"><div class="about-editor-toolbar" role="toolbar"><button type="button" data-cmd="bold"><strong>B</strong></button><button type="button" data-cmd="italic"><em>I</em></button><button type="button" data-cmd="underline"><u>U</u></button><button type="button" data-cmd="formatBlock" data-value="h2">Heading</button><button type="button" data-cmd="insertUnorderedList">• List</button><button type="button" data-cmd="insertOrderedList">1. List</button><button type="button" data-cmd="justifyLeft">Left</button><button type="button" data-cmd="justifyCenter">Center</button><button type="button" data-cmd="justifyRight">Right</button><button type="button" data-cmd="createLink">Link</button></div><div id="about-editor-surface" class="about-editor-surface" contenteditable="true" spellcheck="true"><?= render_about_body($about['body']) ?></div></div><textarea id="body" name="body" hidden></textarea><p class="form-note">Edit the page visually, including headings, emphasis, lists, alignment, and links. The public page will use this same layout.</p></div><div class="form-group"><label for="gallery_mode">Public Image Layout</label><select id="gallery_mode" name="gallery_mode"><option value="album" <?= ($about['gallery_mode'] ?? 'album')==='album'?'selected':'' ?>>Album</option><option value="slideshow" <?= ($about['gallery_mode'] ?? 'album')==='slideshow'?'selected':'' ?>>Slideshow</option><option value="collage" <?= ($about['gallery_mode'] ?? 'album')==='collage'?'selected':'' ?>>Collage</option></select><p class="form-note">Choose how the public image collection is displayed.</p></div>
                <div class="full"><button class="btn btn-primary" type="submit">Save About FPHAI</button></div>
            </form></div>
        </details>

        <details class="section-card about-media-manager foldable-panel">
            <summary><span><strong>FPHAI Images</strong><small>Add and arrange the FPHAI Images shown on the public About page.</small></span><span class="fold-chevron">⌄</span></summary>
            <div class="foldable-content"><div class="section-heading"><div><h2>FPHAI Images</h2><p>Add public FPHAI images such as announcements, activities, certifications, or clear page images from PDF records. Images may be landscape or portrait and are displayed without cropping. Maximum 10 MB per image and up to 25 megapixels.</p></div></div>
            <form method="POST" enctype="multipart/form-data" class="form-grid">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="add_about_media">
                <div class="form-group"><label for="media_title">Title</label><input id="media_title" name="media_title" maxlength="200" required></div>
                <div class="form-group"><label for="about_media_file">FPHAI Image</label><input id="about_media_file" name="about_media_file" type="file" accept="image/jpeg,image/png,image/webp" required><p class="form-note">JPG, PNG, or WEBP · up to 10 MB · maximum 25 megapixels. Landscape and portrait images are accepted and will not be cropped.</p></div>
                <div class="full"><button class="btn btn-primary" type="submit">Add FPHAI Image</button></div>
            </form>
            <div class="about-media-manager-grid" id="about-media-sortable">
            <?php foreach ($allAboutMedia as $media): ?>
                <article class="about-media-manager-card" draggable="true" data-media-id="<?= (int)$media['media_id'] ?>">
                    <?php if ($media['media_type']==='image'): ?><img src="about_media_download.php?id=<?= (int)$media['media_id'] ?>" alt="<?= e($media['title']) ?>"><a class="about-media-download" href="about_media_download.php?id=<?= (int)$media['media_id'] ?>&download=1">Download image</a><?php else: ?><div class="about-pdf-mini">Legacy PDF — replace with image</div><?php endif; ?>
                    <div class="about-media-manager-info"><strong><?= e($media['title']) ?></strong><span>IMAGE · <?= e($media['original_name'] ?: '') ?></span></div>
                    <div class="actions">
                        <form method="POST" class="inline-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="toggle_about_media"><input type="hidden" name="media_id" value="<?= (int)$media['media_id'] ?>"><button class="btn btn-secondary btn-small" type="submit"><?= $media['is_active']?'Hide':'Show' ?></button></form>
                        <form method="POST" class="inline-form" onsubmit="return confirm('Remove this About FPHAI media item?');"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete_about_media"><input type="hidden" name="media_id" value="<?= (int)$media['media_id'] ?>"><button class="btn btn-danger btn-small" type="submit">Delete</button></form>
                    </div>
                </article>
            <?php endforeach; ?>
            <?php if (!$allAboutMedia): ?><p class="empty-state">No public images have been added yet.</p><?php endif; ?>
            </div>
            <form method="POST" id="about-media-order-form" class="about-media-order-form">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="reorder_about_media"><div id="about-media-order-fields"></div>
                <div class="about-media-order-actions"><button class="btn btn-secondary" type="submit">Save Image Order</button><span class="form-note">Drag the cards to arrange their public order.</span></div>
            </form>
        </div>
</details>

        <details class="section-card about-slides-card foldable-panel">
            <summary><span><strong>Login Background</strong><small>Manage the landscape images shown behind the login page.</small></span><span class="fold-chevron">⌄</span></summary>
            <div class="foldable-content"><div class="section-heading"><div><h2>Login Background</h2><p>Landscape JPG, PNG, or WEBP only. Maximum 10 MB and 25 megapixels per image. Images are displayed without cropping and transition every 1 minute.</p></div></div>
            <form method="POST" enctype="multipart/form-data" class="form-grid">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="add_slide">
                <div class="form-group"><label for="slide_title">Image Title (optional)</label><input id="slide_title" name="slide_title" maxlength="200"></div>
                <div class="form-group"><label for="slide_image">Landscape Background Image</label><input id="slide_image" name="slide_image" type="file" accept="image/jpeg,image/png,image/webp" required><p class="form-note">Portrait images are rejected.</p></div>
                <div class="full"><button class="btn btn-primary" type="submit">Add Background Image</button></div>
            </form>
            <div class="slide-manager-grid" id="login-slides-sortable">
            <?php foreach ($allSlides as $slide): ?>
                <article class="slide-manager-card about-media-manager-card" draggable="true" data-slide-id="<?= (int)$slide['slide_id'] ?>">
                    <img src="login_slide.php?id=<?= (int)$slide['slide_id'] ?>" alt="<?= e($slide['title'] ?: 'Login background image') ?>">
                    <div class="slide-manager-info"><strong><?= e($slide['title'] ?: 'Untitled image') ?></strong><span><?= $slide['is_active'] ? 'Visible on login' : 'Hidden from login' ?></span></div>
                    <div class="actions">
                        <form method="POST" class="inline-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="toggle_slide"><input type="hidden" name="slide_id" value="<?= (int)$slide['slide_id'] ?>"><button class="btn btn-secondary btn-small" type="submit"><?= $slide['is_active'] ? 'Hide' : 'Show' ?></button></form>
                        <form method="POST" class="inline-form" onsubmit="return confirm('Remove this login background image?');"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete_slide"><input type="hidden" name="slide_id" value="<?= (int)$slide['slide_id'] ?>"><button class="btn btn-danger btn-small" type="submit">Delete</button></form>
                    </div>
                </article>
            <?php endforeach; ?>
            <?php if (!$allSlides): ?><p class="empty-state">No custom login background images have been added yet.</p><?php endif; ?>
            </div>
            <form method="POST" class="about-media-order-form" id="login-slides-order-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="reorder_slides"><div id="login-slides-order-fields"></div><div class="about-media-order-actions"><button class="btn btn-secondary" type="submit">Save Image Order</button><span class="form-note">Drag and drop the images to arrange their slideshow order.</span></div></form>
            </div>
        </details>
        <?php endif; ?>
    </div>
    <script>
(function(){
 const slides=[...document.querySelectorAll('.about-public-slide')]; if(slides.length>1){let i=0;setInterval(()=>{slides[i].classList.remove('is-visible');i=(i+1)%slides.length;slides[i].classList.add('is-visible');},5000);}
 const editor=document.getElementById('about-editor-surface'), body=document.getElementById('body');
 if(editor && body){
   const form=editor.closest('form');
   editor.closest('.about-editor')?.querySelectorAll('[data-cmd]').forEach(btn=>btn.addEventListener('click',()=>{
      editor.focus(); const cmd=btn.dataset.cmd;
      if(cmd==='createLink'){const url=prompt('Enter the link URL:','https://'); if(url) document.execCommand('createLink',false,url);}
      else if(cmd==='formatBlock') document.execCommand(cmd,false,btn.dataset.value); else document.execCommand(cmd,false,null);
   }));
   form?.addEventListener('submit',()=>{body.value=editor.innerHTML;});
 }
 const grid=document.getElementById('about-media-sortable'), orderFields=document.getElementById('about-media-order-fields');
 const syncOrder=()=>{if(!orderFields||!grid)return;orderFields.innerHTML='';grid.querySelectorAll('[draggable=true]').forEach(card=>{const i=document.createElement('input');i.type='hidden';i.name='media_order[]';i.value=card.dataset.mediaId;orderFields.appendChild(i);});};
 if(grid){let dragged=null;grid.querySelectorAll('[draggable=true]').forEach(card=>{card.addEventListener('dragstart',()=>{dragged=card;card.classList.add('is-dragging');});card.addEventListener('dragend',()=>{card.classList.remove('is-dragging');dragged=null;syncOrder();});card.addEventListener('dragover',e=>{e.preventDefault();if(!dragged||dragged===card)return;const r=card.getBoundingClientRect();grid.insertBefore(dragged,e.clientY<r.top+r.height/2?card:card.nextSibling);});});syncOrder();}
 const slideGrid=document.getElementById('login-slides-sortable'), slideFields=document.getElementById('login-slides-order-fields');
 const syncSlides=()=>{if(!slideGrid||!slideFields)return;slideFields.innerHTML='';slideGrid.querySelectorAll('[draggable=true]').forEach(card=>{const i=document.createElement('input');i.type='hidden';i.name='slide_order[]';i.value=card.dataset.slideId;slideFields.appendChild(i);});};
 if(slideGrid){let draggedSlide=null;slideGrid.querySelectorAll('[draggable=true]').forEach(card=>{card.addEventListener('dragstart',()=>{draggedSlide=card;card.classList.add('is-dragging');});card.addEventListener('dragend',()=>{card.classList.remove('is-dragging');draggedSlide=null;syncSlides();});card.addEventListener('dragover',e=>{e.preventDefault();if(!draggedSlide||draggedSlide===card)return;const r=card.getBoundingClientRect();slideGrid.insertBefore(draggedSlide,e.clientY<r.top+r.height/2?card:card.nextSibling);});});syncSlides();}
})();
</script>
    <?php require __DIR__ . '/includes/footer.php'; exit;
}
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>About FPHAI | Fairmont Park HOA</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body class="public-about-page">
<header class="public-about-header"><a href="login.php" class="public-brand"><img src="assets/images/logo.png" alt="FPHAI logo"><span>Fairmont Park HOA</span></a><a href="login.php" class="btn btn-primary">Sign In</a></header>
<main class="public-about-main">
<section class="public-about-card"><span class="section-kicker">Fairmont Park Homeowners' Association, Inc.</span><h1><?= e($about['title']) ?></h1><div class="about-body rich-about-body"><?= render_about_body($about['body']) ?></div></section>
<?php if ($aboutMedia): ?><section class="public-about-card public-about-images"><div class="section-heading"><div><span class="section-kicker">Fairmont Park HOA</span><h2>FPHAI Images</h2><p>Browse the images shared by the Association. Select an image to view the whole picture.</p></div></div>
<?php if (($about['gallery_mode'] ?? 'album') === 'slideshow'): ?><div class="about-public-slideshow public-lightbox-gallery"><?php foreach($aboutMedia as $index=>$media): ?><?php if($media['media_type']==='image'): ?><figure class="about-public-slide<?= $index===0?' is-visible':'' ?>"><button type="button" class="about-image-button" data-about-image="about_media_download.php?id=<?= (int)$media['media_id'] ?>" data-about-title="<?= e($media['title']) ?>"><img src="about_media_download.php?id=<?= (int)$media['media_id'] ?>" alt="<?= e($media['title']) ?>"></button><figcaption><?= e($media['title']) ?></figcaption></figure><?php endif; ?><?php endforeach; ?></div>
<?php elseif (($about['gallery_mode'] ?? 'album') === 'collage'): ?><div class="about-public-collage public-lightbox-gallery"><?php foreach($aboutMedia as $media): ?><?php if($media['media_type']==='image'): ?><figure><button type="button" class="about-image-button" data-about-image="about_media_download.php?id=<?= (int)$media['media_id'] ?>" data-about-title="<?= e($media['title']) ?>"><img src="about_media_download.php?id=<?= (int)$media['media_id'] ?>" alt="<?= e($media['title']) ?>"></button><figcaption><?= e($media['title']) ?></figcaption></figure><?php endif; ?><?php endforeach; ?></div>
<?php else: ?><div class="about-public-album public-lightbox-gallery"><?php foreach($aboutMedia as $media): ?><?php if($media['media_type']==='image'): ?><figure><button type="button" class="about-image-button" data-about-image="about_media_download.php?id=<?= (int)$media['media_id'] ?>" data-about-title="<?= e($media['title']) ?>"><img src="about_media_download.php?id=<?= (int)$media['media_id'] ?>" alt="<?= e($media['title']) ?>"></button><figcaption><?= e($media['title']) ?></figcaption></figure><?php endif; ?><?php endforeach; ?></div><?php endif; ?></section><div id="about-image-lightbox" class="about-lightbox" hidden><div class="about-lightbox-inner" role="dialog" aria-modal="true" aria-label="FPHAI image viewer"><button type="button" class="about-lightbox-close" onclick="closeAboutLightbox()" aria-label="Close image viewer">×</button><img id="about-lightbox-image" src="" alt=""><div id="about-lightbox-caption"></div></div></div><?php endif; ?></main>
<footer class="site-footer public-footer">&copy; <?= date('Y') ?> Fairmont Park Homeowners' Association, Inc.</footer>
<script>
(function(){
 const slides=[...document.querySelectorAll('.about-public-slide')]; if(slides.length>1){let i=0;setInterval(()=>{slides[i].classList.remove('is-visible');i=(i+1)%slides.length;slides[i].classList.add('is-visible');},5000);}
 const box=document.getElementById('about-image-lightbox'), img=document.getElementById('about-lightbox-image'), cap=document.getElementById('about-lightbox-caption');
 window.closeAboutLightbox=()=>{if(box){box.hidden=true;document.body.classList.remove('modal-open');}};
 document.querySelectorAll('.about-image-button').forEach(btn=>btn.addEventListener('click',()=>{if(!box)return;img.src=btn.dataset.aboutImage;img.alt=btn.dataset.aboutTitle||'FPHAI image';cap.textContent=btn.dataset.aboutTitle||'';box.hidden=false;document.body.classList.add('modal-open');}));
 if(box){box.addEventListener('click',e=>{if(e.target===box)window.closeAboutLightbox();});document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!box.hidden)window.closeAboutLightbox();});}
})();
</script>
</body></html>
