<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

if (is_logged_in()) { redirect_by_role(); }

$userId = (int)($_SESSION['pending_2fa_user_id'] ?? 0);
if ($userId < 1) { header('Location: login.php'); exit; }

$error = '';
$notice = '';
$contacts = user_two_factor_contacts($pdo, $userId);
if (!$contacts['enabled']) { unset($_SESSION['pending_2fa_user_id'], $_SESSION['pending_2fa_username'], $_SESSION['pending_2fa_expires_at']); header('Location: login.php'); exit; }

if (!empty($_SESSION['pending_2fa_expires_at']) && time() > (int)$_SESSION['pending_2fa_expires_at']) {
    $error = 'The verification session has expired. Please sign in again.';
    $pdo->prepare('DELETE FROM login_2fa_challenges WHERE user_id=:user_id')->execute(['user_id'=>$userId]);
    unset($_SESSION['pending_2fa_user_id'], $_SESSION['pending_2fa_username'], $_SESSION['pending_2fa_expires_at']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $error === '') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request token. Please try again.';
    } elseif (($_POST['action'] ?? '') === 'resend') {
        $challenge = create_and_send_2fa_challenge($pdo, $userId);
        if ($challenge['sent']) {
            $_SESSION['pending_2fa_expires_at'] = time() + (TWO_FACTOR_CODE_MINUTES * 60);
            $notice = 'A new verification code was sent using the available security contact method(s).';
        } else {
            $error = 'The verification code could not be delivered. Please contact the HOA office.';
        }
    } else {
        $code = preg_replace('/\D+/', '', trim($_POST['code'] ?? ''));
        if (strlen($code) !== 6) {
            $error = 'Enter the 6-digit verification code.';
        } else {
            $stmt = $pdo->prepare('SELECT * FROM login_2fa_challenges WHERE user_id=:user_id AND verified_at IS NULL ORDER BY challenge_id DESC LIMIT 1');
            $stmt->execute(['user_id'=>$userId]);
            $challenge = $stmt->fetch();
            if (!$challenge || strtotime($challenge['expires_at']) <= time()) {
                $error = 'The verification code has expired. Please request a new code.';
            } elseif ((int)$challenge['attempts'] >= TWO_FACTOR_MAX_ATTEMPTS) {
                $error = 'Too many incorrect verification attempts. Please request a new code.';
            } elseif (!password_verify($code, $challenge['code_hash'])) {
                $pdo->prepare('UPDATE login_2fa_challenges SET attempts=attempts+1 WHERE challenge_id=:id')->execute(['id'=>$challenge['challenge_id']]);
                $remaining = max(0, TWO_FACTOR_MAX_ATTEMPTS - ((int)$challenge['attempts'] + 1));
                $error = 'The verification code is incorrect.' . ($remaining ? " {$remaining} attempt(s) remaining." : ' Please request a new code.');
            } else {
                $pdo->prepare('UPDATE login_2fa_challenges SET verified_at=NOW() WHERE challenge_id=:id')->execute(['id'=>$challenge['challenge_id']]);
                $userStmt = $pdo->prepare('SELECT user_id,username,role,status,must_change_password,temporary_password_expires_at FROM users WHERE user_id=:id LIMIT 1');
                $userStmt->execute(['id'=>$userId]);
                $user = $userStmt->fetch();
                if (!$user || $user['status'] !== 'Active') {
                    $error = 'This account is no longer active.';
                } else {
                    session_regenerate_id(true);
                    $_SESSION['user_id'] = (int)$user['user_id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['role'] = $user['role'];
                    $_SESSION['last_activity'] = time();
                    unset($_SESSION['pending_2fa_user_id'], $_SESSION['pending_2fa_username'], $_SESSION['pending_2fa_expires_at']);
                    $pdo->prepare('DELETE FROM login_2fa_challenges WHERE user_id=:user_id')->execute(['user_id'=>$userId]);
                    audit_log($pdo, $userId, 'Verified', 'Authentication', $userId, 'Completed two-factor authentication.');
                    if ((int)$user['must_change_password'] === 1) { header('Location: change-password.php'); exit; }
                    redirect_by_role();
                }
            }
        }
    }
}

$username = (string)($_SESSION['pending_2fa_username'] ?? '');
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Security Verification | Fairmont Park HOA</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body class="login-page"><main class="login-shell"><section class="login-card">
<img src="assets/images/logo.png" alt="Fairmont Park HOA logo" class="login-logo"><h1>Security Verification</h1><p class="login-subtitle">A second verification step protects your account.</p>
<?php if($error): ?><div class="alert alert-error"><?=e($error)?></div><?php endif; ?><?php if($notice): ?><div class="alert alert-success"><?=e($notice)?></div><?php endif; ?>
<div class="two-factor-method"><strong>Verification code sent</strong><span><?= $contacts['email_masked'] ? 'Email: '.e($contacts['email_masked']) : '' ?><?= ($contacts['email_masked'] && $contacts['mobile_masked']) ? ' · ' : '' ?><?= $contacts['mobile_masked'] ? 'SMS: '.e($contacts['mobile_masked']) : '' ?></span></div>
<form method="POST" class="form-stack" autocomplete="one-time-code"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><div class="form-group"><label for="code">6-Digit Verification Code</label><input id="code" name="code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="one-time-code" required autofocus></div><button class="btn btn-primary btn-large" type="submit">Verify and Sign In</button></form>
<form method="POST" class="two-factor-resend"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="resend"><button class="btn btn-secondary btn-small" type="submit">Send a New Code</button><a class="login-about-link" href="login.php">Return to Login</a></form>
<p class="login-footer">Account: <?=e($username)?></p></section></main></body></html>
