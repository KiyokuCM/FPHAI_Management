<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/functions.php';

$secureRequest = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ((int)($_SERVER['SERVER_PORT'] ?? 0) === 443);
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'");
if ($secureRequest) { header('Strict-Transport-Security: max-age=31536000; includeSubDomains'); }

$pageTitle = $pageTitle ?? APP_NAME;
$headerUnreadNotifications = function_exists('unread_notification_count') ? unread_notification_count($pdo, current_user_id()) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-Content-Type-Options" content="nosniff">
    <meta http-equiv="X-Frame-Options" content="SAMEORIGIN">
    <meta name="referrer" content="strict-origin-when-cross-origin">
    <title><?= e($pageTitle) ?> | <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= e(APP_URL) ?>/assets/css/style.css">
</head>
<body>
<div class="app-shell">
    <?php require __DIR__ . '/sidebar.php'; ?>

    <div class="main-area">
        <header class="topbar">
            <button class="mobile-menu-btn" type="button" onclick="toggleSidebar()" aria-label="Open navigation">
                ☰
            </button>

            <div>
                <span class="eyebrow"><?= e(APP_FULL_NAME) ?></span>
                <h1 class="page-title"><?= e($pageTitle) ?></h1>
            </div>

            <div class="topbar-right">
                <a class="notification-bell" href="<?= e(APP_URL) ?>/notifications.php" title="Notifications" aria-label="Notifications">🔔<?php if($headerUnreadNotifications): ?><span><?= number_format($headerUnreadNotifications) ?></span><?php endif; ?></a>
                <div class="topbar-clock" aria-live="polite"><div class="clock-date-block"><span class="clock-label">TODAY</span><span class="clock-date" data-live-date><?= date('l, F j, Y') ?></span></div><div class="clock-divider" aria-hidden="true"></div><div class="clock-time-block"><span class="clock-label">CURRENT TIME</span><strong class="clock-time" data-live-time><?= date('h:i:s A') ?></strong></div></div>
            </div>
        </header>

        <main class="content">
