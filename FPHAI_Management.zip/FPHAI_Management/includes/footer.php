</main>

        <footer class="site-footer">
            <span>&copy; <?= date('Y') ?> Fairmont Park Homeowners' Association, Inc.</span>
        </footer>
    </div>
</div>

<script src="<?= e(APP_URL) ?>/assets/js/app.js"></script>
</body>
</html>
