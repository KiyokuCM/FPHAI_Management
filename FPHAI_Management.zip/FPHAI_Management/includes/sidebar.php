<?php
$currentPage = basename($_SERVER['PHP_SELF'] ?? '');
$navLink = static function (string $href, string $label) use ($currentPage): string {
    $active = basename(parse_url($href, PHP_URL_PATH) ?: '') === $currentPage ? ' active' : '';
    return '<a href="' . e($href) . '" class="nav-link' . $active . '"><span>' . e($label) . '</span></a>';
};
?>
<aside class="sidebar" id="sidebar">
    <div class="brand">
        <img src="<?= e(APP_URL) ?>/assets/images/logo.png" alt="FPHAI logo" class="brand-logo">
        <div class="brand-text">
            <strong>Fairmont Park</strong>
            <span>HOA Management</span>
        </div>
    </div>

    <nav class="nav-list" aria-label="Main navigation">
        <?php if (current_role() === 'Administrator'): ?>
            <?= $navLink(APP_URL . '/admin/dashboard.php', 'Dashboard') ?>
            <?= $navLink(APP_URL . '/admin/users.php', 'User Accounts') ?>
            <?= $navLink(APP_URL . '/admin/homeowners.php', 'Homeowners') ?>
            <?= $navLink(APP_URL . '/admin/collections.php', 'Collections') ?>
            <?= $navLink(APP_URL . '/admin/reservations.php', 'Reservations') ?>
            <?= $navLink(APP_URL . '/admin/documents.php', 'Documents') ?>
            <?= $navLink(APP_URL . '/admin/reports.php', 'Reports') ?>
            <?= $navLink(APP_URL . '/admin/audit-trail.php', 'Audit Trail') ?>
            <?= $navLink(APP_URL . '/about.php', 'About FPHAI') ?>
        <?php elseif (current_role() === 'Clerk'): ?>
            <?= $navLink(APP_URL . '/clerk/dashboard.php', 'Dashboard') ?>
            <?= $navLink(APP_URL . '/clerk/homeowners.php', 'Homeowners') ?>
            <?= $navLink(APP_URL . '/clerk/payments.php', 'Payments') ?>
            <?= $navLink(APP_URL . '/clerk/reservations.php', 'Reservations') ?>
            <?= $navLink(APP_URL . '/clerk/documents.php', 'Documents') ?>
            <?= $navLink(APP_URL . '/clerk/reports.php', 'Reports') ?>
            <?= $navLink(APP_URL . '/about.php', 'About FPHAI') ?>
        <?php elseif (current_role() === 'Resident'): ?>
            <?= $navLink(APP_URL . '/resident/dashboard.php', 'Dashboard') ?>
            <?= $navLink(APP_URL . '/resident/payments.php', 'My Payments') ?>
            <?= $navLink(APP_URL . '/resident/reservations.php', 'Reservations') ?>
            <?= $navLink(APP_URL . '/resident/documents.php', 'Documents') ?>
            <?= $navLink(APP_URL . '/resident/profile.php', 'My Profile') ?>
            <?= $navLink(APP_URL . '/about.php', 'About FPHAI') ?>
        <?php endif; ?>
    </nav>

    <div class="sidebar-bottom">
        <a href="<?= e(APP_URL) ?>/logout.php" class="nav-link logout-link"><span class="signout-icon" aria-hidden="true">↪</span><span>Sign Out</span></a>
    </div>
</aside>
