<?php
declare(strict_types=1);

function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function homeowner_full_address(array $row): string
{
    $number = trim((string)($row['address'] ?? ''));
    $street = trim((string)($row['street'] ?? ''));
    return trim($number . ($street !== '' ? ' ' . $street : ''));
}


function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function verify_csrf(string $token): bool
{
    return isset($_SESSION['csrf_token'])
        && hash_equals($_SESSION['csrf_token'], $token);
}

function audit_log(
    PDO $pdo,
    int $userId,
    string $action,
    string $module,
    ?int $recordId = null,
    ?string $details = null
): void {
    $stmt = $pdo->prepare(
        'INSERT INTO audit_logs
            (user_id, action, module, record_id, details, created_at)
         VALUES
            (:user_id, :action, :module, :record_id, :details, NOW())'
    );

    $stmt->execute([
        'user_id'   => $userId,
        'action'    => $action,
        'module'    => $module,
        'record_id' => $recordId,
        'details'   => $details,
    ]);
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash(): ?array
{
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $flash;
}

function status_class(string $status): string
{
    return match ($status) {
        'Active', 'Validated', 'Approved', 'Completed' => 'status-success',
        'Pending' => 'status-pending',
        'Inactive', 'Rejected', 'Cancelled', 'Delinquent' => 'status-danger',
        default => 'status-neutral',
    };
}

function save_uploaded_document(array $file): array
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Please select a document to upload.');
    }

    if (($file['size'] ?? 0) > MAX_UPLOAD_SIZE) {
        throw new RuntimeException('The selected file exceeds the 10 MB limit.');
    }

    $allowed = [
        'application/pdf' => 'pdf',
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'application/msword' => 'doc',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
    ];

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);

    if (!isset($allowed[$mime])) {
        throw new RuntimeException('Unsupported file type. Use PDF, JPG, PNG, DOC, or DOCX.');
    }

    if (!is_dir(UPLOAD_DIR) && !mkdir(UPLOAD_DIR, 0755, true)) {
        throw new RuntimeException('Unable to create the upload directory.');
    }

    $extension = $allowed[$mime];
    $storedName = bin2hex(random_bytes(16)) . '.' . $extension;
    $destination = UPLOAD_DIR . $storedName;

    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        throw new RuntimeException('The document could not be saved.');
    }

    return [
        'original_name' => basename($file['name']),
        'stored_name' => $storedName,
    ];
}

function save_uploaded_image(array $file): string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Please select a homeowner picture to upload.');
    }

    if (($file['size'] ?? 0) > 10 * 1024 * 1024) {
        throw new RuntimeException('The homeowner picture must not exceed 10 MB.');
    }

    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
    ];

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);

    if (!isset($allowed[$mime])) {
        throw new RuntimeException('Unsupported picture type. Use JPG, PNG, or WEBP.');
    }

    $directory = UPLOAD_DIR . 'homeowners/';
    if (!is_dir($directory) && !mkdir($directory, 0755, true)) {
        throw new RuntimeException('Unable to create the homeowner picture directory.');
    }

    $storedName = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
    $destination = $directory . $storedName;

    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        throw new RuntimeException('The homeowner picture could not be saved.');
    }

    return 'homeowners/' . $storedName;
}

function save_uploaded_slide(array $file): string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Please select a login background image.');
    }

    if (($file['size'] ?? 0) > 10 * 1024 * 1024) {
        throw new RuntimeException('The login background image must not exceed 10 MB.');
    }

    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
    ];
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    if (!isset($allowed[$mime])) {
        throw new RuntimeException('Unsupported image type. Use JPG, PNG, or WEBP.');
    }

    $dimensions = @getimagesize($file['tmp_name']);
    if (!$dimensions || (int)$dimensions[0] <= (int)$dimensions[1]) {
        throw new RuntimeException('Login background images must be landscape orientation (width greater than height).');
    }
    if ((int)$dimensions[0] > 6000 || (int)$dimensions[1] > 6000 || ((int)$dimensions[0]*(int)$dimensions[1]) > 25000000) {
        throw new RuntimeException('The login background resolution is too large. Use an image up to 6000 × 6000 pixels and 25 megapixels.');
    }

    $directory = UPLOAD_DIR . 'login-slides/';
    if (!is_dir($directory) && !mkdir($directory, 0755, true)) {
        throw new RuntimeException('Unable to create the login slideshow directory.');
    }

    $storedName = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
    if (!move_uploaded_file($file['tmp_name'], $directory . $storedName)) {
        throw new RuntimeException('The login background image could not be saved.');
    }

    return 'login-slides/' . $storedName;
}



function deactivate_expired_homeowner_accounts(PDO $pdo): void
{
    // Temporary homeowner credentials are valid for two hours. Once the
    // deadline passes without a password change, disable the account rather
    // than deleting it so the linked homeowner record remains traceable.
    $stmt = $pdo->prepare(
        'UPDATE users
         SET status="Inactive"
         WHERE account_source="Homeowner"
           AND must_change_password=1
           AND temporary_password_expires_at IS NOT NULL
           AND temporary_password_expires_at <= NOW()
           AND status="Active"'
    );
    $stmt->execute();
    $pdo->exec('UPDATE homeowners h INNER JOIN users u ON u.user_id=h.user_id SET h.membership_status="Inactive" WHERE u.account_source="Homeowner" AND u.status="Inactive" AND u.must_change_password=1');
}

function sanitize_about_html(string $html): string
{
    $allowed = '<p><br><div><span><h1><h2><h3><h4><strong><b><em><i><u><ul><ol><li><blockquote><a>';
    $html = preg_replace('~<(script|style|iframe|object|embed)\b[^>]*>.*?</\1>~is', '', $html) ?? $html;
    $html = strip_tags($html, $allowed);
    return preg_replace_callback('/<([a-z0-9]+)\b([^>]*)>/i', function($m) {
        $tag = strtolower($m[1]);
        if ($tag === 'br') return '<br>';
        $attrs = '';
        $raw = $m[2] ?? '';
        if ($tag === 'a') {
            if (preg_match('/\bhref\s*=\s*["\']([^"\']*)["\']/i', $raw, $hm)) {
                $href = trim($hm[1]);
                if (preg_match('~^(https?://|mailto:|tel:|/)~i', $href)) {
                    $attrs .= ' href="'.htmlspecialchars($href, ENT_QUOTES, 'UTF-8').'"';
                }
            }
            $attrs .= ' target="_blank" rel="noopener noreferrer"';
        }
        if (preg_match('/\bstyle\s*=\s*["\']([^"\']*)["\']/i', $raw, $sm)) {
            if (preg_match('/(?:^|;)\s*text-align\s*:\s*(left|center|right|justify)\s*(?:;|$)/i', $sm[1], $am)) {
                $attrs .= ' style="text-align:'.$am[1].'"';
            }
        }
        return '<'.$tag.$attrs.'>';
    }, $html) ?? '';
}

function render_about_body(string $body): string
{
    if (strip_tags($body) === $body) return nl2br(e($body));
    return sanitize_about_html($body);
}

function save_uploaded_about_media(array $file): array
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Please select an image to upload.');
    }
    if (($file['size'] ?? 0) > 10 * 1024 * 1024) {
        throw new RuntimeException('The selected image must not exceed 10 MB.');
    }

    $allowed = [
        'image/jpeg' => ['jpg', 'image'],
        'image/png' => ['png', 'image'],
        'image/webp' => ['webp', 'image'],
    ];
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    if (!isset($allowed[$mime])) {
        throw new RuntimeException('Unsupported image type. Use JPG, PNG, or WEBP.');
    }

    $dimensions = @getimagesize($file['tmp_name']);
    if (!$dimensions || empty($dimensions[0]) || empty($dimensions[1])) {
        throw new RuntimeException('The selected file is not a readable image.');
    }
    $width = (int)$dimensions[0];
    $height = (int)$dimensions[1];
    if ($width > 6000 || $height > 6000 || ($width * $height) > 25000000) {
        throw new RuntimeException('The image resolution is too large. Please use an image up to 6000 × 6000 pixels and 25 megapixels.');
    }

    $directory = UPLOAD_DIR . 'about-media/';
    if (!is_dir($directory) && !mkdir($directory, 0755, true)) {
        throw new RuntimeException('Unable to create the About FPHAI media directory.');
    }
    [$extension, $mediaType] = $allowed[$mime];
    $storedName = bin2hex(random_bytes(16)) . '.' . $extension;
    if (!move_uploaded_file($file['tmp_name'], $directory . $storedName)) {
        throw new RuntimeException('The About FPHAI image could not be saved.');
    }
    return ['stored_name'=>'about-media/'.$storedName,'media_type'=>$mediaType,'mime_type'=>$mime,'original_name'=>basename($file['name'])];
}

function generate_resident_username(PDO $pdo, int $homeownerId, ?string $householdName = null): string
{
    if ($householdName === null || trim($householdName) === '') {
        $stmt = $pdo->prepare('SELECT household_name FROM homeowners WHERE homeowner_id=:id');
        $stmt->execute(['id'=>$homeownerId]);
        $householdName = (string)($stmt->fetchColumn() ?: 'resident');
    }

    $baseName = strtolower(trim((string)$householdName));
    if (function_exists('iconv')) {
        $converted = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $baseName);
        if ($converted !== false) $baseName = $converted;
    }
    $baseName = preg_replace('/[^a-z0-9]+/', '', $baseName) ?: 'resident';
    $baseName = substr($baseName, 0, 40);
    $base = $baseName . str_pad((string)$homeownerId, 4, '0', STR_PAD_LEFT);
    $username = $base;
    $suffix = 1;

    $stmt = $pdo->prepare('SELECT COUNT(*) FROM users WHERE username = :username');
    while (true) {
        $stmt->execute(['username' => $username]);
        if ((int)$stmt->fetchColumn() === 0) return $username;
        $username = $base . $suffix;
        $suffix++;
    }
}

function generate_temporary_password(int $length = 12): string
{
    $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
    $max = strlen($alphabet) - 1;
    $password = '';
    for ($i = 0; $i < $length; $i++) {
        $password .= $alphabet[random_int(0, $max)];
    }
    return $password;
}


function temporary_password_expired(?string $expiresAt): bool
{
    return $expiresAt !== null && $expiresAt !== '' && strtotime($expiresAt) <= time();
}

function ensure_monthly_collection_reports(PDO $pdo): void
{
    $firstPayment = $pdo->query('SELECT MIN(payment_date) FROM payments')->fetchColumn();
    if (!$firstPayment) {
        return;
    }

    $cursor = new DateTimeImmutable(substr((string)$firstPayment, 0, 7) . '-01');
    $currentMonth = new DateTimeImmutable(date('Y-m-01'));

    $summaryStmt = $pdo->prepare(
        'SELECT COALESCE(SUM(amount),0), COUNT(*)
         FROM payments
         WHERE status = "Validated"
           AND payment_date >= :month_start
           AND payment_date < :next_month'
    );
    $upsertStmt = $pdo->prepare(
        'INSERT INTO monthly_collection_reports
            (report_year, report_month, total_validated, validated_count, archived_at)
         VALUES (:report_year, :report_month, :total_validated, :validated_count, NOW())
         ON DUPLICATE KEY UPDATE
            total_validated = VALUES(total_validated),
            validated_count = VALUES(validated_count),
            archived_at = VALUES(archived_at)'
    );

    while ($cursor < $currentMonth) {
        $next = $cursor->modify('+1 month');
        $summaryStmt->execute([
            'month_start' => $cursor->format('Y-m-d'),
            'next_month' => $next->format('Y-m-d'),
        ]);
        [$total, $count] = $summaryStmt->fetch(PDO::FETCH_NUM);

        $upsertStmt->execute([
            'report_year' => (int)$cursor->format('Y'),
            'report_month' => (int)$cursor->format('n'),
            'total_validated' => (float)$total,
            'validated_count' => (int)$count,
        ]);

        $cursor = $next;
    }
}

function reservation_rate_per_hour(string $requesterType, string $time): float
{
    $hour = (int)substr($time, 0, 2);
    $isDay = $hour >= 6 && $hour < 18;
    if ($requesterType === 'Resident') {
        return $isDay ? 150.00 : 450.00;
    }
    return $isDay ? 250.00 : 600.00;
}

function calculate_reservation_charge(string $requesterType, string $start, string $end): array
{
    if (!in_array($requesterType, ['Resident', 'Outside User'], true)) {
        throw new RuntimeException('Invalid requester type.');
    }
    $startMinutes = ((int)substr($start, 0, 2) * 60) + ((int)substr($start, 3, 2));
    $endMinutes = ((int)substr($end, 0, 2) * 60) + ((int)substr($end, 3, 2));
    if ($endMinutes <= $startMinutes) throw new RuntimeException('End time must be later than start time.');
    if ($startMinutes < 360 || $endMinutes > 1320) throw new RuntimeException('Reservations are available only from 6:00 AM to 10:00 PM.');
    if (($startMinutes % 60) !== 0 || ($endMinutes % 60) !== 0) throw new RuntimeException('Reservations must use whole-hour time slots because the facility is charged per hour.');
    $dayRate = $requesterType === 'Resident' ? 150.0 : 250.0;
    $nightRate = $requesterType === 'Resident' ? 450.0 : 600.0;
    $dayEnd = 18 * 60;
    $dayMinutes = max(0, min($endMinutes, $dayEnd) - max($startMinutes, 6 * 60));
    $nightMinutes = max(0, $endMinutes - max($startMinutes, $dayEnd));
    $hours = ($endMinutes - $startMinutes) / 60;
    $dayHours = $dayMinutes / 60;
    $nightHours = $nightMinutes / 60;
    $total = ($dayHours * $dayRate) + ($nightHours * $nightRate);
    $period = $dayHours > 0 && $nightHours > 0 ? 'Day + Night' : ($dayHours > 0 ? 'Day' : 'Night');
    return ['hours'=>$hours,'period'=>$period,'hourly_rate'=>null,'day_hours'=>$dayHours,'night_hours'=>$nightHours,'day_rate'=>$dayRate,'night_rate'=>$nightRate,'total'=>round($total,2)];
}

function mark_completed_reservations(PDO $pdo): void
{
    // A request that was never approved must never become Completed merely
    // because its scheduled time has passed. If it already has a validated
    // payment, cancel it and explicitly preserve refund eligibility.
    $stmt=$pdo->query(
        'SELECT r.reservation_id,r.homeowner_id,r.facility,r.reservation_date,r.start_time,r.status,
                EXISTS(SELECT 1 FROM reservation_payments rp WHERE rp.reservation_id=r.reservation_id AND rp.status="Validated") AS has_paid
         FROM reservations r
         WHERE r.status IN ("Pending","Approved")
           AND TIMESTAMP(r.reservation_date,r.end_time) <= NOW()'
    );
    $rows=$stmt->fetchAll();
    if(!$rows) return;
    $cancel=$pdo->prepare('UPDATE reservations SET status="Cancelled", cancellation_reason=:reason WHERE reservation_id=:id AND status="Pending"');
    $complete=$pdo->prepare('UPDATE reservations SET status="Completed" WHERE reservation_id=:id AND status="Approved"');
    foreach($rows as $r){
        if($r['status']==='Pending'){
            $reason=((int)$r['has_paid']===1)
                ? 'Reservation request expired before Administrator approval. The recorded reservation payment is eligible for refund.'
                : 'Reservation request expired before Administrator approval and was automatically cancelled.';
            $cancel->execute(['reason'=>$reason,'id'=>(int)$r['reservation_id']]);
            if($cancel->rowCount()>0 && !empty($r['homeowner_id'])){
                $message=((int)$r['has_paid']===1)
                    ? 'Your reservation request for '.$r['facility'].' on '.$r['reservation_date'].' was not approved before its scheduled time and has been cancelled. Your recorded reservation payment is eligible for refund; please contact the HOA office for refund processing.'
                    : 'Your reservation request for '.$r['facility'].' on '.$r['reservation_date'].' was not approved before its scheduled time and has been automatically cancelled.';
                notify_homeowner($pdo,(int)$r['homeowner_id'],'Reservation request cancelled',$message,'Warning','Reservations',(int)$r['reservation_id']);
            }
        } else {
            $complete->execute(['id'=>(int)$r['reservation_id']]);
        }
    }
}

function latest_reservation_payment(PDO $pdo, int $reservationId): ?array
{
    $stmt = $pdo->prepare('SELECT * FROM reservation_payments WHERE reservation_id=:reservation_id ORDER BY reservation_payment_id DESC LIMIT 1');
    $stmt->execute(['reservation_id'=>$reservationId]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function record_reservation_payment(PDO $pdo, int $reservationId, ?int $homeownerId, float $amount, string $method, ?string $reference, int $encodedBy): int
{
    if ($method !== 'Cash') throw new RuntimeException('Facility reservation payments are recorded as Cash only. Bank Transfer and Cheque are not accepted in the reservation payment module.');
    $stmt = $pdo->prepare('SELECT status FROM reservations WHERE reservation_id=:id LIMIT 1');
    $stmt->execute(['id'=>$reservationId]);
    $status = $stmt->fetchColumn();
    if (!$status) throw new RuntimeException('Reservation record not found.');
    if (!in_array($status, ['Pending','Approved','Completed'], true)) throw new RuntimeException('Reservation payment can only be recorded for a pending, approved, or completed reservation.');
    if ($amount <= 0) throw new RuntimeException('Reservation payment amount must be greater than zero.');
    $or = 'RES-' . date('YmdHis') . '-' . $reservationId;
    $check=$pdo->prepare('SELECT COUNT(*) FROM reservation_payments WHERE or_number=:or');
    $check->execute(['or'=>$or]);
    if ((int)$check->fetchColumn()>0) $or .= '-' . random_int(10,99);
    $stmt=$pdo->prepare('INSERT INTO reservation_payments(reservation_id,homeowner_id,or_number,payment_date,amount,payment_method,reference_number,status,encoded_by) VALUES(:reservation_id,:homeowner_id,:or,CURDATE(),:amount,:method,:reference,"Validated",:encoded_by)');
    $stmt->execute(['reservation_id'=>$reservationId,'homeowner_id'=>$homeownerId?:null,'or'=>$or,'amount'=>$amount,'method'=>$method,'reference'=>$reference?:null,'encoded_by'=>$encodedBy]);
    return (int)$pdo->lastInsertId();
}


function calculate_homeowner_due_date(PDO $pdo, int $homeownerId, ?string $asOfDate = null, float $additionalAmount = 0.0): array
{
    $stmt = $pdo->prepare('SELECT payment_date, amount FROM payments WHERE homeowner_id=:homeowner_id AND status="Validated" ORDER BY payment_date ASC, payment_id ASC');
    $stmt->execute(['homeowner_id'=>$homeownerId]);
    $rows = $stmt->fetchAll();
    $due = null;
    $creditedMonths = 0;
    foreach ($rows as $row) {
        $months = (int)floor(((float)$row['amount']) / RESIDENT_MONTHLY_DUE);
        if ($months < 1) continue;
        $paymentDate = new DateTimeImmutable(substr((string)$row['payment_date'], 0, 10));
        $base = $due && $due > $paymentDate ? $due : $paymentDate;
        $due = $base->modify('+' . $months . ' month');
        $creditedMonths += $months;
    }
    if ($additionalAmount >= RESIDENT_MONTHLY_DUE) {
        $months = (int)floor($additionalAmount / RESIDENT_MONTHLY_DUE);
        $base = $due ?: new DateTimeImmutable($asOfDate ?: date('Y-m-d'));
        $due = $base->modify('+' . $months . ' month');
        $creditedMonths += $months;
    }
    if (!$due) {
        $base = new DateTimeImmutable($asOfDate ?: date('Y-m-d'));
        $due = $base->modify('+1 month');
    }
    return ['due_date'=>$due->format('Y-m-d'),'credited_months'=>$creditedMonths];
}

function notification_exists_for_record(PDO $pdo, int $userId, string $title, int $recordId, ?string $type = null, ?string $since = null): bool
{
    $sql = 'SELECT COUNT(*) FROM notifications WHERE user_id=:user_id AND title=:title AND record_id=:record_id';
    $params = ['user_id'=>$userId, 'title'=>$title, 'record_id'=>$recordId];
    if ($type !== null) {
        $sql .= ' AND type=:type';
        $params['type'] = $type;
    }
    if ($since !== null) {
        $sql .= ' AND created_at >= :since';
        $params['since'] = $since;
    }
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return (int)$stmt->fetchColumn() > 0;
}

function process_monthly_due_statuses(PDO $pdo): void
{
    // A regular validated payment is the source of truth for monthly dues.
    // The resident receives one reminder after the due date, with a seven-day
    // grace period. If no qualifying payment is validated by the end of the
    // grace period, the homeowner becomes Delinquent and both staff roles are
    // notified. A qualifying validated payment restores Active status.
    $rows = $pdo->query(
        'SELECT h.homeowner_id, h.household_name, h.membership_status, h.user_id
         FROM homeowners h
         INNER JOIN users u ON u.user_id=h.user_id
         WHERE u.status="Active" AND h.membership_status <> "Inactive"'
    )->fetchAll();

    $today = new DateTimeImmutable(date('Y-m-d'));

    foreach ($rows as $homeowner) {
        $homeownerId = (int)$homeowner['homeowner_id'];
        if ($homeownerId < 1) continue;

        $dueInfo = calculate_homeowner_due_date($pdo, $homeownerId, $today->format('Y-m-d'));
        $dueDate = new DateTimeImmutable($dueInfo['due_date']);
        if ($today <= $dueDate) {
            // Do not automatically clear Delinquent here. A Delinquent label may
            // have been explicitly set by staff, and it must remain visible until
            // staff changes it or a validated payment is processed. Payment
            // validation uses refresh_homeowner_payment_status() as the explicit
            // restoration path.
            continue;
        }

        $graceEnd = $dueDate->modify('+7 days');
        if ($today <= $graceEnd) {
            $title = 'Monthly Due Reminder';
            $uid = (int)$homeowner['user_id'];
            if ($uid > 0 && !notification_exists_for_record($pdo, $uid, $title, $homeownerId, 'Warning', $dueDate->format('Y-m-d 00:00:00'))) {
                create_notification(
                    $pdo,
                    $uid,
                    $title,
                    'Your monthly due was due on '.$dueDate->format('F j, Y').'. You have 7 days to settle your monthly due before your membership status is changed to Delinquent.',
                    'Warning',
                    'Collections',
                    $homeownerId
                );
            }
            continue;
        }

        if ($homeowner['membership_status'] !== 'Delinquent') {
            $stmt = $pdo->prepare('UPDATE homeowners SET membership_status="Delinquent" WHERE homeowner_id=:homeowner_id');
            $stmt->execute(['homeowner_id'=>$homeownerId]);
            if ($stmt->rowCount() > 0) {
                notify_homeowner($pdo, $homeownerId, 'Monthly Due Overdue', 'Your monthly due has remained unpaid for 7 days after the due date. Your membership status is now Delinquent.', 'Danger', 'Collections', $homeownerId);
                notify_staff($pdo, 'Resident Monthly Due Overdue', $homeowner['household_name'].' has not paid their monthly due within the 7-day grace period. Their membership status is now Delinquent.', 'Danger', 'Collections', $homeownerId);
            }
        }
    }
}

function refresh_homeowner_payment_status(PDO $pdo, int $homeownerId): bool
{
    if ($homeownerId < 1) return false;
    $stmt = $pdo->prepare('SELECT membership_status FROM homeowners WHERE homeowner_id=:homeowner_id LIMIT 1');
    $stmt->execute(['homeowner_id'=>$homeownerId]);
    $status = $stmt->fetchColumn();
    if ($status === false || $status === 'Inactive') return false;

    $today = new DateTimeImmutable(date('Y-m-d'));
    $dueInfo = calculate_homeowner_due_date($pdo, $homeownerId, $today->format('Y-m-d'));
    $dueDate = new DateTimeImmutable($dueInfo['due_date']);

    if ($dueDate >= $today && $status === 'Delinquent') {
        $stmt = $pdo->prepare('UPDATE homeowners SET membership_status="Active" WHERE homeowner_id=:homeowner_id AND membership_status="Delinquent"');
        $stmt->execute(['homeowner_id'=>$homeownerId]);
        return $stmt->rowCount() > 0;
    }
    return false;
}

function current_month_collection_total(PDO $pdo): float
{
    $start = new DateTimeImmutable(date('Y-m-01'));
    $next = $start->modify('+1 month');
    $stmt = $pdo->prepare(
        'SELECT COALESCE(SUM(amount),0)
         FROM payments
         WHERE status = "Validated"
           AND payment_date >= :month_start
           AND payment_date < :next_month'
    );
    $stmt->execute([
        'month_start' => $start->format('Y-m-d'),
        'next_month' => $next->format('Y-m-d'),
    ]);
    return (float)$stmt->fetchColumn();
}

function mask_contact_value(?string $value, string $type): string
{
    $value = trim((string)$value);
    if ($value === '') return '';
    if ($type === 'email') {
        [$local, $domain] = array_pad(explode('@', $value, 2), 2, '');
        if ($domain === '') return '••••';
        $visible = substr($local, 0, 1);
        return $visible . str_repeat('•', max(2, min(6, strlen($local) - 1))) . '@' . $domain;
    }
    $digits = preg_replace('/\D+/', '', $value);
    if ($digits === '') return '••••';
    return str_repeat('•', max(0, strlen($digits) - 4)) . substr($digits, -4);
}

function send_2fa_email_code(string $email, string $code): bool
{
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return false;
    $subject = APP_NAME . ' - Security Verification Code';
    $message = "Your Fairmont Park HOA verification code is {$code}.\n\nThis code expires in " . TWO_FACTOR_CODE_MINUTES . " minutes. If you did not request this code, please contact the HOA office.\n\n" . APP_FULL_NAME;

    $smtpHost = trim((string)TWO_FACTOR_SMTP_HOST);
    if ($smtpHost !== '') {
        return smtp_send_text_email($email, $subject, $message);
    }

    $from = trim((string)TWO_FACTOR_EMAIL_FROM);
    if ($from === '' || !filter_var($from, FILTER_VALIDATE_EMAIL)) $from = 'no-reply@localhost';
    $headers = "MIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nFrom: " . $from . "\r\n";
    return @mail($email, $subject, $message, $headers);
}

function smtp_read_response($socket): array
{
    $lines = [];
    while (($line = fgets($socket, 515)) !== false) {
        $lines[] = trim($line);
        if (isset($line[3]) && $line[3] === ' ') break;
    }
    $last = end($lines) ?: '';
    return [(int)substr($last, 0, 3), implode("\n", $lines)];
}

function smtp_expect($socket, array $codes): bool
{
    [$code] = smtp_read_response($socket);
    return in_array($code, $codes, true);
}

function smtp_command($socket, string $command, array $codes): bool
{
    fwrite($socket, $command . "\r\n");
    return smtp_expect($socket, $codes);
}

function smtp_send_text_email(string $to, string $subject, string $body): bool
{
    $host = trim((string)TWO_FACTOR_SMTP_HOST);
    $port = (int)TWO_FACTOR_SMTP_PORT;
    $encryption = strtolower(trim((string)TWO_FACTOR_SMTP_ENCRYPTION));
    $username = (string)TWO_FACTOR_SMTP_USERNAME;
    $password = (string)TWO_FACTOR_SMTP_PASSWORD;
    $from = trim((string)TWO_FACTOR_EMAIL_FROM);
    if ($host === '' || $port < 1 || $from === '' || !filter_var($from, FILTER_VALIDATE_EMAIL)) return false;

    $transport = $encryption === 'ssl' ? 'ssl://' . $host : $host;
    $errno = 0; $errstr = '';
    $socket = @fsockopen($transport, $port, $errno, $errstr, 10);
    if (!$socket) return false;
    stream_set_timeout($socket, 10);
    try {
        if (!smtp_expect($socket, [220])) return false;
        $hostname = $_SERVER['SERVER_NAME'] ?? 'localhost';
        if (!smtp_command($socket, 'EHLO ' . $hostname, [250])) return false;
        if ($encryption === 'tls') {
            if (!smtp_command($socket, 'STARTTLS', [220])) return false;
            if (!stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) return false;
            if (!smtp_command($socket, 'EHLO ' . $hostname, [250])) return false;
        }
        if ($username !== '') {
            if (!smtp_command($socket, 'AUTH LOGIN', [334])) return false;
            if (!smtp_command($socket, base64_encode($username), [334])) return false;
            if (!smtp_command($socket, base64_encode($password), [235])) return false;
        }
        if (!smtp_command($socket, 'MAIL FROM:<' . $from . '>', [250])) return false;
        if (!smtp_command($socket, 'RCPT TO:<' . $to . '>', [250,251])) return false;
        if (!smtp_command($socket, 'DATA', [354])) return false;
        $headers = 'From: ' . $from . "\r\n" . 'To: ' . $to . "\r\n" . 'Subject: ' . $subject . "\r\n" . 'MIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8';
        $payload = str_replace(["\r\n", "\r", "\n"], "\r\n", $headers . "\r\n\r\n" . $body);
        $payload = preg_replace('/^\./m', '..', $payload) ?? $payload;
        fwrite($socket, $payload . "\r\n.\r\n");
        if (!smtp_expect($socket, [250])) return false;
        smtp_command($socket, 'QUIT', [221]);
        return true;
    } finally {
        fclose($socket);
    }
}

function save_uploaded_payment_proof(array $file): string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Please select a proof of payment image.');
    }
    if (($file['size'] ?? 0) > 10 * 1024 * 1024) {
        throw new RuntimeException('The proof of payment image must not exceed 10 MB.');
    }
    $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    $finfo = new finfo(FILEINFO_MIME_TYPE); $mime = $finfo->file($file['tmp_name']);
    if (!isset($allowed[$mime])) throw new RuntimeException('Unsupported proof image. Use JPG, PNG, or WEBP.');
    $dimensions = @getimagesize($file['tmp_name']);
    if (!$dimensions || (int)$dimensions[0] > 6000 || (int)$dimensions[1] > 6000 || ((int)$dimensions[0]*(int)$dimensions[1]) > 25000000) {
        throw new RuntimeException('The proof image resolution is too large. Use an image up to 6000 × 6000 pixels and 25 megapixels.');
    }
    $directory = UPLOAD_DIR . 'payment-proofs/';
    if (!is_dir($directory) && !mkdir($directory, 0755, true)) throw new RuntimeException('Unable to create the payment proof directory.');
    $stored = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
    if (!move_uploaded_file($file['tmp_name'], $directory . $stored)) throw new RuntimeException('The proof image could not be saved.');
    return 'payment-proofs/' . $stored;
}

function create_notification(PDO $pdo, int $userId, string $title, string $message, string $type='Info', ?string $module=null, ?int $recordId=null): void
{
    if ($userId < 1) return;
    $stmt = $pdo->prepare('INSERT INTO notifications (user_id,title,message,type,module,record_id,is_read,created_at) VALUES (:user_id,:title,:message,:type,:module,:record_id,0,NOW())');
    $stmt->execute(['user_id'=>$userId,'title'=>$title,'message'=>$message,'type'=>$type,'module'=>$module,'record_id'=>$recordId]);
}

function notify_staff(PDO $pdo, string $title, string $message, string $type='Info', ?string $module=null, ?int $recordId=null): void
{
    $stmt = $pdo->query('SELECT user_id FROM users WHERE role IN ("Administrator","Clerk") AND status="Active"');
    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $userId) create_notification($pdo,(int)$userId,$title,$message,$type,$module,$recordId);
}

function notify_homeowner(PDO $pdo, int $homeownerId, string $title, string $message, string $type='Info', ?string $module=null, ?int $recordId=null): void
{
    $stmt=$pdo->prepare('SELECT user_id FROM homeowners WHERE homeowner_id=:id LIMIT 1'); $stmt->execute(['id'=>$homeownerId]);
    $uid=(int)$stmt->fetchColumn(); if ($uid>0) create_notification($pdo,$uid,$title,$message,$type,$module,$recordId);
}

function unread_notification_count(PDO $pdo, int $userId): int
{
    $stmt=$pdo->prepare('SELECT COUNT(*) FROM notifications WHERE user_id=:user_id AND is_read=0'); $stmt->execute(['user_id'=>$userId]); return (int)$stmt->fetchColumn();
}

function send_2fa_sms_code(string $mobile, string $code): bool
{
    $url = trim((string)TWO_FACTOR_SMS_API_URL);
    $token = trim((string)TWO_FACTOR_SMS_API_TOKEN);
    if ($url === '' || $token === '' || trim($mobile) === '' || !function_exists('curl_init')) return false;

    $payload = json_encode([
        'to' => $mobile,
        'message' => APP_NAME . ': Your verification code is ' . $code . '. It expires in ' . TWO_FACTOR_CODE_MINUTES . ' minutes.',
        'sender' => TWO_FACTOR_SMS_SENDER,
    ]);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Authorization: Bearer ' . $token],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => 10,
    ]);
    curl_exec($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $http >= 200 && $http < 300;
}

function user_two_factor_contacts(PDO $pdo, int $userId): array
{
    $stmt = $pdo->prepare(
        'SELECT u.user_id, u.username, u.email AS user_email, u.mobile_number, u.account_source,
                u.two_factor_enabled, h.email AS homeowner_email, h.contact_number AS homeowner_mobile
         FROM users u
         LEFT JOIN homeowners h ON h.user_id=u.user_id
         WHERE u.user_id=:user_id LIMIT 1'
    );
    $stmt->execute(['user_id'=>$userId]);
    $row = $stmt->fetch() ?: [];
    $isHomeownerAccount = (($row['account_source'] ?? '') === 'Homeowner');
    $email = trim((string)($isHomeownerAccount ? ($row['homeowner_email'] ?? '') : ($row['user_email'] ?: ($row['homeowner_email'] ?? ''))));
    $mobile = trim((string)($isHomeownerAccount ? ($row['homeowner_mobile'] ?? '') : ($row['mobile_number'] ?: ($row['homeowner_mobile'] ?? ''))));
    return [
        'enabled' => (bool)($row['two_factor_enabled'] ?? 0),
        'email' => $email,
        'mobile' => $mobile,
        'email_masked' => mask_contact_value($email, 'email'),
        'mobile_masked' => mask_contact_value($mobile, 'mobile'),
    ];
}

function create_and_send_2fa_challenge(PDO $pdo, int $userId): array
{
    $contacts = user_two_factor_contacts($pdo, $userId);
    if (!$contacts['enabled'] || ($contacts['email'] === '' && $contacts['mobile'] === '')) {
        return ['sent'=>false, 'method'=>'', 'contacts'=>$contacts];
    }

    $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $emailSent = $contacts['email'] !== '' ? send_2fa_email_code($contacts['email'], $code) : false;
    $smsSent = $contacts['mobile'] !== '' ? send_2fa_sms_code($contacts['mobile'], $code) : false;

    $method = $emailSent && $smsSent ? 'Email + SMS' : ($emailSent ? 'Email' : ($smsSent ? 'SMS' : ''));
    if ($method === '') return ['sent'=>false, 'method'=>'', 'contacts'=>$contacts];

    $pdo->prepare('DELETE FROM login_2fa_challenges WHERE user_id=:user_id OR expires_at < NOW()')->execute(['user_id'=>$userId]);
    $stmt = $pdo->prepare(
        'INSERT INTO login_2fa_challenges (user_id,code_hash,delivery_method,expires_at)
         VALUES (:user_id,:code_hash,:delivery_method,DATE_ADD(NOW(), INTERVAL ' . (int)TWO_FACTOR_CODE_MINUTES . ' MINUTE))'
    );
    $stmt->execute(['user_id'=>$userId,'code_hash'=>password_hash($code, PASSWORD_DEFAULT),'delivery_method'=>$method]);
    return ['sent'=>true,'method'=>$method,'contacts'=>$contacts];
}
