<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    // Harden the PHP session before it is created. HTTPS deployments receive
    // the Secure flag automatically; SameSite=Lax reduces cross-site request exposure.
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    $secureCookie = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ((int)($_SERVER['SERVER_PORT'] ?? 0) === 443);
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $secureCookie,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function is_logged_in(): bool
{
    return isset($_SESSION['user_id'], $_SESSION['role']);
}

function require_login(): void
{
    if (!is_logged_in()) {
        header('Location: ../login.php');
        exit;
    }

    // Automatically sign out after 30 minutes of inactivity.
    $timeoutSeconds = 30 * 60;
    $lastActivity = (int)($_SESSION['last_activity'] ?? 0);
    if ($lastActivity > 0 && (time() - $lastActivity) >= $timeoutSeconds) {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params['path'], $params['domain'], $params['secure'], $params['httponly']
            );
        }
        session_destroy();
        header('Location: ../login.php?timeout=1');
        exit;
    }

    $_SESSION['last_activity'] = time();
}


function require_role(string ...$allowedRoles): void
{
    require_login();

    // Keep monthly membership status and due reminders current for every role
    // before the requested module reads homeowner data.
    if (function_exists('process_monthly_due_statuses')) {
        process_monthly_due_statuses($GLOBALS['pdo']);
    }

    if (!in_array($_SESSION['role'], $allowedRoles, true)) {
        http_response_code(403);
        exit('403 Forbidden: You are not authorized to access this page.');
    }
}

function redirect_by_role(): void
{
    switch ($_SESSION['role'] ?? '') {
        case 'Administrator':
            header('Location: admin/dashboard.php');
            break;
        case 'Clerk':
            header('Location: clerk/dashboard.php');
            break;
        case 'Resident':
            header('Location: resident/dashboard.php');
            break;
        default:
            header('Location: login.php');
    }
    exit;
}

function current_user_id(): int
{
    return (int)($_SESSION['user_id'] ?? 0);
}

function current_role(): string
{
    return (string)($_SESSION['role'] ?? '');
}

function current_username(): string
{
    return (string)($_SESSION['username'] ?? '');
}
