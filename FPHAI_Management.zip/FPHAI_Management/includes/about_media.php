<?php
// Shared About FPHAI media helpers.
