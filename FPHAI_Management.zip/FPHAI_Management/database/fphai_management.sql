CREATE DATABASE IF NOT EXISTS fphai_management
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE fphai_management;

CREATE TABLE users (
    user_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(150) NULL,
    mobile_number VARCHAR(50) NULL,
    two_factor_enabled TINYINT(1) NOT NULL DEFAULT 1,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('Administrator', 'Clerk', 'Resident') NOT NULL,
    status ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
    account_source ENUM('Manual', 'Homeowner') NOT NULL DEFAULT 'Manual',
    must_change_password TINYINT(1) NOT NULL DEFAULT 0,
    temporary_password_expires_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE homeowners (
    homeowner_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NULL UNIQUE,
    household_name VARCHAR(150) NOT NULL,
    address VARCHAR(255) NOT NULL,
    street VARCHAR(100) NULL,
    block VARCHAR(50) NULL,
    lot VARCHAR(50) NULL,
    contact_number VARCHAR(50) NULL,
    email VARCHAR(150) NULL,
    no_of_vehicles INT UNSIGNED NOT NULL DEFAULT 0,
    no_of_households INT UNSIGNED NOT NULL DEFAULT 1,
    profile_image_path VARCHAR(500) NULL,
    membership_status ENUM('Active', 'Inactive', 'Delinquent') NOT NULL DEFAULT 'Active',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_homeowners_user
        FOREIGN KEY (user_id) REFERENCES users(user_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE payments (
    payment_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    homeowner_id INT UNSIGNED NOT NULL,
    or_number VARCHAR(100) NOT NULL UNIQUE,
    payment_date DATE NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    payment_method ENUM('Cash', 'Bank Transfer', 'Cheque') NOT NULL,
    reference_number VARCHAR(150) NULL,
    description VARCHAR(255) NULL,
    proof_image_path VARCHAR(500) NULL,
    status ENUM('Pending', 'Validated', 'Rejected') NOT NULL DEFAULT 'Pending',
    encoded_by INT UNSIGNED NOT NULL,
    validated_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_payments_homeowner
        FOREIGN KEY (homeowner_id) REFERENCES homeowners(homeowner_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    CONSTRAINT fk_payments_encoded_by
        FOREIGN KEY (encoded_by) REFERENCES users(user_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    CONSTRAINT fk_payments_validated_by
        FOREIGN KEY (validated_by) REFERENCES users(user_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE reservations (
    reservation_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    homeowner_id INT UNSIGNED NULL,
    facility ENUM('Court 1','Court 2') NOT NULL DEFAULT 'Court 1',
    requester_name VARCHAR(150) NOT NULL,
    requester_type ENUM('Resident', 'Outside User') NOT NULL,
    requester_affiliation VARCHAR(200) NULL,
    requester_contact VARCHAR(50) NULL,
    requester_email VARCHAR(150) NULL,
    reservation_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    payment_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    purpose VARCHAR(255) NULL,
    status ENUM('Pending', 'Approved', 'Rejected', 'Cancelled', 'Completed') NOT NULL DEFAULT 'Pending',
    cancellation_reason VARCHAR(500) NULL,
    requested_by INT UNSIGNED NULL,
    approved_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_reservations_homeowner
        FOREIGN KEY (homeowner_id) REFERENCES homeowners(homeowner_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE,
    CONSTRAINT fk_reservations_requested_by
        FOREIGN KEY (requested_by) REFERENCES users(user_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE,
    CONSTRAINT fk_reservations_approved_by
        FOREIGN KEY (approved_by) REFERENCES users(user_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE,
    INDEX idx_reservation_schedule (reservation_date, start_time, end_time, status)
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS reservation_payments (
    reservation_payment_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    reservation_id INT UNSIGNED NOT NULL,
    homeowner_id INT UNSIGNED NULL,
    or_number VARCHAR(100) NOT NULL UNIQUE,
    payment_date DATE NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    payment_method ENUM('Cash','Bank Transfer','Cheque') NOT NULL,
    reference_number VARCHAR(150) NULL,
    status ENUM('Pending','Validated','Rejected') NOT NULL DEFAULT 'Validated',
    encoded_by INT UNSIGNED NOT NULL,
    validated_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_reservation_payments_reservation FOREIGN KEY (reservation_id) REFERENCES reservations(reservation_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_reservation_payments_homeowner FOREIGN KEY (homeowner_id) REFERENCES homeowners(homeowner_id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_reservation_payments_encoded_by FOREIGN KEY (encoded_by) REFERENCES users(user_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_reservation_payments_validated_by FOREIGN KEY (validated_by) REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_reservation_payments_homeowner(homeowner_id,payment_date,status),
    INDEX idx_reservation_payments_reservation(reservation_id,status)
) ENGINE=InnoDB;

CREATE TABLE documents (
    document_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    category VARCHAR(100) NOT NULL,
    description TEXT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    uploaded_by INT UNSIGNED NOT NULL,
    visibility ENUM('Administrator', 'Clerk', 'Resident', 'All') NOT NULL DEFAULT 'All',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_documents_uploaded_by
        FOREIGN KEY (uploaded_by) REFERENCES users(user_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE notifications (
    notification_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(30) NOT NULL DEFAULT 'Info',
    module VARCHAR(100) NULL,
    record_id INT UNSIGNED NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_notifications_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_notifications_user_read (user_id,is_read,created_at)
) ENGINE=InnoDB;

CREATE TABLE reports (
    report_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    report_type VARCHAR(100) NOT NULL,
    generated_by INT UNSIGNED NOT NULL,
    generated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_reports_generated_by
        FOREIGN KEY (generated_by) REFERENCES users(user_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE monthly_collection_reports (
    monthly_report_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    report_year SMALLINT UNSIGNED NOT NULL,
    report_month TINYINT UNSIGNED NOT NULL,
    total_validated DECIMAL(14,2) NOT NULL DEFAULT 0.00,
    validated_count INT UNSIGNED NOT NULL DEFAULT 0,
    archived_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_monthly_collection (report_year, report_month)
) ENGINE=InnoDB;

CREATE TABLE login_attempts (
    attempt_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    failed_attempts INT UNSIGNED NOT NULL DEFAULT 0,
    locked_until DATETIME NULL,
    last_attempt_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_login_attempt (username, ip_address),
    INDEX idx_login_attempt_ip (ip_address),
    INDEX idx_login_attempt_lock (locked_until)
) ENGINE=InnoDB;

CREATE TABLE login_2fa_challenges (
    challenge_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    code_hash VARCHAR(255) NOT NULL,
    delivery_method ENUM('Email','SMS','Email + SMS') NOT NULL,
    expires_at DATETIME NOT NULL,
    attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
    verified_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_2fa_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_2fa_user (user_id),
    INDEX idx_2fa_expires (expires_at)
) ENGINE=InnoDB;



CREATE TABLE about_content (
    about_id TINYINT UNSIGNED PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    body TEXT NOT NULL,
    gallery_mode ENUM('slideshow','album','collage') NOT NULL DEFAULT 'album',
    updated_by INT UNSIGNED NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_about_updated_by FOREIGN KEY (updated_by) REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE about_media (
    media_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    media_type ENUM('image') NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    original_name VARCHAR(255) NULL,
    sort_order INT NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    uploaded_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_about_media_uploaded_by FOREIGN KEY (uploaded_by) REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_about_media_display (is_active, sort_order, media_id)
) ENGINE=InnoDB;

CREATE TABLE login_slides (
    slide_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NULL,
    image_path VARCHAR(500) NOT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    uploaded_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_login_slides_uploaded_by FOREIGN KEY (uploaded_by) REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_login_slides_active (is_active, sort_order)
) ENGINE=InnoDB;

INSERT INTO about_content (about_id, title, body) VALUES
(1, 'About Fairmont Park Homeowners'' Association, Inc.',
 'Fairmont Park Homeowners'' Association, Inc. (FPHAI) is a non-profit, non-government homeowners association located at Boles Street, Fairmont North Fairview, Quezon City. The Association works to maintain a peaceful, orderly, and well-managed residential community while supporting the needs of its homeowners and members.

FPHAI manages homeowner and membership records, monthly dues collection, facility reservations, community announcements, clearances, and other day-to-day association services. The Association also coordinates selected community programs and helps maintain shared facilities such as the basketball court.

The web-based centralized management system is designed to help FPHAI keep records organized, improve collection reporting, and manage facility reservations more efficiently while providing residents with easier access to their own information and selected HOA resources.')
ON DUPLICATE KEY UPDATE title=VALUES(title);

CREATE TABLE audit_logs (
    log_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NULL,
    action VARCHAR(100) NOT NULL,
    module VARCHAR(100) NOT NULL,
    record_id INT UNSIGNED NULL,
    details TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_audit_user
        FOREIGN KEY (user_id) REFERENCES users(user_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE,
    INDEX idx_audit_created_at (created_at),
    INDEX idx_audit_user (user_id),
    INDEX idx_audit_module (module)
) ENGINE=InnoDB;
