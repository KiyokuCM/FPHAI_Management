USE fphai_management;

-- Security: force homeowner-created accounts to change their temporary password.
ALTER TABLE users
    ADD COLUMN IF NOT EXISTS account_source ENUM('Manual', 'Homeowner') NOT NULL DEFAULT 'Manual' AFTER status,
    ADD COLUMN IF NOT EXISTS must_change_password TINYINT(1) NOT NULL DEFAULT 0 AFTER status,
    ADD COLUMN IF NOT EXISTS temporary_password_expires_at DATETIME NULL AFTER must_change_password;

-- Homeowner profile details.
ALTER TABLE homeowners
    ADD COLUMN IF NOT EXISTS no_of_vehicles INT UNSIGNED NOT NULL DEFAULT 0 AFTER email,
    ADD COLUMN IF NOT EXISTS no_of_households INT UNSIGNED NOT NULL DEFAULT 1 AFTER no_of_vehicles,
    ADD COLUMN IF NOT EXISTS profile_image_path VARCHAR(500) NULL AFTER no_of_households;

-- Progressive login throttling. Records are keyed by username + client IP.
CREATE TABLE IF NOT EXISTS login_attempts (
    attempt_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    failed_attempts INT UNSIGNED NOT NULL DEFAULT 0,
    locked_until DATETIME NULL,
    last_attempt_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_login_attempt (username, ip_address),
    INDEX idx_login_attempt_ip (ip_address),
    INDEX idx_login_attempt_lock (locked_until)
) ENGINE=InnoDB;

-- Monthly collection archive. The payment records remain the source of detail;
-- this table keeps the month-by-month summary so the dashboard can reset safely.
CREATE TABLE IF NOT EXISTS monthly_collection_reports (
    monthly_report_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    report_year SMALLINT UNSIGNED NOT NULL,
    report_month TINYINT UNSIGNED NOT NULL,
    total_validated DECIMAL(14,2) NOT NULL DEFAULT 0.00,
    validated_count INT UNSIGNED NOT NULL DEFAULT 0,
    archived_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_monthly_collection (report_year, report_month)
) ENGINE=InnoDB;


-- Audit trail required by the application. This also makes the migration safe when the base database was created without this table.
CREATE TABLE IF NOT EXISTS audit_logs (
    log_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NULL,
    action VARCHAR(100) NOT NULL,
    module VARCHAR(100) NOT NULL,
    record_id INT UNSIGNED NULL,
    details TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_audit_user
        FOREIGN KEY (user_id) REFERENCES users(user_id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_audit_created_at (created_at),
    INDEX idx_audit_user (user_id),
    INDEX idx_audit_module (module)
) ENGINE=InnoDB;

-- About section and editable login background slideshow.
CREATE TABLE IF NOT EXISTS about_content (
    about_id TINYINT UNSIGNED PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    body TEXT NOT NULL,
    updated_by INT UNSIGNED NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_about_updated_by FOREIGN KEY (updated_by) REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

INSERT INTO about_content (about_id, title, body) VALUES
(1, 'About Fairmont Park Homeowners'' Association, Inc.',
 'Fairmont Park Homeowners'' Association, Inc. (FPHAI) is a non-profit, non-government homeowners association located at Boles Street, Fairmont North Fairview, Quezon City. The Association works to maintain a peaceful, orderly, and well-managed residential community while supporting the needs of its homeowners and members.

FPHAI manages homeowner and membership records, monthly dues collection, facility reservations, community announcements, clearances, and other day-to-day association services. The Association also coordinates selected community programs and helps maintain shared facilities such as the basketball court.

The web-based centralized management system is designed to help FPHAI keep records organized, improve collection reporting, and manage facility reservations more efficiently while providing residents with easier access to their own information and selected HOA resources.')
ON DUPLICATE KEY UPDATE title=VALUES(title);

CREATE TABLE IF NOT EXISTS login_slides (
    slide_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NULL,
    image_path VARCHAR(500) NOT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    uploaded_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_login_slides_uploaded_by FOREIGN KEY (uploaded_by) REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_login_slides_active (is_active, sort_order)
) ENGINE=InnoDB;

ALTER TABLE reservations ADD COLUMN IF NOT EXISTS requester_affiliation VARCHAR(200) NULL AFTER requester_type;
ALTER TABLE reservations ADD COLUMN IF NOT EXISTS requester_contact VARCHAR(50) NULL AFTER requester_affiliation;
ALTER TABLE reservations ADD COLUMN IF NOT EXISTS requester_email VARCHAR(150) NULL AFTER requester_contact;


-- Reservation facility and payment amount. Existing records default to Court 1 / zero amount until reviewed.
ALTER TABLE reservations
    ADD COLUMN IF NOT EXISTS facility ENUM('Court 1','Court 2') NOT NULL DEFAULT 'Court 1' AFTER homeowner_id,
    ADD COLUMN IF NOT EXISTS payment_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER end_time;

-- The system now accepts only Cash, Bank Transfer, and Cheque. Legacy GCash/Other entries are retained as Bank Transfer for continuity.
UPDATE payments SET payment_method='Bank Transfer' WHERE payment_method IN ('GCash','Other');
ALTER TABLE payments MODIFY COLUMN payment_method ENUM('Cash','Bank Transfer','Cheque') NOT NULL;

-- Phase C preparation: About FPHAI media gallery. Public PDF documents are represented by uploaded page images.
ALTER TABLE about_content
    ADD COLUMN IF NOT EXISTS gallery_mode ENUM('slideshow','album','collage') NOT NULL DEFAULT 'album' AFTER body;

CREATE TABLE IF NOT EXISTS about_media (
    media_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    media_type ENUM('image','pdf') NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    original_name VARCHAR(255) NULL,
    sort_order INT NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    uploaded_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_about_media_uploaded_by FOREIGN KEY (uploaded_by) REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_about_media_display (is_active, sort_order, media_id)
) ENGINE=InnoDB;

-- Existing About media is now image-only. Any existing PDF rows should be reviewed manually and replaced with page images.

-- Phase C: optional two-factor authentication. 2FA is required only when the account
-- has enabled it and at least one usable email/mobile contact is available.
ALTER TABLE users
    ADD COLUMN IF NOT EXISTS email VARCHAR(150) NULL AFTER username,
    ADD COLUMN IF NOT EXISTS mobile_number VARCHAR(50) NULL AFTER email,
    ADD COLUMN IF NOT EXISTS two_factor_enabled TINYINT(1) NOT NULL DEFAULT 1 AFTER mobile_number;

CREATE TABLE IF NOT EXISTS login_2fa_challenges (
    challenge_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    code_hash VARCHAR(255) NOT NULL,
    delivery_method ENUM('Email','SMS','Email + SMS') NOT NULL,
    expires_at DATETIME NOT NULL,
    attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
    verified_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_2fa_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_2fa_user (user_id),
    INDEX idx_2fa_expires (expires_at)
) ENGINE=InnoDB;

-- Phase C3: payment proof and resident/staff notifications
ALTER TABLE payments ADD COLUMN IF NOT EXISTS proof_image_path VARCHAR(500) NULL AFTER description;

CREATE TABLE IF NOT EXISTS notifications (
    notification_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(30) NOT NULL DEFAULT 'Info',
    module VARCHAR(100) NULL,
    record_id INT UNSIGNED NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_notifications_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_notifications_user_read (user_id,is_read,created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS reservation_payments (
    reservation_payment_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    reservation_id INT UNSIGNED NOT NULL,
    homeowner_id INT UNSIGNED NULL,
    or_number VARCHAR(100) NOT NULL UNIQUE,
    payment_date DATE NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    payment_method ENUM('Cash','Bank Transfer','Cheque') NOT NULL,
    reference_number VARCHAR(150) NULL,
    status ENUM('Pending','Validated','Rejected') NOT NULL DEFAULT 'Validated',
    encoded_by INT UNSIGNED NOT NULL,
    validated_by INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_reservation_payments_reservation FOREIGN KEY (reservation_id) REFERENCES reservations(reservation_id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_reservation_payments_homeowner FOREIGN KEY (homeowner_id) REFERENCES homeowners(homeowner_id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_reservation_payments_encoded_by FOREIGN KEY (encoded_by) REFERENCES users(user_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_reservation_payments_validated_by FOREIGN KEY (validated_by) REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_reservation_payments_homeowner(homeowner_id,payment_date,status),
    INDEX idx_reservation_payments_reservation(reservation_id,status)
) ENGINE=InnoDB;


-- Phase C9: reservation cancellation reason for all user types.
ALTER TABLE reservations ADD COLUMN IF NOT EXISTS cancellation_reason VARCHAR(500) NULL AFTER status;


-- Remove the retired system-level role. Existing accounts using it are converted to Administrator.
ALTER TABLE users MODIFY role ENUM('Administrator','Clerk','Resident') NOT NULL;

-- C15: separate street from compact house/lot address entry.
ALTER TABLE homeowners ADD COLUMN IF NOT EXISTS street VARCHAR(100) NULL AFTER address;
