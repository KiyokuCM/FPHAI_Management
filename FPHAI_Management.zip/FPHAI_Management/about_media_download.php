<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';

$id = (int)($_GET['id'] ?? 0);
if ($id < 1) { http_response_code(404); exit('File not found.'); }
$stmt = $pdo->prepare('SELECT title, media_type, file_path, original_name FROM about_media WHERE media_id=:id AND is_active=1 LIMIT 1');
$stmt->execute(['id'=>$id]);
$media = $stmt->fetch();
if (!$media || $media['media_type'] !== 'image') { http_response_code(404); exit('File not found.'); }

$download = isset($_GET['download']) && $_GET['download'] === '1';
if ($download && (!is_logged_in() || !in_array(current_role(), ['Administrator','Clerk'], true))) {
    http_response_code(403);
    exit('403 Forbidden: image downloads are available to Administrator and Clerk accounts only.');
}

$path = UPLOAD_DIR . $media['file_path'];
if (!is_file($path)) { http_response_code(404); exit('File not found.'); }
$finfo = new finfo(FILEINFO_MIME_TYPE);
$mime = $finfo->file($path) ?: 'application/octet-stream';
$filename = basename($media['original_name'] ?: ($media['title'].'.jpg'));
header('Content-Type: '.$mime);
header('Content-Length: '.filesize($path));
header('Content-Disposition: '.($download ? 'attachment' : 'inline').'; filename="'.str_replace('"','', $filename).'"');
header('X-Content-Type-Options: nosniff');
readfile($path);
exit;
