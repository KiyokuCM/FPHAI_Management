<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';
require_role('Administrator','Clerk');

$homeownerId=(int)($_GET['homeowner_id']??0);
$stmt=$pdo->prepare('SELECT * FROM homeowners WHERE homeowner_id=:id LIMIT 1');
$stmt->execute(['id'=>$homeownerId]);
$h=$stmt->fetch();
if(!$h){http_response_code(404);exit('Homeowner not found.');}

$stmt=$pdo->prepare(
    'SELECT r.*, rp.or_number AS payment_or, rp.payment_method, rp.status AS payment_status, rp.payment_date AS reservation_payment_date
     FROM reservations r
     LEFT JOIN reservation_payments rp ON rp.reservation_payment_id=(
         SELECT MAX(rp2.reservation_payment_id) FROM reservation_payments rp2 WHERE rp2.reservation_id=r.reservation_id
     )
     WHERE r.homeowner_id=:id
     ORDER BY r.reservation_date DESC, r.start_time DESC, r.reservation_id DESC'
);
$stmt->execute(['id'=>$homeownerId]);
$reservations=$stmt->fetchAll();

$years=[];
foreach($reservations as $r){
    $year=date('Y',strtotime($r['reservation_date']));
    if(!isset($years[$year])) $years[$year]=['count'=>0,'completed_revenue'=>0.0,'rows'=>[]];
    $years[$year]['count']++;
    if($r['status']==='Completed' && $r['payment_status']==='Validated') $years[$year]['completed_revenue']+=(float)$r['payment_amount'];
    $years[$year]['rows'][]=$r;
}

$memberSince=$h['created_at'];
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Reservation History - <?=e($h['household_name'])?></title>
<link rel="stylesheet" href="assets/css/style.css">
<style>
body{background:#fff}.print-sheet{max-width:1050px;margin:24px auto;padding:28px}.print-tools{display:flex;gap:8px;justify-content:flex-end;margin-bottom:18px}.history-print-header{text-align:center;border-bottom:1px solid #ddd;padding-bottom:16px;margin-bottom:20px}.history-print-header img{width:72px;height:72px;object-fit:contain}.summary-box{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:18px 0}.summary-box div{border:1px solid #ddd;padding:12px;border-radius:8px}.summary-box strong,.summary-box span{display:block}.year-block{margin-top:22px}.data-table{width:100%;border-collapse:collapse}.data-table th,.data-table td{border:1px solid #ddd;padding:7px;text-align:left;font-size:12px;vertical-align:top}.data-table th{background:#f3f7f4}.reservation-meta{margin:0 0 6px;color:#667}.no-print{display:flex;gap:8px}@media print{.print-tools{display:none!important}.print-sheet{margin:0;max-width:none;padding:0}.year-block{break-inside:auto}.data-table tr{break-inside:avoid}}
</style>
</head>
<body>
<main class="print-sheet">
    <div class="print-tools no-print"><button class="btn btn-primary" onclick="window.print()">Print</button><button class="btn btn-secondary" onclick="window.close()">Close</button></div>
    <header class="history-print-header">
        <img src="assets/images/logo.png" alt="FPHAI logo">
        <h1>Fairmont Park Homeowners' Association, Inc.</h1>
        <h2>Homeowner Reservation History</h2>
        <p><strong><?=e($h['household_name'])?></strong> · <?=e($h['address'])?></p>
        <?php if($h['block']||$h['lot']): ?><p>Block <?=e($h['block']?:'—')?> / Lot <?=e($h['lot']?:'—')?></p><?php endif; ?>
        <p>Member record since <?=e(date('F d, Y',strtotime($memberSince)))?></p>
    </header>

    <div class="summary-box">
        <div><span>Total Reservations</span><strong><?=number_format(count($reservations))?></strong></div>
        <div><span>Completed Paid Revenue</span><strong>₱<?=number_format(array_sum(array_map(fn($r)=>($r['status']==='Completed'&&$r['payment_status']==='Validated')?(float)$r['payment_amount']:0,$reservations)),2)?></strong></div>
        <div><span>Recent Records</span><strong><?=number_format(min(3,count($reservations)))?></strong></div>
    </div>

    <?php if($reservations): ?>
    <section class="year-block">
        <h2>Recent Reservations</h2>
        <table class="data-table"><thead><tr><th>Date</th><th>Facility</th><th>Time</th><th>Requester</th><th>Type</th><th>Fee</th><th>Payment</th><th>Status</th></tr></thead><tbody>
        <?php foreach(array_slice($reservations,0,3) as $r): ?><tr>
            <td><?=e($r['reservation_date'])?></td><td><?=e($r['facility'])?></td>
            <td><?=e(date('g:i A',strtotime($r['start_time'])))?>–<?=e(date('g:i A',strtotime($r['end_time'])))?></td>
            <td><?=e($r['requester_name'])?></td><td><?=e($r['requester_type'])?></td>
            <td>₱<?=number_format((float)$r['payment_amount'],2)?></td>
            <td><?=e($r['payment_status']?:'Not recorded')?><?= $r['payment_or'] ? ' · '.e($r['payment_or']) : '' ?></td>
            <td><?=e($r['status'])?></td>
        </tr><?php endforeach; ?></tbody></table>
    </section>
    <?php endif; ?>

    <?php foreach($years as $year=>$yr): ?>
    <section class="year-block">
        <h2><?=e($year)?></h2>
        <p class="reservation-meta"><?=number_format($yr['count'])?> reservation record(s) · Completed paid revenue: ₱<?=number_format($yr['completed_revenue'],2)?></p>
        <table class="data-table"><thead><tr><th>Date</th><th>Facility</th><th>Time</th><th>Requester</th><th>Type</th><th>Purpose</th><th>Fee</th><th>Payment OR</th><th>Payment</th><th>Status</th><th>Cancellation Reason</th></tr></thead><tbody>
        <?php foreach($yr['rows'] as $r): ?><tr>
            <td><?=e($r['reservation_date'])?></td><td><?=e($r['facility'])?></td>
            <td><?=e(date('g:i A',strtotime($r['start_time'])))?>–<?=e(date('g:i A',strtotime($r['end_time'])))?></td>
            <td><?=e($r['requester_name'])?></td><td><?=e($r['requester_type'])?></td>
            <td><?=e($r['purpose']?:'—')?></td><td>₱<?=number_format((float)$r['payment_amount'],2)?></td>
            <td><?=e($r['payment_or']?:'—')?></td><td><?=e($r['payment_status']?:'Not recorded')?></td><td><?=e($r['status'])?></td><td><?=e($r['cancellation_reason']?:'—')?></td>
        </tr><?php endforeach; ?></tbody></table>
    </section>
    <?php endforeach; ?>
    <?php if(!$reservations): ?><p>No reservation records have been recorded for this homeowner.</p><?php endif; ?>
</main>
</body>
</html>
