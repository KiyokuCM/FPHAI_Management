function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    if (sidebar) {
        sidebar.classList.toggle('open');
    }
}

document.addEventListener('click', function (event) {
    const sidebar = document.getElementById('sidebar');
    const button = document.querySelector('.mobile-menu-btn');

    if (!sidebar || !button) return;

    if (
        window.innerWidth <= 900 &&
        sidebar.classList.contains('open') &&
        !sidebar.contains(event.target) &&
        !button.contains(event.target)
    ) {
        sidebar.classList.remove('open');
    }
});


function startLiveClock() {
    const dateEl = document.querySelector('[data-live-date]');
    const timeEl = document.querySelector('[data-live-time]');
    if (!dateEl && !timeEl) return;
    const update = () => {
        const now = new Date();
        if (dateEl) dateEl.textContent = now.toLocaleDateString('en-PH', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
        if (timeEl) timeEl.textContent = now.toLocaleTimeString('en-PH', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
    };
    update();
    setInterval(update, 1000);
}

document.addEventListener('DOMContentLoaded', startLiveClock);

function startLoginSlideshow() {
    const slides = document.querySelectorAll('.login-slide');
    if (slides.length < 2) return;
    let index = 0;
    slides[0].classList.add('is-visible');
    setInterval(() => {
        slides[index].classList.remove('is-visible');
        index = (index + 1) % slides.length;
        slides[index].classList.add('is-visible');
    }, 5500);
}

document.addEventListener('DOMContentLoaded', startLoginSlideshow);


function startInactivityTimeout() {
    const timeoutMs = 30 * 60 * 1000;
    let timer;
    const reset = () => {
        clearTimeout(timer);
        timer = setTimeout(() => {
            window.location.href = '../login.php?timeout=1';
        }, timeoutMs);
    };
    ['click','keydown','mousemove','mousedown','scroll','touchstart'].forEach(eventName => {
        document.addEventListener(eventName, reset, { passive: true });
    });
    reset();
}

document.addEventListener('DOMContentLoaded', startInactivityTimeout);


function initReservationCalendarDetails() {
    const modal = document.getElementById('reservation-calendar-modal');
    const list = document.getElementById('calendar-detail-list');
    const title = document.getElementById('calendar-detail-title');
    const subtitle = document.getElementById('calendar-detail-subtitle');
    if (!modal || !list || !window.reservationCalendarData) return;
    const data = window.reservationCalendarData;
    const privacy = window.reservationCalendarPrivacy || 'staff';
    const currentUserId = Number(window.reservationCurrentUserId || 0);
    const esc = (v) => String(v ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
    const fmtTime = (v) => { const parts=String(v||'').split(':'); if(parts.length<2)return v||''; let h=Number(parts[0]); const m=parts[1]; const ap=h>=12?'PM':'AM'; h=h%12||12; return `${h}:${m} ${ap}`; };
    const fmtDate = (v) => { const d=new Date(`${v}T00:00:00`); return d.toLocaleDateString('en-PH',{weekday:'long',year:'numeric',month:'long',day:'numeric'}); };
    const open = (facility,date) => {
        const rows = (data[facility] && data[facility][date]) ? data[facility][date] : [];
        title.textContent = `${facility} — ${fmtDate(date)}`;
        subtitle.textContent = rows.length ? `${rows.length} reservation record${rows.length===1?'':'s'} on this date.` : 'No reservation records for this date.';
        if (!rows.length) { list.innerHTML='<div class="calendar-detail-empty">This date is currently vacant.</div>'; }
        else {
            list.innerHTML = rows.map(r => {
                const mine = currentUserId && Number(r.requested_by) === currentUserId;
                let requester = r.requester_name || '—';
                let extra = `<span>${esc(r.requester_type || '')}</span>`;
                if (privacy === 'resident' && !mine) { requester = r.requester_type === 'Outside User' ? 'Outside user (name hidden)' : 'Resident (name hidden)'; extra = '<span>Requester details hidden for privacy</span>'; }
                else if (privacy !== 'resident') { extra = `<span>${esc(r.requester_type || '')} · ${esc(r.requester_affiliation || 'No affiliation provided')}</span><span>${esc(r.requester_contact || 'No contact')} · ${esc(r.requester_email || 'No email')}</span>`; }
                return `<article class="calendar-detail-item"><div class="calendar-detail-main"><strong>${esc(requester)}</strong>${extra}</div><div class="calendar-detail-time"><strong>${esc(fmtTime(r.start_time))}–${esc(fmtTime(r.end_time))}</strong><span class="status-pill ${r.status==='Approved'||r.status==='Completed'?'status-success':r.status==='Pending'?'status-pending':'status-danger'}">${esc(r.status)}</span></div></article>`;
            }).join('');
        }
        const chosenDate = new Date(`${date}T00:00:00`); const today = new Date(); today.setHours(0,0,0,0);
        if (chosenDate >= today && (privacy === 'resident' || privacy === 'staff')) {
            const reserve = document.createElement('a'); reserve.className='btn btn-primary reservation-calendar-reserve';
            reserve.textContent = privacy === 'resident' ? 'Reserve this date' : 'Record Reservation Request';
            reserve.href = privacy === 'resident'
                ? `reservations.php?reserve=1&facility=${encodeURIComponent(facility)}&date=${encodeURIComponent(date)}#reservation-request`
                : `reservations.php?record=1&facility=${encodeURIComponent(facility)}&date=${encodeURIComponent(date)}#reservation-request`;
            list.appendChild(reserve);
        }
        modal.hidden=false; document.body.classList.add('modal-open');
    };
    document.querySelectorAll('.calendar-interactive-day').forEach(btn=>btn.addEventListener('click',()=>open(btn.dataset.calendarFacility,btn.dataset.calendarDate)));
    window.openReservationCalendarDate = open;
    const query = new URLSearchParams(window.location.search);
    if (query.get('open_date') === '1' && query.get('date')) {
        const requestedFacility = query.get('facility') || 'Court 1';
        const requestedDate = query.get('date');
        if (data[requestedFacility] && data[requestedFacility][requestedDate]) {
            setTimeout(() => open(requestedFacility, requestedDate), 30);
        }
    }
    window.closeReservationCalendar = () => { modal.hidden=true; document.body.classList.remove('modal-open'); };
    modal.addEventListener('click', e=>{ if(e.target===modal) window.closeReservationCalendar(); });
    document.addEventListener('keydown', e=>{ if(e.key==='Escape' && !modal.hidden) window.closeReservationCalendar(); });
}
document.addEventListener('DOMContentLoaded', initReservationCalendarDetails);


function scheduleDailyCalendarRefresh() {
    const path = window.location.pathname.toLowerCase();
    const isCalendarPage = path.endsWith('/dashboard.php') || path.endsWith('/reservations.php');
    if (!isCalendarPage) return;

    const refreshAtNextMidnight = () => {
        const now = new Date();
        const next = new Date(now);
        next.setHours(24, 0, 1, 0); // one second after local midnight
        setTimeout(() => {
            const url = new URL(window.location.href);
            const monthParam = url.searchParams.get('month');
            const currentMonth = `${new Date().getFullYear()}-${String(new Date().getMonth()+1).padStart(2,'0')}`;
            if (monthParam && monthParam !== currentMonth) {
                // Keep historical month views intact; only normalize to the current
                // month when the page was already showing the current month.
                refreshAtNextMidnight();
                return;
            }
            window.location.reload();
        }, Math.max(1000, next.getTime() - now.getTime()));
    };
    refreshAtNextMidnight();
}

document.addEventListener('DOMContentLoaded', scheduleDailyCalendarRefresh);

function initPhoneCountryFields() {
    const fields = document.querySelectorAll('input[name="contact_number"], input[name="mobile_number"], input[name="requester_contact"]');
    if (!fields.length) return;
    const countries = [
        ['PH','+63','Philippines'],['US','+1','United States'],['CA','+1','Canada'],['GB','+44','United Kingdom'],
        ['AU','+61','Australia'],['SG','+65','Singapore'],['MY','+60','Malaysia'],['JP','+81','Japan'],
        ['KR','+82','South Korea'],['HK','+852','Hong Kong'],['AE','+971','UAE'],['SA','+966','Saudi Arabia'],
        ['IN','+91','India'],['CN','+86','China'],['TW','+886','Taiwan'],['NZ','+64','New Zealand'],
        ['DE','+49','Germany'],['FR','+33','France'],['IT','+39','Italy'],['ES','+34','Spain']
    ];
    const findCountry = (value) => {
        const v = String(value || '').trim();
        if (/^09\d{8,9}$/.test(v.replace(/[\s-]/g,''))) return 0;
        const digits = v.replace(/\D/g,'');
        if (v.startsWith('+')) {
            let best = -1, bestLen = -1;
            countries.forEach((c,i)=>{const code=c[1].replace('+','');if(digits.startsWith(code)&&code.length>bestLen){best=i;bestLen=code.length;}});
            if(best>=0)return best;
        }
        return 0;
    };
    fields.forEach(input=>{
        if (input.dataset.phoneReady) return;
        input.dataset.phoneReady='1';
        const wrap=document.createElement('div'); wrap.className='intl-phone-wrap';
        const select=document.createElement('select'); select.setAttribute('aria-label','Country code');
        countries.forEach((c,i)=>{const o=document.createElement('option');o.value=String(i);o.textContent=`${c[1]} ${c[2]}`;select.appendChild(o);});
        input.parentNode.insertBefore(wrap,input); wrap.appendChild(select); wrap.appendChild(input);
        const initial=input.value.trim(); select.value=String(findCountry(initial));
        const normalize=()=>{
            let raw=input.value.trim(); const country=countries[Number(select.value)||0];
            if(!raw){return;}
            raw=raw.replace(/[()\-]/g,'').replace(/\s+/g,' ');
            if(raw.startsWith('+')){
                input.value='+'+raw.slice(1).replace(/\D/g,''); return;
            }
            let digits=raw.replace(/\D/g,'');
            if(country[0]==='PH' && digits.startsWith('0')) digits=digits.slice(1);
            input.value=country[1]+' '+digits;
        };
        input.addEventListener('blur',normalize); input.addEventListener('change',normalize);
        select.addEventListener('change',()=>{ if(input.value.trim()) normalize(); });
        const form=input.closest('form'); if(form)form.addEventListener('submit',normalize);
    });
}
document.addEventListener('DOMContentLoaded', initPhoneCountryFields);
