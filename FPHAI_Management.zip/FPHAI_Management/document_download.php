<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

require_login();

$id = (int)($_GET['id'] ?? 0);
if ($id < 1) {
    http_response_code(400);
    exit('Invalid document.');
}

$stmt = $pdo->prepare(
    'SELECT document_id, title, file_name, file_path, visibility
     FROM documents WHERE document_id=:id LIMIT 1'
);
$stmt->execute(['id'=>$id]);
$document = $stmt->fetch();

if (!$document) {
    http_response_code(404);
    exit('Document not found.');
}

$role = current_role();
$allowed = $document['visibility'] === 'All' || $document['visibility'] === $role;
if (!$allowed) {
    http_response_code(403);
    exit('You are not authorized to access this document.');
}

$file = UPLOAD_DIR . basename($document['file_path']);
if (!is_file($file)) {
    http_response_code(404);
    exit('Stored document not found.');
}

$mime = mime_content_type($file) ?: 'application/octet-stream';
header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($file));
header('Content-Disposition: inline; filename="' . rawurlencode(basename($document['file_name'])) . '"');
readfile($file);
exit;
