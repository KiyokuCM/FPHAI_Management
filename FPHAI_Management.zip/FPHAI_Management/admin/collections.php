<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('Administrator');

$pageTitle = 'Collections';
$error = '';
ensure_monthly_collection_reports($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request token. Please try again.';
    } else {
        try {
            $action = $_POST['action'] ?? '';
            $id = (int)($_POST['payment_id'] ?? 0);

            if ($action === 'validate' || $action === 'reject') {
                if ($id < 1) throw new RuntimeException('Invalid payment record.');
                $newStatus = $action === 'validate' ? 'Validated' : 'Rejected';

                $stmt = $pdo->prepare(
                    'UPDATE payments
                     SET status=:status, validated_by=:validated_by
                     WHERE payment_id=:id AND status="Pending"'
                );
                $stmt->execute([
                    'status'=>$newStatus,
                    'validated_by'=>current_user_id(),
                    'id'=>$id
                ]);

                if ($stmt->rowCount() === 0) {
                    throw new RuntimeException('The payment is no longer pending.');
                }

                $homeownerStmt = $pdo->prepare('SELECT p.homeowner_id, h.household_name FROM payments p INNER JOIN homeowners h ON h.homeowner_id=p.homeowner_id WHERE p.payment_id=:payment_id LIMIT 1');
                $homeownerStmt->execute(['payment_id'=>$id]);
                $paymentOwner = $homeownerStmt->fetch();

                if ($newStatus === 'Validated' && $paymentOwner) {
                    $restoredActive = refresh_homeowner_payment_status($pdo, (int)$paymentOwner['homeowner_id']);
                    $message = $restoredActive
                        ? 'Your payment has been validated and your monthly due is covered. Your membership status is Active.'
                        : 'Your payment has been validated by the HOA. Your collection record has been updated.';
                    notify_homeowner(
                        $pdo,
                        (int)$paymentOwner['homeowner_id'],
                        'Payment Validated',
                        $message,
                        'Success',
                        'Collections',
                        $id
                    );
                    if ($restoredActive) {
                        notify_staff(
                            $pdo,
                            'Resident Monthly Due Paid',
                            $paymentOwner['household_name'].' has a validated payment and their membership status has been restored to Active.',
                            'Success',
                            'Collections',
                            (int)$paymentOwner['homeowner_id']
                        );
                    }
                } elseif ($newStatus === 'Rejected' && $paymentOwner) {
                    notify_homeowner(
                        $pdo,
                        (int)$paymentOwner['homeowner_id'],
                        'Payment Rejected',
                        'Your payment record was rejected by the HOA. Please contact the office if you need clarification or need to submit a corrected payment record.',
                        'Danger',
                        'Collections',
                        $id
                    );
                }

                audit_log($pdo, current_user_id(), $newStatus, 'Collections', $id, "Payment {$newStatus}.");
                flash('success', "Payment {$newStatus}.");
                header('Location: collections.php');
                exit;
            }
        } catch (RuntimeException $ex) {
            $error = $ex->getMessage();
        }
    }
}

$totalValidated = current_month_collection_total($pdo);

$pendingCount = (int)$pdo->query(
    'SELECT COUNT(*) FROM payments WHERE status="Pending"'
)->fetchColumn();

$delinquentCount = (int)$pdo->query(
    'SELECT COUNT(*) FROM homeowners WHERE membership_status="Delinquent"'
)->fetchColumn();

$q = trim($_GET['q'] ?? '');
$statusFilter = $_GET['status'] ?? '';
$sql = 'SELECT p.*, h.household_name, u.username AS encoded_username
        FROM payments p
        JOIN homeowners h ON h.homeowner_id=p.homeowner_id
        JOIN users u ON u.user_id=p.encoded_by
        WHERE 1=1';
$params = [];

if ($q !== '') {
    $sql .= ' AND (h.household_name LIKE :household_q OR p.or_number LIKE :or_q OR p.reference_number LIKE :reference_q)';
    $search = "%{$q}%";
    $params['household_q'] = $search;
    $params['or_q'] = $search;
    $params['reference_q'] = $search;
}
if (in_array($statusFilter, ['Pending','Validated','Rejected'], true)) {
    $sql .= ' AND p.status=:status';
    $params['status'] = $statusFilter;
}
$sql .= ' ORDER BY p.payment_date DESC, p.payment_id DESC';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$payments = $stmt->fetchAll();

require __DIR__ . '/../includes/header.php';
$flash = get_flash();
?>
<?php if ($flash): ?><div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>

<section class="stats-grid">
    <article class="stat-card"><span class="stat-label">Current Month Validated Collections</span><strong>₱<?= number_format($totalValidated,2) ?></strong></article>
    <article class="stat-card"><span class="stat-label">Pending Payments</span><strong><?= number_format($pendingCount) ?></strong></article>
    <article class="stat-card stat-card-danger"><span class="stat-label">Delinquent Homeowners</span><strong><?= number_format($delinquentCount) ?></strong></article>
</section>

<section class="section-card">
    <div class="toolbar">
        <div>
            <h2 style="margin:0;">Payment Monitoring</h2>
            <p class="form-note">Review payments encoded by the office and validate or reject pending records.</p>
        </div>
        <form method="GET" class="filter-form">
            <div class="form-group">
                <label for="q">Search</label>
                <input id="q" name="q" type="search" value="<?= e($q) ?>" placeholder="Household, SI, reference">
            </div>
            <div class="form-group">
                <label for="status">Status</label>
                <select id="status" name="status">
                    <option value="">All</option>
                    <?php foreach (['Pending','Validated','Rejected'] as $s): ?>
                        <option value="<?= e($s) ?>" <?= $statusFilter === $s ? 'selected' : '' ?>><?= e($s) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button class="btn btn-primary" type="submit">Filter</button>
            <a class="btn btn-secondary" href="collections.php">Clear</a>
        </form>
    </div>

    <div class="data-table-wrap">
        <table class="data-table">
            <thead><tr><th>Date</th><th>Homeowner</th><th>SI Number</th><th>Amount</th><th>Method</th><th>Transaction Description</th><th>Proof</th><th>Status</th><th>Encoded By</th><th>Action</th></tr></thead>
            <tbody>
            <?php foreach ($payments as $p): ?>
                <?php $paymentDetail = [
                        'Payment Date' => $p['payment_date'],
                        'Homeowner' => $p['household_name'],
                        'SI Number' => $p['or_number'],
                        'Amount' => '₱'.number_format((float)$p['amount'], 2),
                        'Payment Method' => $p['payment_method'],
                        'Reference Number' => $p['reference_number'] ?: '—',
                        'Transaction Description' => $p['description'] ?: '—',
                        'Status' => $p['status'],
                        'Encoded By' => $p['encoded_username'] ?? '—',
                        'Created At' => $p['created_at'] ?? '—',
                    ]; ?>
                <tr class="interactive-data-row" tabindex="0" data-payment-details="<?= e(json_encode($paymentDetail, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) ?>">
                    <td><?= e($p['household_name']) ?></td>
                    <td><?= e($p['or_number']) ?></td>
                    <td>₱<?= number_format((float)$p['amount'],2) ?></td>
                    <td><?= e($p['payment_method']) ?><?= $p['reference_number'] ? '<br><small>'.e($p['reference_number']).'</small>' : '' ?></td>
                    <td class="table-description" title="<?= e($p['description'] ?? '') ?>"><?= e(mb_strimwidth($p['description'] ?? '—', 0, 72, '…', 'UTF-8')) ?></td>
                    <td><?= !empty($p['proof_image_path']) ? '<a class="btn btn-secondary btn-small" target="_blank" href="../payment_proof_download.php?id='.(int)$p['payment_id'].'">View proof</a>' : '<span class="form-note">—</span>' ?></td>
                    <td><span class="status-pill <?= e(status_class($p['status'])) ?>"><?= e($p['status']) ?></span></td>
                    <td><?= e($p['encoded_username']) ?></td>
                    <td>
                        <?php if ($p['status'] === 'Pending'): ?>
                            <div class="actions">
                                <form method="POST" class="inline-form">
                                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                    <input type="hidden" name="action" value="validate">
                                    <input type="hidden" name="payment_id" value="<?= (int)$p['payment_id'] ?>">
                                    <button class="btn btn-primary btn-small" type="submit">Validate</button>
                                </form>
                                <form method="POST" class="inline-form" onsubmit="return confirm('Reject this payment record?');">
                                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                    <input type="hidden" name="action" value="reject">
                                    <input type="hidden" name="payment_id" value="<?= (int)$p['payment_id'] ?>">
                                    <button class="btn btn-danger btn-small" type="submit">Reject</button>
                                </form>
                            </div>
                        <?php else: ?>
                            <span class="form-note">No action</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$payments): ?><tr><td colspan="10" class="empty-state">No payment records found.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</section>

<div class="record-detail-overlay" id="payment-detail-overlay" aria-hidden="true">
  <div class="record-detail-modal" role="dialog" aria-modal="true" aria-labelledby="payment-detail-title">
    <button type="button" class="record-detail-close" aria-label="Close" onclick="closePaymentDetail()">×</button>
    <h2 id="payment-detail-title">Payment Details</h2>
    <div id="payment-detail-content" class="record-detail-grid"></div>
  </div>
</div>
<script>
(function(){
 const overlay=document.getElementById('payment-detail-overlay'), content=document.getElementById('payment-detail-content');
 function open(row){
   try{ const data=JSON.parse(row.dataset.paymentDetails||'{}'); content.innerHTML=Object.entries(data).map(([k,v])=>'<div><span>'+escapeHtml(k)+'</span><strong>'+escapeHtml(String(v))+'</strong></div>').join(''); overlay.classList.add('is-visible'); overlay.setAttribute('aria-hidden','false'); }catch(e){}
 }
 function escapeHtml(v){return v.replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c]));}
 window.closePaymentDetail=function(){overlay.classList.remove('is-visible');overlay.setAttribute('aria-hidden','true');};
 document.addEventListener('click',e=>{const row=e.target.closest('.interactive-data-row'); if(!row || e.target.closest('a,button,form,input,select,textarea')) return; open(row);});
 document.addEventListener('keydown',e=>{const row=e.target.closest('.interactive-data-row'); if(row && (e.key==='Enter'||e.key===' ')){e.preventDefault();open(row);} if(e.key==='Escape') closePaymentDetail();});
 overlay.addEventListener('click',e=>{if(e.target===overlay) closePaymentDetail();});
})();
</script>
<?php require __DIR__ . '/../includes/footer.php'; ?>
