<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('Administrator');

$pageTitle = 'Reports';
ensure_monthly_collection_reports($pdo);

$reportType = $_GET['type'] ?? 'collections';
$allowedTypes = ['collections','monthly','delinquency','reservations'];
if (!in_array($reportType, $allowedTypes, true)) $reportType = 'collections';

$from = trim($_GET['from'] ?? '');
$to = trim($_GET['to'] ?? '');
if (($reportType ?? '') === 'reservations') {
    if ($from === '') $from = date('Y-m-01');
    if ($to === '') $to = date('Y-m-d');
}
$to = trim($_GET['to'] ?? '');
$archiveYear = trim($_GET['year'] ?? 'all');
if ($from !== '' && $to !== '' && $from > $to) [$from, $to] = [$to, $from];
if ($reportType === 'collections' && $from === '' && $to === '') { $from = date('Y-m-01'); $to = date('Y-m-t'); }
if ($reportType === 'monthly') { $from = ''; $to = ''; }

$rows = [];
$total = 0.0;
$monthlyGroups = [];
$archiveTotal = 0.0;
$archiveMonths = 0;
$summaryDelinquent = 0;
$summaryReservationRevenue = 0.0;

$yearRows = $pdo->query('SELECT DISTINCT report_year FROM monthly_collection_reports ORDER BY report_year DESC')->fetchAll(PDO::FETCH_COLUMN);
$availableArchiveYears = array_map('intval', $yearRows);

if ($reportType === 'collections') {
    // Only validated payments belong in the collection report.
    $sql = 'SELECT p.payment_date, h.household_name, h.address, p.or_number,
                   p.amount, p.payment_method, p.reference_number, p.description
            FROM payments p
            JOIN homeowners h ON h.homeowner_id=p.homeowner_id
            WHERE p.status="Validated"';
    $params = [];
    if ($from !== '') { $sql .= ' AND p.payment_date >= :from'; $params['from']=$from; }
    if ($to !== '') { $sql .= ' AND p.payment_date <= :to'; $params['to']=$to; }
    $sql .= ' ORDER BY p.payment_date, p.payment_id';
    $stmt=$pdo->prepare($sql); $stmt->execute($params); $rows=$stmt->fetchAll();
    foreach ($rows as $row) $total += (float)$row['amount'];
} elseif ($reportType === 'monthly') {
    $sql = 'SELECT report_year, report_month, total_validated, validated_count, archived_at
            FROM monthly_collection_reports';
    $params = [];
    if ($archiveYear !== 'all' && ctype_digit($archiveYear)) {
        $sql .= ' WHERE report_year=:year'; $params['year']=(int)$archiveYear;
    }
    $sql .= ' ORDER BY report_year DESC, report_month DESC';
    $stmt=$pdo->prepare($sql); $stmt->execute($params); $rows=$stmt->fetchAll();
    foreach ($rows as $r) {
        $monthlyGroups[(int)$r['report_year']][]=$r;
        $archiveTotal += (float)$r['total_validated'];
        $archiveMonths++;
    }
} elseif ($reportType === 'delinquency') {
    $rows = $pdo->query(
        'SELECT household_name,address,block,lot,contact_number,email,membership_status
         FROM homeowners WHERE membership_status="Delinquent" ORDER BY household_name'
    )->fetchAll();
    $summaryDelinquent = count($rows);
} elseif ($reportType === 'reservations') {
    // Reservation revenue only includes completed reservations. Pending, approved,
    // rejected, and cancelled records are not revenue and are excluded from this report.
    $sql = 'SELECT r.reservation_id,r.facility,r.reservation_date,r.start_time,r.end_time,r.requester_name,
                   r.requester_type,r.requester_affiliation,r.requester_contact,r.requester_email,
                   COALESCE(rp.payment_amount,0) AS payment_amount,h.household_name
            FROM reservations r
            LEFT JOIN homeowners h ON h.homeowner_id=r.homeowner_id
            INNER JOIN (SELECT reservation_id,SUM(amount) AS payment_amount FROM reservation_payments WHERE status="Validated" GROUP BY reservation_id) rp ON rp.reservation_id=r.reservation_id
            WHERE r.status="Completed" AND rp.payment_amount > 0';
    $params=[];
    if ($from !== '') { $sql.=' AND r.reservation_date >= :from'; $params['from']=$from; }
    if ($to !== '') { $sql.=' AND r.reservation_date <= :to'; $params['to']=$to; }
    $sql.=' ORDER BY r.reservation_date,r.start_time';
    $stmt=$pdo->prepare($sql); $stmt->execute($params); $rows=$stmt->fetchAll();
    foreach ($rows as $row) $summaryReservationRevenue += (float)$row['payment_amount'];
}

if (isset($_GET['print']) && $_GET['print'] === '1') {
    audit_log($pdo, current_user_id(), 'Generated', 'Reports', null, 'Generated report: '.$reportType.($reportType==='monthly' ? ' / year '.$archiveYear : ''));
}

$reportTitle = [
    'collections'=>'Collection Summary',
    'monthly'=>'Monthly Collection Archive',
    'delinquency'=>'Delinquency List',
    'reservations'=>'Reservation Revenue',
][$reportType];

require __DIR__ . '/../includes/header.php';
?>
<section class="section-card no-print">
    <div class="toolbar">
        <div><h2>Report Generation</h2><p class="form-note">Generate and print reports using only the records relevant to the selected report type.</p></div>
        <form method="GET" class="filter-form report-generator-form <?= $reportType==='delinquency'?'report-generator-delinquency':'' ?>">
            <div class="form-group"><label for="type">Report Type</label><select id="type" name="type">
                <option value="collections" <?= $reportType==='collections'?'selected':'' ?>>Collection Summary</option>
                <option value="monthly" <?= $reportType==='monthly'?'selected':'' ?>>Monthly Collection Archive</option>
                <option value="delinquency" <?= $reportType==='delinquency'?'selected':'' ?>>Delinquency List</option>
                <option value="reservations" <?= $reportType==='reservations'?'selected':'' ?>>Reservation Revenue</option>
            </select></div>
            <?php if ($reportType === 'monthly'): ?>
                <div class="form-group"><label for="year">Archive Year</label><select id="year" name="year"><option value="all" <?= $archiveYear==='all'?'selected':'' ?>>All Years</option><?php foreach($availableArchiveYears as $yr): ?><option value="<?= (int)$yr ?>" <?= $archiveYear==(string)$yr?'selected':'' ?>><?= (int)$yr ?></option><?php endforeach; ?></select></div>
            <?php elseif ($reportType !== 'delinquency'): ?>
                <div class="form-group"><label for="from">From</label><input id="from" name="from" type="date" value="<?= e($from) ?>"></div>
                <div class="form-group"><label for="to">To</label><input id="to" name="to" type="date" value="<?= e($to) ?>"></div>
            <?php endif; ?>
            <button class="btn btn-primary" type="submit">Generate</button>
            <button class="btn btn-secondary" type="button" onclick="window.print()">Print</button>
        </form>
    </div>
</section>

<section class="section-card">
    <div class="print-only report-header"><img src="../assets/images/logo.png" alt="FPHAI logo"><h2>Fairmont Park Homeowners' Association, Inc.</h2><div class="report-meta"><?= e($reportTitle) ?></div></div>

    <?php if ($reportType === 'collections'): ?>
        <div class="report-summary-single"><span>Total Validated Collections</span><strong>₱<?= number_format($total,2) ?></strong></div>
        <h2>Collection Summary</h2>
        <p class="form-note">Only validated payment transactions are included.</p>
        <div class="data-table-wrap"><table class="data-table"><thead><tr><th>Date</th><th>Homeowner</th><th>Address</th><th>OR</th><th>Amount</th><th>Method</th><th>Description</th></tr></thead><tbody>
        <?php foreach($rows as $r): ?><tr><td><?=e($r['payment_date'])?></td><td><?=e($r['household_name'])?></td><td><?=e($r['address'])?></td><td><?=e($r['or_number'])?></td><td>₱<?=number_format((float)$r['amount'],2)?></td><td><?=e($r['payment_method'])?></td><td><?=e($r['description'] ?: '—')?></td></tr><?php endforeach; ?>
        <?php if(!$rows): ?><tr><td colspan="7" class="empty-state">No validated collection records found.</td></tr><?php endif; ?></tbody></table></div>
    <?php elseif ($reportType === 'monthly'): ?>
        <div class="report-summary-single"><span>Total Monthly Collection Archive<?= $archiveYear==='all'?' — All Years':' — '.$archiveYear ?></span><strong>₱<?=number_format($archiveTotal,2)?></strong><small><?=number_format($archiveMonths)?> archived month<?= $archiveMonths===1?'':'s' ?></small></div>
        <h2>Monthly Collection Archive</h2>
        <p class="form-note">Use Archive Year above to generate or print one year, or choose All Years.</p>
        <div class="data-table-wrap"><table class="data-table"><thead><tr><th>Month</th><th>Validated Transactions</th><th>Total Validated</th><th>Last Archived</th></tr></thead><tbody>
        <?php foreach($monthlyGroups as $year=>$yearRows): ?><tr class="report-year-row"><td colspan="4"><strong><?=e($year)?></strong></td></tr><?php foreach($yearRows as $r): ?><tr><td><?=e(date('F Y',strtotime($r['report_year'].'-'.$r['report_month'].'-01')))?></td><td><?=number_format((int)$r['validated_count'])?></td><td>₱<?=number_format((float)$r['total_validated'],2)?></td><td><?=e($r['archived_at'])?></td></tr><?php endforeach; ?><?php endforeach; ?>
        <?php if(!$rows): ?><tr><td colspan="4" class="empty-state">No archived collection periods found for the selected year.</td></tr><?php endif; ?></tbody></table></div>
    <?php elseif ($reportType === 'delinquency'): ?>
        <div class="report-summary-single report-summary-danger"><span>Total Delinquent Homeowners</span><strong><?=number_format($summaryDelinquent)?></strong></div>
        <h2>Delinquency List</h2>
        <div class="data-table-wrap"><table class="data-table"><thead><tr><th>Household</th><th>Address</th><th>Block/Lot</th><th>Contact</th><th>Email</th><th>Status</th></tr></thead><tbody>
        <?php foreach($rows as $r): ?><tr><td><?=e($r['household_name'])?></td><td><?=e($r['address'])?></td><td><?=e(trim(($r['block']??'').' / '.($r['lot']??''),' /'))?></td><td><?=e($r['contact_number']??'')?></td><td><?=e($r['email']??'')?></td><td><?=e($r['membership_status'])?></td></tr><?php endforeach; ?>
        <?php if(!$rows): ?><tr><td colspan="6" class="empty-state">No delinquent records found.</td></tr><?php endif; ?></tbody></table></div>
    <?php else: ?>
        <div class="report-summary-single"><span>Total Completed Reservation Revenue</span><strong>₱<?=number_format($summaryReservationRevenue,2)?></strong><small>Completed reservations only</small></div>
        <h2>Reservation Revenue</h2>
        <p class="form-note">Only completed reservations are included. Pending, approved, rejected, and cancelled reservations are excluded.</p>
        <div class="data-table-wrap"><table class="data-table"><thead><tr><th>Facility</th><th>Date</th><th>Time</th><th>Requester</th><th>Type</th><th>Affiliation / Household</th><th>Contact</th><th>Email</th><th>Revenue</th></tr></thead><tbody>
        <?php foreach($rows as $r): ?><tr><td><?=e($r['facility'])?></td><td><?=e($r['reservation_date'])?></td><td><?=e(date('g:i A',strtotime($r['start_time'])))?>–<?=e(date('g:i A',strtotime($r['end_time'])))?></td><td><?=e($r['requester_name'])?></td><td><?=e($r['requester_type'])?></td><td><?=e($r['requester_affiliation'] ?: ($r['household_name'] ?: '—'))?></td><td><?=e($r['requester_contact'] ?: '—')?></td><td><?=e($r['requester_email'] ?: '—')?></td><td>₱<?=number_format((float)$r['payment_amount'],2)?></td></tr><?php endforeach; ?>
        <?php if(!$rows): ?><tr><td colspan="9" class="empty-state">No completed reservation revenue records found.</td></tr><?php endif; ?></tbody></table></div>
    <?php endif; ?>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

<script>document.addEventListener('DOMContentLoaded',function(){const type=document.getElementById('type'),from=document.getElementById('from'),to=document.getElementById('to');if(!type||!from||!to)return;function sync(){if(type.value==='reservations'){if(!from.value)from.value=new Date().toISOString().slice(0,8)+'01';if(!to.value)to.value=new Date().toISOString().slice(0,10);} }type.addEventListener('change',sync);sync();});</script>
