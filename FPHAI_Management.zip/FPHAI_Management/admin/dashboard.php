<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

require_role('Administrator');

$pageTitle = 'Administrator Dashboard';
ensure_monthly_collection_reports($pdo);

$homeowners = (int)$pdo->query('SELECT COUNT(*) FROM homeowners')->fetchColumn();
$pendingReservations = (int)$pdo->query('SELECT COUNT(*) FROM reservations WHERE status = "Pending"')->fetchColumn();
$totalCollections = current_month_collection_total($pdo);
$reservationRevenue = (float)$pdo->query('SELECT COALESCE(SUM(rp.amount),0) FROM reservation_payments rp INNER JOIN reservations r ON r.reservation_id=rp.reservation_id WHERE rp.status="Validated" AND r.status="Completed" AND rp.payment_date >= DATE_FORMAT(CURDATE(),"%Y-%m-01") AND rp.payment_date < DATE_ADD(DATE_FORMAT(CURDATE(),"%Y-%m-01"), INTERVAL 1 MONTH)')->fetchColumn();
$pendingPayments = (int)$pdo->query('SELECT COUNT(*) FROM payments WHERE status = "Pending"')->fetchColumn();
$delinquent = (int)$pdo->query('SELECT COUNT(*) FROM homeowners WHERE membership_status = "Delinquent"')->fetchColumn();

$pendingCollectionRows = $pdo->query(
    'SELECT p.payment_id, p.or_number, p.payment_date, p.amount, p.payment_method, h.household_name
     FROM payments p
     INNER JOIN homeowners h ON h.homeowner_id = p.homeowner_id
     WHERE p.status = "Pending"
     ORDER BY p.payment_date ASC, p.payment_id ASC
     LIMIT 5'
)->fetchAll();

$pendingReservationRows = $pdo->query(
    'SELECT r.reservation_id, r.requester_name, r.reservation_date, r.start_time, r.end_time, r.requester_type, r.facility, r.payment_amount
     FROM reservations r
     WHERE r.status = "Pending"
     ORDER BY r.reservation_date ASC, r.start_time ASC, r.reservation_id ASC
     LIMIT 5'
)->fetchAll();

$dashboardMonth = date('Y-m');
$dashboardStart = $dashboardMonth . '-01';
$dashboardEnd = (new DateTimeImmutable($dashboardStart))->modify('+1 month')->format('Y-m-d');
$calendarStmt = $pdo->prepare('SELECT facility,reservation_date,COUNT(*) AS booking_count FROM reservations WHERE reservation_date>=:start AND reservation_date<:end AND status IN ("Pending","Approved") GROUP BY facility,reservation_date');
$calendarStmt->execute(['start'=>$dashboardStart,'end'=>$dashboardEnd]);
$dashboardBookings=[];
foreach($calendarStmt->fetchAll() as $b){ $dashboardBookings[$b['facility']][$b['reservation_date']] = (int)$b['booking_count']; }
function dashboard_calendar(string $month,array $bookings,string $facility): void {
    $first=new DateTimeImmutable($month.'-01'); $days=(int)$first->format('t'); $offset=(int)$first->format('N')-1;
    echo '<div class="calendar-card compact-calendar"><div class="calendar-heading"><div><strong>'.e($facility).'</strong><span>Current month</span></div></div><div class="calendar-weekdays"><span>M</span><span>T</span><span>W</span><span>T</span><span>F</span><span>S</span><span>S</span></div><div class="calendar-grid">';
    for($i=0;$i<$offset;$i++) echo '<div class="calendar-day is-empty"></div>';
    $today=date('Y-m-d'); for($d=1;$d<=$days;$d++){ $date=$first->setDate((int)$first->format('Y'),(int)$first->format('m'),$d)->format('Y-m-d'); $count=$bookings[$facility][$date]??0; $past=$date<$today; $cls=$past?'is-closed':($count?'is-booked':'is-available'); $label=$past?'Closed':($count?'Booked':'Open'); echo '<a class="calendar-day '.$cls.'" href="reservations.php?month='.e($month).'&date='.e($date).'&facility='.rawurlencode($facility).'&open_date=1" title="'.e($date).' — '.e($label).'"><strong>'.$d.'</strong><span>'.$label.'</span></a>'; }
    echo '</div></div>';
}

$chartYears=[];
$thisYear=(int)date('Y');
for($y=$thisYear-4;$y<=$thisYear;$y++) $chartYears[]=$y;

// Five-year annual collection totals. Historical months are taken from the
// monthly archive; the current month is added directly from validated payments.
$chartCollections=[];
foreach($chartYears as $y) $chartCollections[$y]=0.0;
$chartArchiveStmt=$pdo->prepare('SELECT report_year, COALESCE(SUM(total_validated),0) AS annual_total FROM monthly_collection_reports WHERE report_year BETWEEN :start_year AND :end_year GROUP BY report_year ORDER BY report_year');
$chartArchiveStmt->execute(['start_year'=>$thisYear-4,'end_year'=>$thisYear]);
foreach($chartArchiveStmt->fetchAll() as $r){
    $y=(int)$r['report_year'];
    if(array_key_exists($y,$chartCollections)) $chartCollections[$y]=(float)$r['annual_total'];
}
$currentMonthStmt=$pdo->prepare('SELECT COALESCE(SUM(amount),0) FROM payments WHERE status="Validated" AND payment_date >= :start_date AND payment_date < :next_date');
$currentMonthStmt->execute(['start_date'=>date('Y-m-01'),'next_date'=>date('Y-m-01',strtotime('+1 month'))]);
$chartCollections[$thisYear]+=(float)$currentMonthStmt->fetchColumn();

// Five-year annual reservation revenue totals. Only completed reservations
// with validated reservation payments are included, matching Reports.
$chartReservations=[];
foreach($chartYears as $y) $chartReservations[$y]=0.0;
$chartReservationStmt=$pdo->prepare('SELECT YEAR(r.reservation_date) AS report_year, COALESCE(SUM(rp.amount),0) AS annual_total FROM reservations r INNER JOIN reservation_payments rp ON rp.reservation_id=r.reservation_id WHERE r.status="Completed" AND rp.status="Validated" AND r.reservation_date >= :start_date AND r.reservation_date < :next_date GROUP BY YEAR(r.reservation_date) ORDER BY report_year');
$chartReservationStmt->execute(['start_date'=>($thisYear-4).'-01-01','next_date'=>($thisYear+1).'-01-01']);
foreach($chartReservationStmt->fetchAll() as $r){
    $y=(int)$r['report_year'];
    if(array_key_exists($y,$chartReservations)) $chartReservations[$y]=(float)$r['annual_total'];
}

$chartCollectionsMax=max($chartCollections ?: [0]);
$chartReservationsMax=max($chartReservations ?: [0]);
$chartCombinedMax=max($chartCollectionsMax,$chartReservationsMax,1);

require __DIR__ . '/../includes/header.php';
?>

<section class="welcome-card dashboard-welcome">
    <div class="dashboard-welcome-copy">
        <span class="eyebrow">Welcome back</span>
        <h2>Hello, <?= e(current_username()) ?>.</h2>
        <p class="dashboard-role">Administrator</p>
        <p>Monitor centralized records, collections, reservations, and user activity.</p>
    </div>
</section>

<section class="stats-grid">
    <article class="stat-card"><span class="stat-label">Current Month Collections</span><strong>₱<?= number_format($totalCollections, 2) ?></strong></article>
    <article class="stat-card"><span class="stat-label">Reservation Revenue This Month</span><strong>₱<?= number_format($reservationRevenue, 2) ?></strong></article>
    <article class="stat-card stat-card-danger"><span class="stat-label">Delinquent Homeowners</span><strong><?= number_format($delinquent) ?></strong></article>
    <article class="stat-card"><span class="stat-label">Registered Homeowners</span><strong><?= number_format($homeowners) ?></strong></article>
</section>

<section class="financial-comparison-grid">
    <article class="section-card financial-chart-card">
        <div class="section-heading"><div><h2>Monthly Collections — 5-Year Comparison</h2><p>Total validated collections for each of the past five calendar years. The current year includes collections through the current month.</p></div></div>
        <div class="annual-histogram" aria-label="Five year annual collections histogram">
            <div class="annual-histogram-scale"><span>₱<?= number_format($chartCombinedMax,0) ?></span><span>₱<?= number_format($chartCombinedMax*0.75,0) ?></span><span>₱<?= number_format($chartCombinedMax*0.50,0) ?></span><span>₱<?= number_format($chartCombinedMax*0.25,0) ?></span><span>₱0</span></div>
            <div class="annual-histogram-plot">
                <div class="annual-histogram-gridlines" aria-hidden="true"><span></span><span></span><span></span><span></span><span></span></div>
                <?php foreach($chartYears as $year): $value=(float)$chartCollections[$year]; $height=$chartCombinedMax>0 ? ($value/$chartCombinedMax*100) : 0; ?>
                    <div class="annual-histogram-group">
                        <div class="annual-histogram-value">₱<?= number_format($value,0) ?></div>
                        <div class="annual-histogram-bar collections-bar" style="height:<?= max(0,min(100,$height)) ?>%" title="<?= e((string)$year) ?> collections: ₱<?= number_format($value,2) ?>"></div>
                        <strong><?= e((string)$year) ?></strong>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </article>
    <article class="section-card financial-chart-card">
        <div class="section-heading"><div><h2>Reservation Revenue — 5-Year Comparison</h2><p>Total revenue from completed reservations with validated payments for each of the past five calendar years.</p></div></div>
        <div class="annual-histogram" aria-label="Five year annual reservation revenue histogram">
            <div class="annual-histogram-scale"><span>₱<?= number_format($chartCombinedMax,0) ?></span><span>₱<?= number_format($chartCombinedMax*0.75,0) ?></span><span>₱<?= number_format($chartCombinedMax*0.50,0) ?></span><span>₱<?= number_format($chartCombinedMax*0.25,0) ?></span><span>₱0</span></div>
            <div class="annual-histogram-plot">
                <div class="annual-histogram-gridlines" aria-hidden="true"><span></span><span></span><span></span><span></span><span></span></div>
                <?php foreach($chartYears as $year): $value=(float)$chartReservations[$year]; $height=$chartCombinedMax>0 ? ($value/$chartCombinedMax*100) : 0; ?>
                    <div class="annual-histogram-group">
                        <div class="annual-histogram-value">₱<?= number_format($value,0) ?></div>
                        <div class="annual-histogram-bar reservation-bar" style="height:<?= max(0,min(100,$height)) ?>%" title="<?= e((string)$year) ?> reservation revenue: ₱<?= number_format($value,2) ?>"></div>
                        <strong><?= e((string)$year) ?></strong>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </article>
</section><section class="section-card dashboard-calendar-section"><div class="section-heading"><div><h2>Court Availability — <?= e(date('F Y')) ?></h2><p>Click any date to open the Reservations module and view that specific date.</p></div></div><div class="calendar-dual"><?php dashboard_calendar($dashboardMonth,$dashboardBookings,'Court 1'); dashboard_calendar($dashboardMonth,$dashboardBookings,'Court 2'); ?></div></section>

<section class="dashboard-action-grid">
    <article class="request-panel">
        <div class="request-panel-header"><div><h2>Awaiting Collection Validation</h2><span>Showing up to 5 pending collection entries.</span></div></div>
        <?php if ($pendingCollectionRows): ?>
            <ul class="request-list">
            <?php foreach ($pendingCollectionRows as $row): ?>
                <li class="request-item"><div class="request-main"><strong><?= e($row['household_name']) ?></strong><span><?= e($row['or_number']) ?> · <?= e($row['payment_date']) ?> · <?= e($row['payment_method']) ?></span></div><div class="request-action"><strong>₱<?= number_format((float)$row['amount'],2) ?></strong></div></li>
            <?php endforeach; ?>
            </ul>
            <?php if ($pendingPayments > 5): ?><div class="request-more"><span class="form-note"><?= number_format($pendingPayments - 5) ?> more pending entries</span></div><?php endif; ?>
        <?php else: ?><div class="request-empty">No collection entries are awaiting validation.</div><?php endif; ?>
        <div class="request-more"><a class="btn btn-primary btn-small" href="collections.php">Review Collections</a></div>
    </article>

    <article class="request-panel">
        <div class="request-panel-header"><div><h2>Awaiting Reservation Approval</h2><span>Showing up to 5 pending requests.</span></div></div>
        <?php if ($pendingReservationRows): ?>
            <ul class="request-list">
            <?php foreach ($pendingReservationRows as $row): ?>
                <li class="request-item"><div class="request-main"><strong><?= e($row['requester_name']) ?></strong><span><?= e($row['facility']) ?> · <?= e($row['reservation_date']) ?> · <?= e(substr($row['start_time'],0,5)) ?>–<?= e(substr($row['end_time'],0,5)) ?> · <?= e($row['requester_type']) ?> · ₱<?= number_format((float)$row['payment_amount'],2) ?></span></div></li>
            <?php endforeach; ?>
            </ul>
            <?php if ($pendingReservations > 5): ?><div class="request-more"><span class="form-note"><?= number_format($pendingReservations - 5) ?> more pending requests</span></div><?php endif; ?>
        <?php else: ?><div class="request-empty">No reservation requests are awaiting approval.</div><?php endif; ?>
        <div class="request-more"><a class="btn btn-primary btn-small" href="reservations.php">Review Reservations</a></div>
    </article>
</section>


<?php require __DIR__ . '/../includes/footer.php'; ?>
