<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('Administrator');

$pageTitle = 'Audit Trail';

$q = trim($_GET['q'] ?? '');
$sql = 'SELECT a.*, u.username
        FROM audit_logs a
        LEFT JOIN users u ON u.user_id=a.user_id
        WHERE 1=1';
$params=[];

if ($q !== '') {
    $sql .= ' AND (a.action LIKE :action_q OR a.module LIKE :module_q OR a.details LIKE :details_q OR u.username LIKE :username_q)';
    $search = "%{$q}%";
    $params['action_q'] = $search;
    $params['module_q'] = $search;
    $params['details_q'] = $search;
    $params['username_q'] = $search;
}
$sql .= ' ORDER BY a.created_at DESC, a.log_id DESC LIMIT 300';

$stmt=$pdo->prepare($sql);
$stmt->execute($params);
$logs=$stmt->fetchAll();

require __DIR__ . '/../includes/header.php';
?>
<section class="section-card">
    <div class="toolbar">
        <div>
            <h2>Activity Log</h2>
            <p class="form-note">Major system activities are recorded for accountability and traceability.</p>
        </div>
        <form method="GET" class="filter-form">
            <div class="form-group">
                <label for="q">Search</label>
                <input id="q" name="q" type="search" value="<?= e($q) ?>" placeholder="User, action, module">
            </div>
            <button class="btn btn-primary" type="submit">Search</button>
            <a class="btn btn-secondary" href="audit-trail.php">Clear</a>
        </form>
    </div>

    <div class="data-table-wrap">
        <table class="data-table">
            <thead><tr><th>Date/Time</th><th>User</th><th>Action</th><th>Module</th><th>Record ID</th><th>Details</th></tr></thead>
            <tbody>
            <?php foreach ($logs as $log): ?>
                <tr>
                    <td><?= e($log['created_at']) ?></td>
                    <td><?= e($log['username'] ?? 'System') ?></td>
                    <td><?= e($log['action']) ?></td>
                    <td><?= e($log['module']) ?></td>
                    <td><?= e((string)($log['record_id'] ?? '—')) ?></td>
                    <td><?= e($log['details'] ?? '') ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$logs): ?><tr><td colspan="6" class="empty-state">No audit records found.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
