<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('Administrator');
deactivate_expired_homeowner_accounts($pdo);

$pageTitle = 'User Accounts';
$error = '';
$editing = null;
$editingHomeowner = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request token. Please try again.';
    } else {
        $action = $_POST['action'] ?? '';

        try {
            if ($action === 'save') {
                $id = (int)($_POST['user_id'] ?? 0);
                $username = trim($_POST['username'] ?? '');
                $role = $_POST['role'] ?? '';
                $status = $_POST['status'] ?? 'Active';
                $password = $_POST['password'] ?? '';
                $email = trim($_POST['email'] ?? '');
                $mobile = trim($_POST['mobile_number'] ?? '');
                $twoFactorEnabled = isset($_POST['two_factor_enabled']) ? 1 : 0;
                if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) { throw new RuntimeException('Please enter a valid email address.'); }

                if ($username === '' || !in_array($role, ['Administrator', 'Clerk', 'Resident'], true)
                    || !in_array($status, ['Active', 'Inactive'], true)) {
                    throw new RuntimeException('Please provide valid account information.');
                }

                if ($id > 0) {
                    $sourceStmt = $pdo->prepare('SELECT account_source, must_change_password, temporary_password_expires_at, status FROM users WHERE user_id=:user_id');
                    $sourceStmt->execute(['user_id'=>$id]);
                    $existingAccount = $sourceStmt->fetch();
                    $existingSource = $existingAccount['account_source'] ?? null;
                    $existingMustChange = (int)($existingAccount['must_change_password'] ?? 0);
                    $existingTempExpires = $existingAccount['temporary_password_expires_at'] ?? null;
                    $existingStatus = $existingAccount['status'] ?? 'Active';
                    if ($existingSource === 'Homeowner' && $role !== 'Resident') {
                        throw new RuntimeException('A Resident account created from a homeowner profile must remain a Resident account.');
                    }

                    if ($id === current_user_id() && $status === 'Inactive') {
                        throw new RuntimeException('The current Administrator account cannot be deactivated here.');
                    }

                    // If the administrator is explicitly resetting a Homeowner-created Resident
                    // account that is still waiting for its temporary password change (including an
                    // expired temporary password), the new administrator-set password becomes the
                    // permanent password and the account is restored to Active automatically.
                    if ($password !== '' && $existingSource === 'Homeowner' && $existingMustChange === 1) {
                        $status = 'Active';
                    }

                    $linkedStmt = $pdo->prepare('SELECT homeowner_id FROM homeowners WHERE user_id=:user_id LIMIT 1');
                    $linkedStmt->execute(['user_id'=>$id]);
                    $linkedHomeownerId = (int)$linkedStmt->fetchColumn();

                    // Keep account editing independent from the homeowner membership update.
                    // The previous CASE expression could fail on installations using ANSI_QUOTES
                    // SQL mode, which made the whole User Account form report a generic save error.
                    if ($linkedHomeownerId > 0) {
                        $sync = $pdo->prepare('UPDATE homeowners SET email=:email, contact_number=:mobile_number WHERE homeowner_id=:homeowner_id');
                        $sync->execute([
                            'email' => $email !== '' ? $email : null,
                            'mobile_number' => $mobile !== '' ? $mobile : null,
                            'homeowner_id' => $linkedHomeownerId,
                        ]);

                        if ($status === 'Inactive') {
                            $pdo->prepare('UPDATE homeowners SET membership_status="Inactive" WHERE homeowner_id=:homeowner_id')->execute(['homeowner_id'=>$linkedHomeownerId]);
                        } elseif ($status === 'Active') {
                            $pdo->prepare('UPDATE homeowners SET membership_status="Active" WHERE homeowner_id=:homeowner_id AND membership_status="Inactive"')->execute(['homeowner_id'=>$linkedHomeownerId]);
                        }
                    }

                    if ($password !== '') {
                        if (strlen($password) < 8) {
                            throw new RuntimeException('Password must contain at least 8 characters.');
                        }
                        $stmt = $pdo->prepare(
                            'UPDATE users
                             SET username = :username, email = :email, mobile_number = :mobile_number, two_factor_enabled = :two_factor_enabled, role = :role, status = :status,
                                 password_hash = :password_hash, must_change_password = 0, temporary_password_expires_at = NULL
                             WHERE user_id = :user_id'
                        );
                        $stmt->execute([
                            'username' => $username,
                            'email' => $email ?: null,
                            'mobile_number' => $mobile ?: null,
                            'two_factor_enabled' => $twoFactorEnabled,
                            'role' => $role,
                            'status' => $status,
                            'password_hash' => password_hash($password, PASSWORD_DEFAULT),
                            'user_id' => $id,
                        ]);
                    } else {
                        $stmt = $pdo->prepare(
                            'UPDATE users
                             SET username = :username, email = :email, mobile_number = :mobile_number, two_factor_enabled = :two_factor_enabled, role = :role, status = :status
                             WHERE user_id = :user_id'
                        );
                        $stmt->execute([
                            'username' => $username,
                            'email' => $email ?: null,
                            'mobile_number' => $mobile ?: null,
                            'two_factor_enabled' => $twoFactorEnabled,
                            'role' => $role,
                            'status' => $status,
                            'user_id' => $id,
                        ]);
                    }

                    // A password change invalidates any outstanding second-factor challenge.
                    // Keep this cleanup best-effort so account editing still works on older databases
                    // where the optional 2FA challenge table has not yet been imported.
                    try {
                        $pdo->prepare('DELETE FROM login_2fa_challenges WHERE user_id=:user_id')->execute(['user_id'=>$id]);
                    } catch (PDOException $ignored) {
                        // The account itself was already saved; a missing optional 2FA table must not
                        // turn a successful account/password update into a generic save error.
                    }
                    audit_log($pdo, current_user_id(), 'Updated', 'User Accounts', $id, $password !== '' ? 'Updated user account and reset password.' : 'Updated user account.');
                    flash('success', 'User account updated.');
                } else {
                    if (strlen($password) < 8) {
                        throw new RuntimeException('A new password must contain at least 8 characters.');
                    }

                    $stmt = $pdo->prepare(
                        'INSERT INTO users (username, email, mobile_number, two_factor_enabled, password_hash, role, status, account_source, must_change_password, temporary_password_expires_at)
                         VALUES (:username, :email, :mobile_number, :two_factor_enabled, :password_hash, :role, :status, "Manual", 0, NULL)'
                    );
                    $stmt->execute([
                        'username' => $username,
                        'email' => $email ?: null,
                        'mobile_number' => $mobile ?: null,
                        'two_factor_enabled' => $twoFactorEnabled,
                        'password_hash' => password_hash($password, PASSWORD_DEFAULT),
                        'role' => $role,
                        'status' => $status,
                    ]);

                    $newId = (int)$pdo->lastInsertId();
                    audit_log($pdo, current_user_id(), 'Created', 'User Accounts', $newId, 'Created user account.');
                    $_SESSION['created_manual_account_confirmation'] = [
                        'username' => $username,
                        'role' => $role,
                        'status' => $status,
                        'password' => $password,
                        'source' => 'Manual',
                    ];
                    flash('success', 'User account created. Please confirm and record the credentials below.');
                }

                header('Location: users.php');
                exit;
            }

            if ($action === 'deactivate') {
                $id = (int)($_POST['user_id'] ?? 0);
                if ($id === current_user_id()) {
                    throw new RuntimeException('The current account cannot be deactivated.');
                }

                $stmt = $pdo->prepare('UPDATE users SET status = "Inactive" WHERE user_id = :user_id');
                $stmt->execute(['user_id' => $id]);
                $syncHomeowner = $pdo->prepare('UPDATE homeowners SET membership_status="Inactive" WHERE user_id=:user_id');
                $syncHomeowner->execute(['user_id'=>$id]);

                audit_log($pdo, current_user_id(), 'Deactivated', 'User Accounts', $id, 'Deactivated user account.');
                flash('success', 'User account deactivated.');
                header('Location: users.php');
                exit;
            }
        } catch (PDOException $ex) {
            $error = $ex->errorInfo[1] === 1062
                ? 'That username already exists.'
                : 'The account could not be saved.';
        } catch (RuntimeException $ex) {
            $error = $ex->getMessage();
        }
    }
}

if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare(
        'SELECT u.user_id, u.username, u.email AS user_email, u.mobile_number, u.two_factor_enabled, u.role, u.status, u.account_source, u.must_change_password, u.temporary_password_expires_at,
                h.homeowner_id, h.household_name, h.address, h.block, h.lot, h.contact_number, h.email, h.profile_image_path, h.membership_status
         FROM users u
         LEFT JOIN homeowners h ON h.user_id=u.user_id
         WHERE u.user_id = :id'
    );
    $stmt->execute(['id' => (int)$_GET['edit']]);
    $editing = $stmt->fetch();
    if ($editing && $editing['account_source'] === 'Homeowner' && !empty($editing['homeowner_id'])) {
        $editingHomeowner = $editing;
    }
}

$q = trim($_GET['q'] ?? '');
$sql = 'SELECT user_id, username, role, status, account_source, must_change_password, two_factor_enabled, created_at FROM users';
$params = [];
if ($q !== '') {
    $sql .= ' WHERE username LIKE :username_q OR role LIKE :role_q OR status LIKE :status_q OR account_source LIKE :source_q';
    $search = "%{$q}%";
    $params = ['username_q'=>$search,'role_q'=>$search,'status_q'=>$search,'source_q'=>$search];
}
$sql .= ' ORDER BY username';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll();

require __DIR__ . '/../includes/header.php';
$flash = get_flash();
$manualAccountConfirmation = $_SESSION['created_manual_account_confirmation'] ?? null;
unset($_SESSION['created_manual_account_confirmation']);
?>

<?php if ($flash): ?><div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
<?php if ($manualAccountConfirmation): ?>
<div class="account-confirm-overlay" id="manual-account-confirm-overlay" role="dialog" aria-modal="true" aria-labelledby="manual-account-confirm-title">
    <div class="account-confirm-modal account-confirm-wide">
        <div class="account-confirm-header"><span class="section-kicker">Account Created</span><h2 id="manual-account-confirm-title">Confirm User Account Details</h2></div>
        <p class="form-note">Please record these details before closing this prompt. This is the only time the password will be shown in full.</p>
        <div class="account-confirm-grid">
            <div><span>Username</span><strong><?= e($manualAccountConfirmation['username']) ?></strong></div>
            <div><span>Role</span><strong><?= e($manualAccountConfirmation['role']) ?></strong></div>
            <div><span>Status</span><strong><?= e($manualAccountConfirmation['status']) ?></strong></div>
            <div><span>Account Source</span><strong><?= e($manualAccountConfirmation['source']) ?></strong></div>
            <div class="account-confirm-password"><span>Password</span><strong><?= e($manualAccountConfirmation['password']) ?></strong></div>
        </div>
        <div class="account-confirm-actions"><button class="btn btn-primary" type="button" onclick="closeManualAccountConfirmation()">I Have Recorded These Details</button></div>
    </div>
</div>
<?php endif; ?>


<?php $activeUserAccounts = (int)$pdo->query('SELECT COUNT(*) FROM users WHERE status="Active"')->fetchColumn();
$inactiveUserAccounts = (int)$pdo->query('SELECT COUNT(*) FROM users WHERE status="Inactive"')->fetchColumn(); ?>
<section class="stats-grid user-account-stats" aria-label="User account summary">
    <article class="stat-card"><span class="stat-label">Active User Accounts</span><strong><?= number_format($activeUserAccounts) ?></strong><small>Accounts currently allowed to sign in.</small></article>
    <article class="stat-card stat-card-danger"><span class="stat-label">Inactive User Accounts</span><strong><?= number_format($inactiveUserAccounts) ?></strong><small>Accounts currently not allowed to sign in.</small></article>
</section>

<details class="section-card foldable-panel"<?= $editing ? ' open' : '' ?>>
    <summary><span><strong><?= $editing ? 'Edit User Account' : 'Create User Account' ?></strong><small><?= $editing ? 'Edit the selected account.' : 'Open this section when you need to create an account.' ?></small></span><span class="fold-chevron">⌄</span></summary>
    <div class="foldable-content">
    <div class="section-heading">
        <div>
            <h2><?= $editing ? 'Edit User Account' : 'Create User Account' ?></h2>
            <p>Manage Administrator, Clerk, and Resident accounts for day-to-day HOA operations.</p>
        </div>
        <?php if ($editing): ?><a class="btn btn-secondary" href="users.php">Cancel Edit</a><?php endif; ?>
    </div>

    <?php if ($editingHomeowner): ?>
        <div class="linked-account-banner full linked-account-banner-split">
            <div class="linked-account-details linked-account-details-left">
                <strong>Linked Homeowner Account</strong>
                <span>This Resident account was automatically created from the homeowner profile below.</span>
                <div class="linked-account-household"><strong><?= e($editingHomeowner['household_name']) ?></strong><span><?= e($editingHomeowner['address']) ?><?= ($editingHomeowner['block'] || $editingHomeowner['lot']) ? ' · Block/Lot: '.e(trim(($editingHomeowner['block'] ?? '').' / '.($editingHomeowner['lot'] ?? ''), ' /')) : '' ?></span></div>
                <span><?= e($editingHomeowner['contact_number'] ?: 'No contact number') ?><?= $editingHomeowner['email'] ? ' · '.e($editingHomeowner['email']) : '' ?></span>
                <?php if (!empty($editingHomeowner['must_change_password'])): ?><span>Temporary password expires: <?= e($editingHomeowner['temporary_password_expires_at'] ?: 'Not set') ?></span><?php endif; ?>
            </div>
            <div class="linked-account-photo-right">
                <?php if (!empty($editingHomeowner['profile_image_path'])): ?><img src="../homeowner_image.php?id=<?= (int)$editingHomeowner['homeowner_id'] ?>" alt="Linked homeowner picture" class="linked-homeowner-photo"><?php else: ?><div class="linked-homeowner-photo photo-placeholder">No picture</div><?php endif; ?>
                <span>Homeowner picture</span>
            </div>
        </div>
    <?php endif; ?>
    <?php if ($editingHomeowner && !empty($editingHomeowner['must_change_password']) && !empty($editingHomeowner['temporary_password_expires_at']) && strtotime($editingHomeowner['temporary_password_expires_at']) <= time()): ?>
        <div class="alert alert-warning full">This temporary Resident password has expired without being changed. You can set a new password below. Saving a new password will clear the temporary-password requirement and allow the Resident to sign in directly.</div>
    <?php endif; ?>

    <form method="POST" class="form-grid" data-current-role="<?= e($editing['role'] ?? "") ?>" onsubmit="return confirmUserAccountSave(this);">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="user_id" value="<?= (int)($editing['user_id'] ?? 0) ?>">

        <div class="form-group">
            <label for="username">Username</label>
            <input id="username" name="username" type="text" maxlength="100"
                   value="<?= e($editing['username'] ?? '') ?>" required>
        </div>

        <div class="form-group">
            <label for="role">Role</label>
            <select id="role" name="role" required>
                <?php foreach (['Administrator','Clerk','Resident'] as $role): ?>
                    <option value="<?= e($role) ?>" <?= (($editing['role'] ?? ($editing ? '' : 'Clerk')) === $role) ? 'selected' : '' ?>>
                        <?= e($role) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="status">Status</label>
            <select id="status" name="status" required>
                <?php foreach (['Active', 'Inactive'] as $status): ?>
                    <option value="<?= e($status) ?>" <?= (($editing['status'] ?? 'Active') === $status) ? 'selected' : '' ?>>
                        <?= e($status) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="email">Email Address</label>
            <input id="email" name="email" type="email" maxlength="150" value="<?= e($editing['user_email'] ?? ($editing['email'] ?? '')) ?>">
        </div>

        <div class="form-group">
            <label for="mobile_number">Mobile Number</label>
            <input id="mobile_number" name="mobile_number" type="text" maxlength="50" value="<?= e($editing['mobile_number'] ?? ($editing['contact_number'] ?? '')) ?>">
        </div>

        <div class="form-group compact-checkbox-group">
            <label class="checkbox-label"><input type="checkbox" name="two_factor_enabled" value="1" <?= isset($editing['two_factor_enabled']) && (int)$editing['two_factor_enabled']===1 ? 'checked' : '' ?>> Enable two-factor authentication when an email or SMS contact is available</label>
            <p class="form-note">If no email/mobile is provided, login continues with password authentication only.</p>
        </div>

        <div class="form-group">
            <label for="password">Password <?= $editing ? '(leave blank to keep current)' : '' ?></label>
            <input id="password" name="password" type="password" minlength="8"
                   <?= $editing ? '' : 'required' ?>>
            <?php if ($editing && ($editing['account_source'] ?? '') === 'Homeowner'): ?><p class="form-note">For a Homeowner-created Resident account, entering a new password permanently resets the temporary password, clears the expiration, and skips the first-login password-change page.</p><?php endif; ?>
        </div>

        <div class="full">
            <button class="btn btn-primary" type="submit">
                <?= $editing ? 'Save Changes' : 'Create Account' ?>
            </button>
        </div>
    </form>
    </div>
</details>

<section class="section-card" style="margin-top:22px;">
    <div class="section-heading">
        <div>
            <h2>Registered Accounts</h2>
            <p>Homeowner profiles automatically receive Resident accounts. User Accounts remains available for staff and other manual account administration.</p>
        </div>
    </div>
    <form method="GET" class="filter-form user-search-form" style="margin:18px 0;">
        <div class="form-group"><label for="user-q">Search Accounts</label><input id="user-q" name="q" type="search" value="<?= e($q) ?>" placeholder="Username, role, status, or source"></div>
        <button class="btn btn-primary" type="submit">Search</button>
        <a class="btn btn-secondary" href="users.php">Clear</a>
    </form>

    <div class="data-table-wrap">
        <table class="data-table">
            <thead><tr><th>Username</th><th>Role</th><th>Source</th><th>Status</th><th>2FA</th><th>Created</th><th>Actions</th></tr></thead>
            <tbody>
            <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= e($user['username']) ?></td>
                    <td><?= e($user['role']) ?></td>
                    <td><?= e($user['account_source']) ?></td>
                    <td><span class="status-pill <?= e(status_class($user['status'])) ?>"><?= e($user['status']) ?></span></td>
                    <td><?= !empty($user['two_factor_enabled']) ? 'Enabled' : 'Off' ?></td>
                    <td><?= e($user['created_at']) ?></td>
                    <td class="actions">
                        <a class="btn btn-secondary btn-small" href="?edit=<?= (int)$user['user_id'] ?>">Edit</a>
                        <?php if ($user['status'] === 'Active' && (int)$user['user_id'] !== current_user_id()): ?>
                            <form method="POST" class="inline-form" onsubmit="return confirm('Deactivate this account?');">
                                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="action" value="deactivate">
                                <input type="hidden" name="user_id" value="<?= (int)$user['user_id'] ?>">
                                <button class="btn btn-danger btn-small" type="submit">Deactivate</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<script>
function confirmUserAccountSave(form){
    const roleField=form.querySelector('[name=role]');
    const userIdField=form.querySelector('[name=user_id]');
    const selectedRole=roleField ? roleField.value : '';
    const currentRole=form.dataset.currentRole || '';
    const isEditing=!!(userIdField && Number(userIdField.value)>0);
    if(isEditing && currentRole && currentRole!==selectedRole){
        const detail=selectedRole==='Administrator'
            ? ' This gives the account Administrator access to operational management functions.'
            : selectedRole==='Clerk'
                ? ' This gives the account Clerk access to day-to-day office functions.'
                : ' This makes the account a Resident account.';
        return window.confirm('You are changing this user’s role from '+currentRole+' to '+selectedRole+'.'+detail+'\n\nDo you want to continue and save this change?');
    }
    if(!isEditing){
        return window.confirm('Create this user account with the '+selectedRole+' role?\n\nPlease verify the role before continuing.');
    }
    return window.confirm('Save the changes made to this user account?');
}
function closeManualAccountConfirmation(){ const o=document.getElementById('manual-account-confirm-overlay'); if(o)o.remove(); }
</script>
<?php require __DIR__ . '/../includes/footer.php'; ?>
