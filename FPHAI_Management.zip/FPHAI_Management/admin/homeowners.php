<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('Administrator');
deactivate_expired_homeowner_accounts($pdo);

$pageTitle = 'Homeowner Records';
$error = '';
$editing = null;
$formInput = $_SERVER['REQUEST_METHOD'] === 'POST' ? $_POST : [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request token. Please try again.';
    } else {
        try {
            $action = $_POST['action'] ?? '';

            if ($action === 'save') {
                $id = (int)($_POST['homeowner_id'] ?? 0);
                $household = trim($_POST['household_name'] ?? '');
                $address = trim($_POST['address'] ?? '');
                $street = trim($_POST['street'] ?? '');
                $block = trim($_POST['block'] ?? '');
                $lot = trim($_POST['lot'] ?? '');
                $contact = trim($_POST['contact_number'] ?? '');
                $email = trim($_POST['email'] ?? '');
                $vehicles = max(0, (int)($_POST['no_of_vehicles'] ?? 0));
                $households = max(0, (int)($_POST['no_of_households'] ?? 1));
                $status = $_POST['membership_status'] ?? 'Active';

                if ($household === '' || $address === '' || $street === '' || $contact === '' || !in_array($status, ['Active','Inactive','Delinquent'], true)) {
                    throw new RuntimeException('Household name, house/address number, street, contact number, and membership status are required.');
                }
                // Adrian Street has no block number; other streets may use their mapped blocks.
                $streetBlocks = [
                    'Adrian Street'=>[], 'Banning Street'=>['39','40'], 'Bronx Street'=>['34','40','41','46'],
                    'Burney Street'=>['48','50','53'], 'Badger Street'=>['44','50'], 'Boles Street'=>['45','53'],
                    'Bryant Street'=>['49','50','51'], 'Butler Street'=>['33','34'], 'Bremen Street'=>['34','39','40'],
                    'Bronson Street'=>['45','46','47','48','49','51','53'], 'Burke Street'=>['48','49'], 'Baker Street'=>['38'],
                    'Byron Street'=>['45','48'], 'Bonner Street'=>['41','44','50','53']
                ];
                if (!array_key_exists($street, $streetBlocks)) {
                    throw new RuntimeException('Please select a valid street.');
                }
                if ($streetBlocks[$street] && $block === '') {
                    throw new RuntimeException('Please select the block for the selected street.');
                }
                if (!$streetBlocks[$street]) {
                    $block = '';
                }
                if (!preg_match('/^[0-9A-Za-z-]+$/', $address) || mb_strlen($address) > 20) {
                    throw new RuntimeException('House / Address No. must be 20 characters or fewer and may contain only letters, numbers, and hyphens.');
                }
                if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    throw new RuntimeException('Please enter a valid email address.');
                }

                $newImage = null;
                if (!empty($_FILES['profile_image']['name'])) {
                    $newImage = save_uploaded_image($_FILES['profile_image']);
                }

                // Prevent an exact duplicate homeowner profile. Image is intentionally excluded because
                // the same household can legitimately have a different profile photo.
                $duplicateSql = "SELECT homeowner_id FROM homeowners
                                 WHERE LOWER(TRIM(household_name)) = LOWER(TRIM(:household_name))
                                   AND LOWER(TRIM(address)) = LOWER(TRIM(:address))
                                   AND COALESCE(LOWER(TRIM(street)), '') = LOWER(TRIM(:street))
                                   AND COALESCE(LOWER(TRIM(block)), '') = LOWER(TRIM(:block))
                                   AND COALESCE(LOWER(TRIM(lot)), '') = LOWER(TRIM(:lot))
                                   AND COALESCE(TRIM(contact_number), '') = TRIM(:contact_number)
                                   AND COALESCE(LOWER(TRIM(email)), '') = LOWER(TRIM(:email))
                                   AND no_of_vehicles = :vehicles
                                   AND no_of_households = :households";
                $duplicateParams = [
                    'household_name'=>$household, 'address'=>$address, 'street'=>$street, 'block'=>$block, 'lot'=>$lot,
                    'contact_number'=>$contact, 'email'=>$email, 'vehicles'=>$vehicles, 'households'=>$households
                ];
                if ($id > 0) $duplicateSql .= ' AND homeowner_id <> :duplicate_id';
                if ($id > 0) $duplicateParams['duplicate_id'] = $id;
                $duplicateStmt = $pdo->prepare($duplicateSql);
                $duplicateStmt->execute($duplicateParams);
                if ($duplicateStmt->fetchColumn()) {
                    throw new RuntimeException('A homeowner profile with the same household name, address, block, lot, contact number, email, number of vehicles, and number of households already exists.');
                }

                $pdo->beginTransaction();
                if ($id > 0) {
                    $currentStmt = $pdo->prepare('SELECT profile_image_path FROM homeowners WHERE homeowner_id=:id FOR UPDATE');
                    $currentStmt->execute(['id'=>$id]);
                    $current = $currentStmt->fetch();
                    if (!$current) throw new RuntimeException('Homeowner record not found.');

                    $sql = 'UPDATE homeowners
                            SET household_name=:household_name, address=:address, street=:street, block=:block, lot=:lot,
                                contact_number=:contact_number, email=:email, no_of_vehicles=:vehicles,
                                no_of_households=:households, membership_status=:membership_status';
                    $params = [
                        'household_name'=>$household, 'address'=>$address, 'street'=>$street, 'block'=>$block,
                        'lot'=>$lot ?: null, 'contact_number'=>$contact, 'email'=>$email,
                        'vehicles'=>$vehicles, 'households'=>$households, 'membership_status'=>$status, 'id'=>$id
                    ];
                    if ($newImage !== null) {
                        $sql .= ', profile_image_path=:profile_image_path';
                        $params['profile_image_path'] = $newImage;
                    }
                    $sql .= ' WHERE homeowner_id=:id';
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute($params);

                    $syncUser = $pdo->prepare('UPDATE users SET email=:email, mobile_number=:mobile_number WHERE user_id=(SELECT user_id FROM homeowners WHERE homeowner_id=:homeowner_id)');
                    $syncUser->execute(['email'=>$email ?: null,'mobile_number'=>$contact ?: null,'homeowner_id'=>$id]);

                    $oldImage = $current['profile_image_path'] ?? null;
                    $message = 'Homeowner record updated.';
                    audit_log($pdo, current_user_id(), 'Updated', 'Homeowner Records', $id, 'Updated homeowner record.');
                    $pdo->commit();
                    if ($newImage !== null && $oldImage) @unlink(UPLOAD_DIR . $oldImage);
                    flash('success', $message);
                } else {
                    $stmt = $pdo->prepare(
                        'INSERT INTO homeowners
                         (household_name,address,street,block,lot,contact_number,email,no_of_vehicles,no_of_households,profile_image_path,membership_status)
                         VALUES (:household_name,:address,:street,:block,:lot,:contact_number,:email,:vehicles,:households,:profile_image_path,:membership_status)'
                    );
                    $stmt->execute([
                        'household_name'=>$household, 'address'=>$address, 'street'=>$street, 'block'=>$block,
                        'lot'=>$lot ?: null, 'contact_number'=>$contact, 'email'=>$email,
                        'vehicles'=>$vehicles, 'households'=>$households, 'profile_image_path'=>$newImage,
                        'membership_status'=>$status
                    ]);
                    $id = (int)$pdo->lastInsertId();

                    // A homeowner profile and its Resident account are one onboarding transaction.
                    // The account is created immediately so the two records can never be left
                    // disconnected merely because a confirmation modal was dismissed.
                    $username = generate_resident_username($pdo, $id, $household);
                    $temporaryPassword = generate_temporary_password();
                    $userStmt = $pdo->prepare(
                        'INSERT INTO users (username,email,mobile_number,two_factor_enabled,password_hash,role,status,account_source,must_change_password,temporary_password_expires_at)
                         VALUES (:username,:email,:mobile_number,0,:password_hash,"Resident","Active","Homeowner",1,DATE_ADD(NOW(), INTERVAL 2 HOUR))'
                    );
                    $userStmt->execute([
                        'username'=>$username,
                        'email'=>$email ?: null,
                        'mobile_number'=>$contact ?: null,
                        'password_hash'=>password_hash($temporaryPassword, PASSWORD_DEFAULT),
                    ]);
                    $userId = (int)$pdo->lastInsertId();
                    $pdo->prepare('UPDATE homeowners SET user_id=:user_id WHERE homeowner_id=:homeowner_id')
                        ->execute(['user_id'=>$userId,'homeowner_id'=>$id]);

                    audit_log($pdo, current_user_id(), 'Created', 'Homeowner Records', $id, 'Created homeowner profile and linked Resident account '.$username.'.');
                    $pdo->commit();
                    $_SESSION['created_account_confirmation'] = [
                        'homeowner_id' => $id,
                        'household_name' => $household,
                        'contact' => $contact,
                        'email' => $email,
                        'username' => $username,
                        'temporary_password' => $temporaryPassword,
                        'role' => 'Resident',
                        'source' => 'Homeowner',
                    ];
                    flash('success', 'Homeowner profile and linked Resident account created successfully.');
                }
                header('Location: homeowners.php');
                exit;
            }

            if ($action === 'link_existing_account') {
                $id = (int)($_POST['homeowner_id'] ?? 0);
                $userId = (int)($_POST['resident_user_id'] ?? 0);
                if ($id < 1 || $userId < 1) throw new RuntimeException('Select a homeowner and an existing Resident account.');
                $stmt = $pdo->prepare('SELECT user_id, household_name, contact_number, email, user_id FROM homeowners WHERE homeowner_id=:id');
                $stmt->execute(['id'=>$id]);
                $homeowner = $stmt->fetch();
                if (!$homeowner) throw new RuntimeException('Homeowner record not found.');
                if (!empty($homeowner['user_id'])) throw new RuntimeException('This homeowner is already linked to a Resident account.');
                $stmt = $pdo->prepare('SELECT u.user_id,u.username,u.role,u.status,u.email,u.mobile_number,h.homeowner_id AS linked_homeowner_id
                                       FROM users u LEFT JOIN homeowners h ON h.user_id=u.user_id
                                       WHERE u.user_id=:uid AND u.role="Resident" AND u.status="Active" LIMIT 1');
                $stmt->execute(['uid'=>$userId]);
                $resident = $stmt->fetch();
                if (!$resident) throw new RuntimeException('The selected account is not an active Resident account.');
                if (!empty($resident['linked_homeowner_id'])) throw new RuntimeException('That Resident account is already linked to another homeowner.');
                $username = $resident['username'];
                if (preg_match('/^resident\d{4}$/i', $username)) {
                    $candidate = generate_resident_username($pdo, $id, $homeowner['household_name']);
                    if ($candidate !== $username) {
                        $pdo->prepare('UPDATE users SET username=:username WHERE user_id=:uid')->execute(['username'=>$candidate,'uid'=>$userId]);
                        $username = $candidate;
                    }
                }
                $pdo->beginTransaction();
                try {
                    $pdo->prepare('UPDATE homeowners SET user_id=:uid WHERE homeowner_id=:hid')->execute(['uid'=>$userId,'hid'=>$id]);
                    $pdo->prepare('UPDATE users SET email=:email,mobile_number=:mobile WHERE user_id=:uid')->execute(['email'=>$homeowner['email']?:null,'mobile'=>$homeowner['contact_number']?:null,'uid'=>$userId]);
                    audit_log($pdo,current_user_id(),'Linked Account','Homeowner Records',$id,'Linked existing Resident account '.$username.' to homeowner profile.');
                    $pdo->commit();
                } catch (Throwable $e) { if($pdo->inTransaction())$pdo->rollBack(); throw $e; }
                flash('success','Existing Resident account linked successfully.');
                header('Location: homeowners.php'); exit;
            }

            if ($action === 'create_account') {
                $id = (int)($_POST['homeowner_id'] ?? 0);
                if ($id < 1) throw new RuntimeException('Invalid homeowner record.');
                $pdo->beginTransaction();
                $stmt = $pdo->prepare('SELECT user_id, household_name, contact_number, email FROM homeowners WHERE homeowner_id=:id FOR UPDATE');
                $stmt->execute(['id'=>$id]);
                $homeowner = $stmt->fetch();
                if (!$homeowner) throw new RuntimeException('Homeowner record not found.');
                if (!empty($homeowner['user_id'])) throw new RuntimeException('This homeowner already has a linked account.');
                $username = generate_resident_username($pdo, $id, $homeowner['household_name']);
                $temporaryPassword = generate_temporary_password();
                $userStmt = $pdo->prepare(
                    'INSERT INTO users (username,email,mobile_number,two_factor_enabled,password_hash,role,status,account_source,must_change_password,temporary_password_expires_at)
                     VALUES (:username,:email,:mobile_number,0,:password_hash,"Resident","Active","Homeowner",1,DATE_ADD(NOW(), INTERVAL 2 HOUR))'
                );
                $userStmt->execute([
                    'username'=>$username,
                    'email'=>$homeowner['email'] ?: null,
                    'mobile_number'=>$homeowner['contact_number'] ?: null,
                    'password_hash'=>password_hash($temporaryPassword, PASSWORD_DEFAULT),
                ]);
                $userId = (int)$pdo->lastInsertId();
                $pdo->prepare('UPDATE homeowners SET user_id=:user_id WHERE homeowner_id=:homeowner_id')->execute(['user_id'=>$userId,'homeowner_id'=>$id]);
                audit_log($pdo, current_user_id(), 'Created Account', 'Homeowner Records', $id, 'Created linked Resident account '.$username.' for an existing homeowner.');
                $pdo->commit();
                $_SESSION['created_account_confirmation'] = [
                    'homeowner_id'=>$id, 'household_name'=>$homeowner['household_name'],
                    'contact'=>$homeowner['contact_number'] ?? '', 'email'=>$homeowner['email'] ?? '',
                    'username'=>$username, 'temporary_password'=>$temporaryPassword,
                    'role'=>'Resident', 'source'=>'Homeowner'
                ];
                flash('success','Linked Resident account created successfully.');
                header('Location: homeowners.php');
                exit;
            }

            if ($action === 'status') {
                $id = (int)($_POST['homeowner_id'] ?? 0);
                $status = $_POST['membership_status'] ?? '';
                if (!in_array($status, ['Active','Inactive','Delinquent'], true)) throw new RuntimeException('Invalid membership status.');
                $stmt = $pdo->prepare('UPDATE homeowners SET membership_status=:status WHERE homeowner_id=:id');
                $stmt->execute(['status'=>$status,'id'=>$id]);
                if (in_array($status, ['Active','Inactive'], true)) {
                    $syncUser = $pdo->prepare('UPDATE users SET status=:user_status WHERE user_id=(SELECT user_id FROM homeowners WHERE homeowner_id=:id)');
                    $syncUser->execute(['user_status'=>$status, 'id'=>$id]);
                }
                audit_log($pdo, current_user_id(), 'Updated Status', 'Homeowner Records', $id, 'Changed membership status.');
                flash('success', 'Membership status updated.');
                header('Location: homeowners.php');
                exit;
            }

            if ($action === 'delete') {
                $id = (int)($_POST['homeowner_id'] ?? 0);
                if ($id < 1) throw new RuntimeException('Invalid homeowner record.');

                $pdo->beginTransaction();
                $stmt = $pdo->prepare('SELECT user_id, profile_image_path, household_name FROM homeowners WHERE homeowner_id=:id FOR UPDATE');
                $stmt->execute(['id'=>$id]);
                $homeowner = $stmt->fetch();
                if (!$homeowner) throw new RuntimeException('Homeowner record not found.');

                $paymentStmt = $pdo->prepare('SELECT COUNT(*) FROM payments WHERE homeowner_id=:id');
                $paymentStmt->execute(['id'=>$id]);
                if ((int)$paymentStmt->fetchColumn() > 0) {
                    throw new RuntimeException('This homeowner cannot be deleted because payment records already exist. Use Inactive status instead to preserve financial history.');
                }

                $pdo->prepare('DELETE FROM homeowners WHERE homeowner_id=:id')->execute(['id'=>$id]);
                if (!empty($homeowner['user_id'])) {
                    $userStmt = $pdo->prepare('SELECT account_source, role FROM users WHERE user_id=:user_id');
                    $userStmt->execute(['user_id'=>$homeowner['user_id']]);
                    $account = $userStmt->fetch();
                    if ($account && $account['account_source'] === 'Homeowner' && $account['role'] === 'Resident') {
                        $pdo->prepare('DELETE FROM users WHERE user_id=:user_id')->execute(['user_id'=>$homeowner['user_id']]);
                    }
                }
                audit_log($pdo, current_user_id(), 'Deleted', 'Homeowner Records', $id, 'Deleted homeowner duplicate/profile with no payment records.');
                $pdo->commit();
                if (!empty($homeowner['profile_image_path'])) @unlink(UPLOAD_DIR . $homeowner['profile_image_path']);
                flash('success', 'Homeowner record deleted.');
                header('Location: homeowners.php');
                exit;
            }
        } catch (PDOException $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = 'The homeowner record could not be saved. Please check the database fields and try again.';
        } catch (RuntimeException $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = $ex->getMessage();
        }
    }
}

$paymentHistory = [];
$paymentYearSummary = [];
$reservationHistory = [];
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT * FROM homeowners WHERE homeowner_id=:id');
    $stmt->execute(['id'=>(int)$_GET['edit']]);
    $editing = $stmt->fetch();
    if ($editing) {
        $historyStmt = $pdo->prepare(
            'SELECT p.payment_id, p.or_number, p.payment_date, p.amount, p.payment_method,
                    p.reference_number, p.description, p.status, p.created_at,
                    u.username AS encoded_username
             FROM payments p
             LEFT JOIN users u ON u.user_id=p.encoded_by
             WHERE p.homeowner_id=:homeowner_id
             ORDER BY p.payment_date DESC, p.payment_id DESC'
        );
        $historyStmt->execute(['homeowner_id'=>(int)$editing['homeowner_id']]);
        $paymentHistory = $historyStmt->fetchAll();
        foreach ($paymentHistory as $paymentRow) {
            $year = date('Y', strtotime($paymentRow['payment_date']));
            if (!isset($paymentYearSummary[$year])) {
                $paymentYearSummary[$year] = ['count'=>0,'validated'=>0.0,'total'=>0.0];
            }
            $paymentYearSummary[$year]['count']++;
            $paymentYearSummary[$year]['total'] += (float)$paymentRow['amount'];
            if ($paymentRow['status'] === 'Validated') {
                $paymentYearSummary[$year]['validated'] += (float)$paymentRow['amount'];
            }
        }
        $reservationHistoryStmt = $pdo->prepare('SELECT r.reservation_id,r.facility,r.reservation_date,r.start_time,r.end_time,r.requester_name,r.requester_type,r.payment_amount,r.status,rp.or_number AS payment_or,rp.payment_method,rp.status AS payment_status FROM reservations r LEFT JOIN reservation_payments rp ON rp.reservation_payment_id=(SELECT MAX(rp2.reservation_payment_id) FROM reservation_payments rp2 WHERE rp2.reservation_id=r.reservation_id) WHERE r.homeowner_id=:homeowner_id ORDER BY r.reservation_date DESC,r.reservation_id DESC');
        $reservationHistoryStmt->execute(['homeowner_id'=>(int)$editing['homeowner_id']]);
        $reservationHistory = $reservationHistoryStmt->fetchAll();
    }
}

$q = trim($_GET['q'] ?? '');
$streetFilter = trim($_GET['street'] ?? '');
$streetOptions = ['Adrian Street','Banning Street','Bronx Street','Burney Street','Badger Street','Boles Street','Bryant Street','Butler Street','Bremen Street','Bronson Street','Burke Street','Baker Street','Byron Street','Bonner Street'];
$sql = 'SELECT h.*, u.username AS resident_username, u.status AS account_status
        FROM homeowners h
        LEFT JOIN users u ON u.user_id=h.user_id';
$params = [];
$where = [];
if ($q !== '') {
    $where[] = '(h.household_name LIKE :household_q OR h.address LIKE :address_q OR h.street LIKE :street_q OR h.block LIKE :block_q OR h.lot LIKE :lot_q OR h.contact_number LIKE :contact_q OR h.email LIKE :email_q OR h.membership_status LIKE :status_q OR u.username LIKE :username_q)';
    $search = "%{$q}%";
    $params += ['household_q'=>$search,'address_q'=>$search,'street_q'=>$search,'block_q'=>$search,'lot_q'=>$search,'contact_q'=>$search,'email_q'=>$search,'status_q'=>$search,'username_q'=>$search];
}
if ($streetFilter !== '' && in_array($streetFilter, $streetOptions, true)) {
    $where[] = 'h.street = :street_filter';
    $params['street_filter'] = $streetFilter;
}
if ($where) $sql .= ' WHERE '.implode(' AND ', $where);
$sql .= ' ORDER BY h.street, h.block, h.lot, h.household_name';
$stmt = $pdo->prepare($sql); $stmt->execute($params); $homeowners = $stmt->fetchAll();
$streetCountRows = $pdo->query("SELECT COALESCE(NULLIF(TRIM(street), ''), 'Unassigned Street') AS street_name, COUNT(*) AS homeowner_count FROM homeowners GROUP BY COALESCE(NULLIF(TRIM(street), ''), 'Unassigned Street') ORDER BY street_name")->fetchAll();
$streetCounts = [];
foreach ($streetCountRows as $row) $streetCounts[$row['street_name']] = (int)$row['homeowner_count'];

$paymentYearRows = $pdo->query(
    'SELECT homeowner_id, YEAR(payment_date) AS payment_year, COUNT(*) AS payment_count,
            MIN(payment_date) AS first_payment_date,
            COALESCE(SUM(amount),0) AS total_amount,
            COALESCE(SUM(CASE WHEN status="Validated" THEN amount ELSE 0 END),0) AS validated_amount
     FROM payments
     GROUP BY homeowner_id, YEAR(payment_date)
     ORDER BY payment_year DESC'
)->fetchAll();
$homeownerPaymentYears = [];
$homeownerPaymentCounts = [];
foreach ($paymentYearRows as $row) {
    $hid = (int)$row['homeowner_id'];
    $homeownerPaymentYears[$hid][] = $row;
    $homeownerPaymentCounts[$hid] = ($homeownerPaymentCounts[$hid] ?? 0) + (int)$row['payment_count'];
}
$recentPaymentRows = $pdo->query(
    'SELECT homeowner_id, payment_date, or_number, amount, status, description
     FROM payments ORDER BY payment_date DESC, payment_id DESC'
)->fetchAll();
$homeownerRecentPayments = [];
foreach ($recentPaymentRows as $row) {
    $hid = (int)$row['homeowner_id'];
    if (!isset($homeownerRecentPayments[$hid])) $homeownerRecentPayments[$hid] = [];
    if (count($homeownerRecentPayments[$hid]) < 3) $homeownerRecentPayments[$hid][] = $row;
}

$reservationHistoryRows = $pdo->query(
    'SELECT r.reservation_id,r.homeowner_id,r.facility,r.reservation_date,r.start_time,r.end_time,r.payment_amount,r.status,r.requester_name,
            rp.or_number AS payment_or,rp.payment_method AS payment_method,rp.status AS payment_status
     FROM reservations r
     LEFT JOIN reservation_payments rp ON rp.reservation_payment_id=(SELECT MAX(rp2.reservation_payment_id) FROM reservation_payments rp2 WHERE rp2.reservation_id=r.reservation_id)
     WHERE r.homeowner_id IS NOT NULL
     ORDER BY r.reservation_date DESC,r.reservation_id DESC'
)->fetchAll();
$homeownerReservationCounts=[]; $homeownerReservationYears=[]; $homeownerRecentReservations=[];
foreach($reservationHistoryRows as $rr){
    $hid=(int)$rr['homeowner_id']; $homeownerReservationCounts[$hid]=($homeownerReservationCounts[$hid]??0)+1;
    $yr=date('Y',strtotime($rr['reservation_date']));
    if(!isset($homeownerReservationYears[$hid][$yr])) $homeownerReservationYears[$hid][$yr]=['count'=>0,'completed_revenue'=>0.0];
    $homeownerReservationYears[$hid][$yr]['count']++;
    if($rr['status']==='Completed' && $rr['payment_status']==='Validated') $homeownerReservationYears[$hid][$yr]['completed_revenue']+=(float)$rr['payment_amount'];
    if(!isset($homeownerRecentReservations[$hid])) $homeownerRecentReservations[$hid]=[];
    if(count($homeownerRecentReservations[$hid])<5) $homeownerRecentReservations[$hid][]=$rr;
}

$unlinkedResidentStmt = $pdo->query('SELECT u.user_id,u.username,h.homeowner_id AS linked_homeowner_id FROM users u LEFT JOIN homeowners h ON h.user_id=u.user_id WHERE u.role="Resident" AND u.status="Active" ORDER BY u.username');
$unlinkedResidents = array_values(array_filter($unlinkedResidentStmt->fetchAll(), fn($r) => empty($r['linked_homeowner_id'])));

require __DIR__ . '/../includes/header.php';
$flash = get_flash();
?>
<?php if ($flash): ?><div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
<?php
$accountConfirmation = $_SESSION['created_account_confirmation'] ?? null;
unset($_SESSION['created_account_confirmation']);
?>
<?php if ($accountConfirmation): ?>
<div class="account-confirm-overlay" id="account-confirm-overlay" role="dialog" aria-modal="true" aria-labelledby="account-confirm-title">
    <div class="account-confirm-modal account-confirm-wide">
        <div class="account-confirm-header"><span class="section-kicker">Resident Account Created</span><h2 id="account-confirm-title">Record and Share Account Details</h2></div>
        <p class="form-note">The account has now been created. Record these credentials for the resident. The temporary password is valid for <strong>2 hours</strong> and must be changed on first login.</p>
        <div class="account-confirm-grid">
            <div><span>Household</span><strong><?= e($accountConfirmation['household_name']) ?></strong></div>
            <div><span>Username</span><strong><?= e($accountConfirmation['username']) ?></strong></div>
            <div><span>Role</span><strong><?= e($accountConfirmation['role']) ?></strong></div>
            <div><span>Account Source</span><strong><?= e($accountConfirmation['source']) ?></strong></div>
            <div><span>Contact</span><strong><?= e($accountConfirmation['contact'] ?: 'No contact number') ?></strong></div>
            <div><span>Email</span><strong><?= e($accountConfirmation['email'] ?: 'No email address') ?></strong></div>
            <div class="account-confirm-password"><span>Temporary Password</span><strong><?= e($accountConfirmation['temporary_password']) ?></strong></div>
        </div>
        <div class="account-message-grid">
            <div class="account-message-card">
                <div class="message-card-heading"><strong>Email Draft</strong><button class="btn btn-secondary btn-small" type="button" onclick="copyAccountMessage('email-draft')">Copy</button></div>
                <textarea id="email-draft" readonly><?= e("Subject: Your Fairmont Park HOA Resident Account

Hello {$accountConfirmation['household_name']},

Your Resident account for the Fairmont Park HOA Management System has been created.

Username: {$accountConfirmation['username']}
Temporary Password: {$accountConfirmation['temporary_password']}
Account: Resident

Please sign in and change your temporary password immediately. The temporary password is valid for 2 hours from account creation.

Fairmont Park Homeowners' Association, Inc.") ?></textarea>
                <?php if (!empty($accountConfirmation['email'])):
    $gmailSubject = rawurlencode('Fairmont Park HOA Resident Account');
    $gmailBody = rawurlencode("Hello {$accountConfirmation['household_name']},

Your Resident account for the Fairmont Park HOA Management System has been created.

Username: {$accountConfirmation['username']}
Temporary Password: {$accountConfirmation['temporary_password']}
Account: Resident

Please sign in and change your temporary password immediately. The temporary password is valid for 2 hours from account creation.

Fairmont Park Homeowners' Association, Inc.");
    $gmailUrl = 'https://mail.google.com/mail/?view=cm&fs=1&to=' . rawurlencode($accountConfirmation['email']) . '&su=' . $gmailSubject . '&body=' . $gmailBody;
?><a class="btn btn-primary btn-small" href="<?= e($gmailUrl) ?>" target="_blank" rel="noopener">Open Gmail</a><?php endif; ?>
            </div>
            <div class="account-message-card">
                <div class="message-card-heading"><strong>SMS Draft</strong><button class="btn btn-secondary btn-small" type="button" onclick="copyAccountMessage('sms-draft')">Copy</button></div>
                <textarea id="sms-draft" readonly><?= e("Fairmont Park HOA: Your Resident account is ready. Username: {$accountConfirmation['username']} | Temporary password: {$accountConfirmation['temporary_password']} | Valid for 2 hours. Please sign in and change your password immediately.") ?></textarea>
                <?php if (!empty($accountConfirmation['contact'])): ?><a class="btn btn-primary btn-small" href="sms:<?= e(preg_replace('/[^0-9+]/','',$accountConfirmation['contact'])) ?>">Open SMS</a><?php endif; ?>
            </div>
        </div>
        <div class="account-confirm-actions"><button class="btn btn-primary" type="button" onclick="const o=this.closest('.account-confirm-overlay'); if(o){o.remove(); document.body.classList.remove('modal-open');}">I Have Recorded These Details</button></div>
    </div>
</div>
<?php endif; ?>

<details class="section-card foldable-panel"<?= ($editing || $error) ? ' open' : '' ?> id="homeowner-form-section">
    <summary><span><strong><?= $editing ? 'Edit Homeowner' : 'Add Homeowner' ?></strong><small><?= $editing ? 'Edit the selected homeowner profile.' : 'Open this section when you need to add a homeowner.' ?></small></span><span class="fold-chevron">⌄</span></summary>
    <div class="foldable-content">
    <div class="section-heading">
        <div>
            <h2><?= $editing ? 'Edit Homeowner' : 'Add Homeowner' ?></h2>
            <p>A linked Resident account is created automatically with the homeowner profile. The confirmation prompt only displays the credentials for recording.</p>
        </div>
        <?php if ($editing): ?><a class="btn btn-secondary" href="homeowners.php">Cancel Edit</a><?php endif; ?>
    </div>

    <form method="POST" enctype="multipart/form-data" class="form-grid">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="homeowner_id" value="<?= (int)($editing['homeowner_id'] ?? 0) ?>">

        <div class="form-group"><label for="household_name">Household Name</label><input id="household_name" name="household_name" type="text" maxlength="150" value="<?= e($editing['household_name'] ?? ($formInput['household_name'] ?? '')) ?>" required></div>
        <div class="form-group compact-address-field"><label for="address">House / Address No.</label><input id="address" name="address" type="text" maxlength="20" pattern="[0-9A-Za-z-]+" value="<?= e($editing['address'] ?? ($formInput['address'] ?? '')) ?>" placeholder="e.g. 25-A, 17, 4-B" required></div>
        <div class="form-group"><label for="street">Street</label><select id="street" name="street" required><option value="">Select street</option><?php foreach (['Adrian Street','Banning Street','Bronx Street','Burney Street','Badger Street','Boles Street','Bryant Street','Butler Street','Bremen Street','Bronson Street','Burke Street','Baker Street','Byron Street','Bonner Street'] as $streetOption): ?><option value="<?= e($streetOption) ?>" <?= (($editing['street'] ?? ($formInput['street'] ?? '')) === $streetOption) ? 'selected' : '' ?>><?= e($streetOption) ?></option><?php endforeach; ?></select></div>
        <div class="form-group compact-location-field"><label for="block">Block</label><select id="block" name="block"><option value="">Select block</option></select></div>
        <div class="form-group compact-location-field"><label for="lot">Lot</label><input id="lot" name="lot" type="text" maxlength="10" value="<?= e($editing['lot'] ?? '') ?>" placeholder="e.g. 8-A"></div>
        <div class="form-group"><label for="contact_number">Contact Number</label><input id="contact_number" name="contact_number" type="text" maxlength="50" value="<?= e($editing['contact_number'] ?? ($formInput['contact_number'] ?? '')) ?>" required></div>
        <div class="form-group"><label for="email">Email</label><input id="email" name="email" type="email" maxlength="150" value="<?= e($editing['email'] ?? ($formInput['email'] ?? '')) ?>"></div>
        <div class="form-group"><label for="no_of_households">No. of Households</label><input id="no_of_households" name="no_of_households" type="number" min="0" max="999" value="<?= (int)($editing['no_of_households'] ?? ($formInput['no_of_households'] ?? 1)) ?>" required></div>
        <div class="form-group"><label for="no_of_vehicles">No. of Vehicles</label><input id="no_of_vehicles" name="no_of_vehicles" type="number" min="0" max="999" value="<?= (int)($editing['no_of_vehicles'] ?? ($formInput['no_of_vehicles'] ?? 0)) ?>" required></div>
        <div class="form-group"><label for="profile_image">Homeowner Picture</label><input id="profile_image" name="profile_image" type="file" accept="image/jpeg,image/png,image/webp"><p class="form-note">Optional. JPG, PNG, or WEBP, up to 10 MB.</p></div>
        <div class="form-group"><label for="membership_status">Membership Status</label><select id="membership_status" name="membership_status" required><?php foreach (['Active','Inactive','Delinquent'] as $status): ?><option value="<?= e($status) ?>" <?= (($editing['membership_status'] ?? ($formInput['membership_status'] ?? 'Active')) === $status) ? 'selected' : '' ?>><?= e($status) ?></option><?php endforeach; ?></select></div>
        <?php if (!empty($editing['profile_image_path'])): ?><div class="form-group"><label>Current Picture</label><img src="../homeowner_image.php?id=<?= (int)$editing['homeowner_id'] ?>" alt="Current homeowner picture" class="homeowner-photo-large"></div><?php endif; ?>
        <div class="full"><button class="btn btn-primary" type="submit"><?= $editing ? 'Save Changes' : 'Add Homeowner' ?></button></div>
    </form>
    </div>
</details>

<?php if ($editing): ?>
<section class="section-card payment-history-section" style="margin-top:22px;">
    <div class="section-heading"><div><h2>Homeowner History</h2><p>Review the resident's payment and reservation records without expanding the page into a long list.</p></div><span class="status-pill status-neutral"><?= number_format(count($paymentHistory)) ?> payments · <?= number_format(count($reservationHistory)) ?> reservations</span></div>
    <div class="profile-tabs" data-profile-tabs>
        <div class="profile-tab-buttons" role="tablist">
            <button type="button" class="profile-tab-button is-active" role="tab" aria-selected="true" data-tab-target="payment-history-tab">Payment History</button>
            <button type="button" class="profile-tab-button" role="tab" aria-selected="false" data-tab-target="reservation-history-tab">Reservation History</button>
        </div>
        <div id="payment-history-tab" class="profile-tab-panel is-active" role="tabpanel">
            <div class="section-heading"><div><strong>Payment History</strong><p class="form-note">Complete regular HOA payment records for <?= e($editing['household_name']) ?>.</p></div><?php if ($paymentHistory): ?><a class="btn btn-secondary btn-small" target="_blank" href="../homeowner_payment_history.php?homeowner_id=<?= (int)$editing['homeowner_id'] ?>">Print Payment History</a><?php endif; ?></div>
            <?php if ($paymentHistory): ?><div class="payment-history-summary"><?php foreach ($paymentYearSummary as $year => $summary): ?><div class="history-year-card"><span><?= e($year) ?></span><strong>₱<?= number_format($summary['validated'],2) ?></strong><small><?= number_format($summary['count']) ?> payment<?= $summary['count']===1?'':'s' ?> · Validated total</small></div><?php endforeach; ?></div><div class="data-table-wrap"><table class="data-table"><thead><tr><th>Date</th><th>SI Number</th><th>Amount</th><th>Method</th><th>Description</th><th>Status</th><th>Encoded By</th></tr></thead><tbody><?php foreach ($paymentHistory as $ph): ?><tr class="clickable-history-row" tabindex="0" data-history-detail="<?= e(json_encode(['Date'=>$ph['payment_date'],'SI Number'=>$ph['or_number'],'Amount'=>'₱'.number_format((float)$ph['amount'],2),'Payment Method'=>$ph['payment_method'],'Reference'=>$ph['reference_number']?:'—','Description'=>$ph['description']?:'—','Status'=>$ph['status'],'Encoded By'=>$ph['encoded_username']?:'—'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)) ?>"><td><?= e($ph['payment_date']) ?></td><td><?= e($ph['or_number']) ?></td><td>₱<?= number_format((float)$ph['amount'],2) ?></td><td><?= e($ph['payment_method']) ?><?= $ph['reference_number'] ? '<br><small>'.e($ph['reference_number']).'</small>' : '' ?></td><td class="table-description" title="<?= e($ph['description'] ?? '') ?>"><?= e(mb_strimwidth($ph['description'] ?? '—',0,60,'…','UTF-8')) ?></td><td><span class="status-pill <?= e(status_class($ph['status'])) ?>"><?= e($ph['status']) ?></span></td><td><?= e($ph['encoded_username'] ?? '—') ?></td></tr><?php endforeach; ?></tbody></table></div><?php else: ?><div class="request-empty">No payment history has been recorded for this homeowner yet.</div><?php endif; ?>
        </div>
        <div id="reservation-history-tab" class="profile-tab-panel" role="tabpanel">
            <div class="section-heading"><div><strong>Reservation History</strong><p class="form-note">Facility reservation requests and their cash payment records for <?= e($editing['household_name']) ?>.</p></div><?php if ($reservationHistory): ?><a class="btn btn-secondary btn-small" target="_blank" href="../homeowner_reservation_history.php?homeowner_id=<?= (int)$editing['homeowner_id'] ?>">Print Reservation History</a><?php endif; ?></div>
            <?php if ($reservationHistory): ?><div class="data-table-wrap"><table class="data-table"><thead><tr><th>Date</th><th>Facility</th><th>Time</th><th>Requester</th><th>Fee</th><th>Payment OR</th><th>Payment</th><th>Status</th></tr></thead><tbody><?php foreach ($reservationHistory as $rh): ?><tr class="clickable-history-row" tabindex="0" data-history-detail="<?= e(json_encode(['Date'=>$rh['reservation_date'],'Facility'=>$rh['facility'],'Time'=>date('g:i A',strtotime($rh['start_time'])).'–'.date('g:i A',strtotime($rh['end_time'])),'Requester'=>$rh['requester_name'],'Requester Type'=>$rh['requester_type'],'Reservation Fee'=>'₱'.number_format((float)$rh['payment_amount'],2),'Payment OR'=>$rh['payment_or']?:'—','Payment'=>$rh['payment_status']?:'Not recorded','Status'=>$rh['status']],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)) ?>"><td><?= e($rh['reservation_date']) ?></td><td><?= e($rh['facility']) ?></td><td><?= e(date('g:i A',strtotime($rh['start_time']))) ?>–<?= e(date('g:i A',strtotime($rh['end_time']))) ?></td><td><?= e($rh['requester_name']) ?> <small>(<?= e($rh['requester_type']) ?>)</small></td><td>₱<?= number_format((float)$rh['payment_amount'],2) ?></td><td><?= e($rh['payment_or'] ?: '—') ?></td><td><?= e($rh['payment_status'] ?: 'Not recorded') ?></td><td><span class="status-pill <?= e(status_class($rh['status'])) ?>"><?= e($rh['status']) ?></span></td></tr><?php endforeach; ?></tbody></table></div><?php else: ?><div class="request-empty">No reservation history has been recorded for this homeowner yet.</div><?php endif; ?>
        </div>
    </div>
</section>
<?php endif; ?>
<div id="history-detail-modal" class="record-detail-overlay" hidden><div class="record-detail-modal" role="dialog" aria-modal="true"><div class="section-heading"><div><span class="section-kicker">Homeowner History</span><h2>Record Details</h2></div><button type="button" class="btn btn-secondary btn-small" id="close-history-detail">Close</button></div><div id="history-detail-grid" class="record-detail-grid"></div></div></div>
<script>document.addEventListener('DOMContentLoaded',function(){const modal=document.getElementById('history-detail-modal'),grid=document.getElementById('history-detail-grid'),close=document.getElementById('close-history-detail');if(modal){const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));document.querySelectorAll('.clickable-history-row').forEach(row=>{const open=()=>{const d=JSON.parse(row.dataset.historyDetail||'{}');grid.innerHTML=Object.entries(d).map(([k,v])=>'<div><span>'+esc(k)+'</span><strong>'+esc(v)+'</strong></div>').join('');modal.hidden=false;};row.addEventListener('click',open);row.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();open();}});});close&&close.addEventListener('click',()=>modal.hidden=true);modal.addEventListener('click',e=>{if(e.target===modal)modal.hidden=true;});}document.querySelectorAll('[data-profile-tabs]').forEach(function(tabs){const buttons=[...tabs.querySelectorAll('.profile-tab-button')],panels=[...tabs.querySelectorAll('.profile-tab-panel')];buttons.forEach(btn=>btn.addEventListener('click',function(){buttons.forEach(b=>{b.classList.remove('is-active');b.setAttribute('aria-selected','false');});panels.forEach(p=>p.classList.remove('is-active'));btn.classList.add('is-active');btn.setAttribute('aria-selected','true');const panel=tabs.querySelector('#'+btn.dataset.tabTarget);if(panel)panel.classList.add('is-active');}));});});</script>

<section class="section-card" style="margin-top:22px;">
    <div class="toolbar"><div><h2 style="margin:0;">Homeowner List</h2><p class="form-note">Search by household, street, block, lot, username, contact, email, address, or membership status. Click a street below to filter the list.</p></div><form method="GET" class="filter-form homeowner-search-filter"><div class="form-group"><label for="q">Search Records</label><input id="q" name="q" type="search" value="<?= e($q) ?>" placeholder="Name, street, block, username, lot…"></div><button class="btn btn-primary" type="submit">Search</button><a class="btn btn-secondary" href="homeowners.php">Clear</a></form></div>
<div class="street-count-panel"><div class="street-count-heading"><strong>Homeowners by Street</strong><span><?= number_format(count($homeowners)) ?> shown<?= $streetFilter ? ' · filtered to '.e($streetFilter) : '' ?></span></div><div class="street-count-grid" role="list" aria-label="Homeowners by Street"><?php foreach ($streetOptions as $streetOption): $isSelected = $streetFilter === $streetOption; $streetHref = $isSelected ? 'homeowners.php' : 'homeowners.php?street='.rawurlencode($streetOption); ?><a class="street-count-item <?= $isSelected ? 'is-selected' : '' ?>" href="<?= e($streetHref) ?>" role="listitem" aria-pressed="<?= $isSelected ? 'true' : 'false' ?>"><span><?= e($streetOption) ?></span><strong><?= number_format($streetCounts[$streetOption] ?? 0) ?></strong></a><?php endforeach; ?></div></div>
    <div class="homeowner-card-grid">
    <?php foreach ($homeowners as $h):
        $hid=(int)$h['homeowner_id'];
        $paymentCount=(int)($homeownerPaymentCounts[$hid] ?? 0);
        $years=$homeownerPaymentYears[$hid] ?? [];
        $recent=$homeownerRecentPayments[$hid] ?? [];
    ?>
        <details class="homeowner-profile-card">
            <summary class="homeowner-card-summary">
                <div class="homeowner-profile-identity">
                    <?php if (!empty($h['profile_image_path'])): ?><img src="../homeowner_image.php?id=<?= (int)$h['homeowner_id'] ?>" alt="Homeowner picture" class="homeowner-profile-photo"><?php else: ?><div class="homeowner-profile-photo photo-placeholder">No picture</div><?php endif; ?>
                    <div><h3><?= e($h['household_name']) ?></h3><p><?= e(homeowner_full_address($h)) ?></p><span class="status-pill <?= e(status_class($h['membership_status'])) ?>"><?= e($h['membership_status']) ?></span></div>
                </div>
                <div class="homeowner-summary-right"><span><?= $paymentCount ? number_format($paymentCount).' payment record'.($paymentCount===1?'':'s') : 'No payment records' ?></span><strong><?= $h['resident_username'] ? 'Resident account: '.e($h['resident_username']) : 'No Resident Account' ?></strong><span class="fold-chevron">⌄</span></div>
            </summary>
            <div class="homeowner-profile-expanded">
                <div class="homeowner-profile-header">
                    <div class="homeowner-profile-identity">
                        <?php if (!empty($h['profile_image_path'])): ?><img src="../homeowner_image.php?id=<?= (int)$h['homeowner_id'] ?>" alt="Homeowner picture" class="homeowner-profile-photo"><?php else: ?><div class="homeowner-profile-photo photo-placeholder">No picture</div><?php endif; ?>
                        <div><h3><?= e($h['household_name']) ?></h3><p><?= e(homeowner_full_address($h)) ?></p><span class="status-pill <?= e(status_class($h['membership_status'])) ?>"><?= e($h['membership_status']) ?></span></div>
                    </div>
                    <div class="homeowner-profile-account"><?php if (!empty($h['resident_username'])): ?><strong>Resident Account</strong><span><?= e($h['resident_username']) ?></span><small><?= e($h['account_status']) ?></small><?php else: ?><strong>No Resident Account</strong><?php endif; ?></div>
                </div>
                <div class="homeowner-profile-details">
                    <div><span>Block / Lot</span><strong><?= e(trim(($h['block'] ?? '').' / '.($h['lot'] ?? ''),' /')) ?: '—' ?></strong></div>
                    <div><span>Contact</span><strong><?= e($h['contact_number'] ?: '—') ?></strong></div>
                    <div><span>Email</span><strong><?= e($h['email'] ?: '—') ?></strong></div>
                    <div><span>Households / Vehicles</span><strong><?= number_format((int)$h['no_of_households']) ?> / <?= number_format((int)$h['no_of_vehicles']) ?></strong></div>
                </div>
                <?php
                    $memberSince = null;
                    if ($years && !empty($years[count($years)-1]['first_payment_date'])) {
                        $memberSince = $years[count($years)-1]['first_payment_date'];
                    }
                    if (!$memberSince) $memberSince = $h['created_at'];
                ?>
                <div class="fairmont-history-card">
                    <div class="profile-card-heading"><strong>Fairmont Record History</strong><span>Essential record information</span></div>
                    <div class="history-facts history-facts-compact">
                        <span><strong>Member since</strong> <?= e(date('F d, Y', strtotime($memberSince))) ?></span>
                        <span><strong>Payment records</strong> <?= number_format($paymentCount) ?></span>
                        <span><strong>Last payment</strong> <?= !empty($recent[0]['payment_date']) ? e(date('F d, Y', strtotime($recent[0]['payment_date']))) : 'No payment recorded' ?></span>
                    </div>
                </div>
                <details class="profile-payment-card profile-payment-details">
                    <summary class="profile-card-heading"><strong>Payment History</strong><span><?= $paymentCount ? 'View history throughout the years' : 'No records yet' ?> <span class="fold-chevron">⌄</span></span></summary>
                    <div class="profile-payment-content">
                        <?php if ($years): ?><div class="profile-year-grid"><?php foreach ($years as $yr): ?><div class="profile-year-item"><strong><?= e($yr['payment_year']) ?></strong><span><?= number_format((int)$yr['payment_count']) ?> payment<?= (int)$yr['payment_count']===1?'':'s' ?></span><b>₱<?= number_format((float)$yr['validated_amount'],2) ?></b><small>Validated</small></div><?php endforeach; ?></div><?php else: ?><div class="request-empty">No payment history has been recorded for this homeowner.</div><?php endif; ?>
                        <?php if ($recent): ?><div class="profile-recent-payments"><strong>Recent records</strong><?php foreach ($recent as $rp): ?><div class="profile-payment-row"><span><?= e($rp['payment_date']) ?> · <?= e($rp['or_number']) ?></span><span>₱<?= number_format((float)$rp['amount'],2) ?> · <?= e($rp['status']) ?></span></div><?php endforeach; ?></div><?php endif; ?>
                    </div>
                </details>
                <?php $reservationCount=(int)($homeownerReservationCounts[$hid]??0); $reservationYears=$homeownerReservationYears[$hid]??[]; $recentReservations=$homeownerRecentReservations[$hid]??[]; ?>
                <details class="profile-payment-card profile-reservation-details">
                    <summary class="profile-card-heading"><strong>Reservation History</strong><span><?= $reservationCount ? 'View facility reservation history' : 'No reservation records yet' ?> <span class="fold-chevron">⌄</span></span></summary>
                    <div class="profile-payment-content">
                        <?php if($reservationYears): ?><div class="profile-year-grid"><?php foreach($reservationYears as $yr=>$summary): ?><div class="profile-year-item"><strong><?=e($yr)?></strong><span><?=number_format($summary['count'])?> reservation<?=((int)$summary['count']===1?'':'s')?></span><b>₱<?=number_format((float)$summary['completed_revenue'],2)?></b><small>Paid completed revenue</small></div><?php endforeach; ?></div><?php else: ?><div class="request-empty">No reservation history has been recorded for this homeowner.</div><?php endif; ?>
                        <?php if($recentReservations): ?><div class="profile-recent-payments"><strong>Recent reservations</strong><?php foreach($recentReservations as $rr): ?><div class="profile-payment-row"><span><?=e($rr['reservation_date'])?> · <?=e($rr['facility'])?> · <?=e(date('g:i A',strtotime($rr['start_time'])))?>–<?=e(date('g:i A',strtotime($rr['end_time'])))?></span><span>₱<?=number_format((float)$rr['payment_amount'],2)?> · <?=e($rr['status'])?></span></div><?php endforeach; ?></div><?php endif; ?>
                    </div>
                </details>
                <div class="homeowner-profile-actions">
                    <a class="btn btn-secondary btn-small" href="?edit=<?= $hid ?>">Edit Profile</a>
                    <a class="btn btn-secondary btn-small" target="_blank" href="../homeowner_payment_history.php?homeowner_id=<?= $hid ?>">Print Collection History</a>
                    <a class="btn btn-secondary btn-small" target="_blank" href="../homeowner_reservation_history.php?homeowner_id=<?= $hid ?>">Print Reservation History</a>
                    <?php if (empty($h['user_id'])): ?>
                    <div class="account-link-tools">
                        <form method="POST" class="inline-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="create_account"><input type="hidden" name="homeowner_id" value="<?= $hid ?>"><button class="btn btn-primary btn-small" type="submit">Create Account</button></form>
                        <?php if ($unlinkedResidents): ?><form method="POST" class="inline-form account-link-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="link_existing_account"><input type="hidden" name="homeowner_id" value="<?= $hid ?>"><select name="resident_user_id" aria-label="Existing Resident account"><option value="">Link Existing Resident…</option><?php foreach($unlinkedResidents as $ur): ?><option value="<?= (int)$ur['user_id'] ?>"><?= e($ur['username']) ?></option><?php endforeach; ?></select><button class="btn btn-secondary btn-small" type="submit">Link Account</button></form><?php endif; ?>
                    </div>
                <?php endif; ?>
                    <div class="status-action-group"><span>Set status:</span><?php foreach(['Active','Inactive','Delinquent'] as $st): ?><form method="POST" class="inline-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="status"><input type="hidden" name="homeowner_id" value="<?= $hid ?>"><input type="hidden" name="membership_status" value="<?= e($st) ?>"><button class="btn btn-small <?= $h['membership_status']===$st?'btn-primary':'btn-secondary' ?>" type="submit"><?= e($st) ?></button></form><?php endforeach; ?></div>
                    <form method="POST" class="inline-form"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="homeowner_id" value="<?= $hid ?>"><button class="btn btn-danger btn-small" type="submit" onclick="return confirmHomeownerDelete(this, <?= $paymentCount ? 'true' : 'false' ?>, <?= json_encode($h['household_name']) ?>);">Delete</button></form>
                </div>
            </div>
        </details>
    <?php endforeach; ?>
    <?php if (!$homeowners): ?><div class="request-empty">No homeowner records found.</div><?php endif; ?>
    </div>
</section>
<script>
function closeAccountCreationPrompt() { const overlay=document.getElementById('account-create-prompt'); if(overlay) overlay.remove(); }
function closeAccountConfirmation() { const overlay=document.getElementById('account-confirm-overlay'); if(overlay) overlay.remove(); document.body.classList.remove('modal-open'); }
function confirmHomeownerDelete(form, hasPayments, household){ if(hasPayments){ alert('This homeowner has payment records and cannot be permanently deleted. Use Inactive status instead so the financial history is preserved.'); return false; } return window.confirm('Delete the homeowner profile for '+household+'?

No payment records are attached to this profile. If it has a linked Resident account, that account will also be deleted.

This action cannot be undone.'); }
async function copyAccountMessage(id){
    const el=document.getElementById(id);
    if(!el)return;
    const text=el.value || '';
    let copied=false;
    try{
        if(navigator.clipboard && window.isSecureContext){
            await navigator.clipboard.writeText(text);
            copied=true;
        }
    }catch(e){}
    if(!copied){
        el.focus();
        el.select();
        el.setSelectionRange(0, el.value.length);
        try{ copied=document.execCommand('copy'); }catch(e){ copied=false; }
    }
    if(copied){
        el.classList.add('copied');
        setTimeout(()=>el.classList.remove('copied'),900);
    }else{
        alert('Copy is unavailable in this browser. Please select the draft text and copy it manually.');
    }
}
</script>
<script>document.addEventListener('DOMContentLoaded',function(){const street=document.getElementById('street'),block=document.getElementById('block');if(!street||!block)return;const blocks={"Adrian Street": [], "Banning Street": ["39", "40"], "Bronx Street": ["34", "40", "41", "46"], "Burney Street": ["48", "50", "53"], "Badger Street": ["44", "50"], "Boles Street": ["45", "53"], "Bryant Street": ["49", "50", "51"], "Butler Street": ["33", "34"], "Bremen Street": ["34", "39", "40"], "Bronson Street": ["45", "46", "47", "48", "49", "51", "53"], "Burke Street": ["48", "49"], "Baker Street": ["38"], "Byron Street": ["45", "48"], "Bonner Street": ["41", "44", "50", "53"]};const selected="<?= e($editing['block'] ?? ($formInput['block'] ?? '')) ?>";function sync(){const list=blocks[street.value]||[];block.innerHTML='<option value="">'+(list.length?'Select block':'No block for this street')+'</option>';list.forEach(v=>{const o=document.createElement('option');o.value=v;o.textContent=v;if(v===selected)o.selected=true;block.appendChild(o);});block.disabled=!list.length;block.required=!!list.length;if(!list.length)block.value='';}street.addEventListener('change',function(){const previous=block.value;sync();if(previous)block.value=previous;});sync();});</script>
<script>
document.addEventListener('DOMContentLoaded', function(){
    const cards = Array.from(document.querySelectorAll('.homeowner-profile-card'));
    if (!cards.length) return;

    const overlay = document.createElement('div');
    overlay.className = 'homeowner-profile-modal-overlay';
    overlay.hidden = true;
    overlay.innerHTML = `
        <div class="homeowner-profile-modal" role="dialog" aria-modal="true" aria-labelledby="homeowner-profile-modal-title">
            <div class="section-heading">
                <div><span class="section-kicker">Homeowner Profile</span><h2 id="homeowner-profile-modal-title">Homeowner Details</h2><p>Complete homeowner information, collection history, reservation history, and available actions.</p></div>
                <button type="button" class="btn btn-secondary btn-small" data-close-homeowner-modal>Close</button>
            </div>
            <div class="homeowner-profile-modal-body"></div>
        </div>`;
    document.body.appendChild(overlay);
    const body = overlay.querySelector('.homeowner-profile-modal-body');

    function openCard(card){
        const expanded = card.querySelector(':scope > .homeowner-profile-expanded');
        if (!expanded) return;
        body.innerHTML = '';
        const content = expanded.cloneNode(true);
        content.classList.add('homeowner-modal-content');
        body.appendChild(content);
        overlay.hidden = false;
        document.body.classList.add('modal-open');
    }
    function closeModal(){
        overlay.hidden = true;
        document.body.classList.remove('modal-open');
        body.innerHTML = '';
    }

    cards.forEach(card => {
        const summary = card.querySelector(':scope > summary');
        if (summary) {
            summary.addEventListener('click', function(e){
                e.preventDefault();
                e.stopImmediatePropagation();
                openCard(card);
            }, true);
            summary.addEventListener('keydown', function(e){
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    e.stopImmediatePropagation();
                    openCard(card);
                }
            }, true);
        }
    });

    overlay.addEventListener('click', function(e){
        if (e.target === overlay || e.target.closest('[data-close-homeowner-modal]')) closeModal();
    });
    document.addEventListener('keydown', function(e){
        if (e.key === 'Escape' && !overlay.hidden) closeModal();
    });
});
</script>
<script>
document.addEventListener('DOMContentLoaded', function(){
  const section=document.getElementById('homeowner-form-section');
  const form=section ? section.querySelector('form') : null;
  if(!form) return;
  form.addEventListener('invalid', function(e){
    if(section) section.open=true;
    setTimeout(function(){ try { e.target.focus({preventScroll:false}); e.target.scrollIntoView({behavior:'smooth',block:'center'}); } catch(_){} }, 0);
  }, true);
  const street=form.querySelector('#street'), block=form.querySelector('#block');
  if(street && block){
    form.addEventListener('submit', function(){
      if(street.value === 'Adrian Street') block.value='';
    });
  }
});
</script>
<?php require __DIR__ . '/../includes/footer.php'; ?>
