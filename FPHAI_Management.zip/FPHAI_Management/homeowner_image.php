<?php
declare(strict_types=1);
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_login();
$id=(int)($_GET['id']??0);
$stmt=$pdo->prepare('SELECT h.profile_image_path,h.user_id FROM homeowners h WHERE h.homeowner_id=:id LIMIT 1');
$stmt->execute(['id'=>$id]); $row=$stmt->fetch();
if(!$row || empty($row['profile_image_path'])){http_response_code(404);exit('Image not found.');}
if(current_role()==='Resident' && (int)$row['user_id']!==current_user_id()){http_response_code(403);exit('403 Forbidden');}
$path=UPLOAD_DIR.basename((string)$row['profile_image_path']);
// Stored path is homeowners/<random-name>; keep traversal impossible by resolving below the upload root.
$path=UPLOAD_DIR.str_replace(['..','\\'],['','/'],(string)$row['profile_image_path']);
if(!is_file($path)){http_response_code(404);exit('Image not found.');}
$finfo=new finfo(FILEINFO_MIME_TYPE); $mime=$finfo->file($path)?:'application/octet-stream';
if(!in_array($mime,['image/jpeg','image/png','image/webp'],true)){http_response_code(415);exit('Unsupported image.');}
header('Content-Type: '.$mime);header('Content-Length: '.filesize($path));header('Cache-Control: private, max-age=300');header('X-Content-Type-Options: nosniff');
readfile($path);exit;
