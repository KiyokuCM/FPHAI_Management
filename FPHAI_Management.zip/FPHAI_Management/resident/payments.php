<?php
require_once __DIR__ . '/../config/database.php'; require_once __DIR__ . '/../includes/auth.php'; require_once __DIR__ . '/../includes/functions.php';
require_role('Resident'); $pageTitle='My Payments';
$stmt=$pdo->prepare('SELECT homeowner_id,household_name FROM homeowners WHERE user_id=:uid LIMIT 1');$stmt->execute(['uid'=>current_user_id()]);$home=$stmt->fetch();
$payments=[]; $total=0;
if($home){
 $stmt=$pdo->prepare('SELECT p.payment_date,p.or_number,p.amount,p.payment_method,p.reference_number,p.description,p.proof_image_path,p.status,"Regular Payment" AS source_label,p.payment_id AS source_id FROM payments p WHERE p.homeowner_id=:hid
 UNION ALL
 SELECT rp.payment_date,rp.or_number,rp.amount,rp.payment_method,rp.reference_number,CONCAT("Facility Reservation #",rp.reservation_id," — Reservation Payment") AS description,NULL AS proof_image_path,rp.status,"Reservation Payment" AS source_label,rp.reservation_payment_id AS source_id FROM reservation_payments rp WHERE rp.homeowner_id=:hid2
 ORDER BY payment_date DESC');
 $stmt->execute(['hid'=>$home['homeowner_id'],'hid2'=>$home['homeowner_id']]); $payments=$stmt->fetchAll();
 foreach($payments as $p){if($p['status']==='Validated')$total+=(float)$p['amount'];}
}
$availableYears=[]; foreach($payments as $p){$y=(int)date('Y',strtotime($p['payment_date']));$availableYears[$y]=true;} $currentYear=(int)date('Y'); $availableYears[$currentYear]=true; $availableYears=array_keys($availableYears); rsort($availableYears); $selectedYear=(int)($_GET['year']??$currentYear); if(!in_array($selectedYear,$availableYears,true))$selectedYear=$currentYear; $displayPayments=array_values(array_filter($payments,fn($p)=>(int)date('Y',strtotime($p['payment_date']))===$selectedYear));

require __DIR__.'/../includes/header.php';$flash=get_flash();
?>
<?php if($flash):?><div class="alert alert-<?=e($flash['type'])?>"><?=e($flash['message'])?></div><?php endif;?>
<section class="section-card"><div class="section-heading"><div><span class="section-kicker">Private Records</span><h2>My Payment Records</h2><p>Only your own transactions are shown here. Collections and reservation payments are separated for easier tracking.</p></div></div>
<div class="record-search-bar"><div class="form-group"><label for="resident-payment-year">Year</label><select id="resident-payment-year" onchange="window.location.href='payments.php?year='+this.value"><option value="all">Present year</option><?php foreach($availableYears as $yr): ?><option value="<?=e((string)$yr)?>" <?=($selectedYear===$yr)?'selected':''?>><?=e((string)$yr)?></option><?php endforeach; ?></select></div><div class="form-group"><label for="resident-payment-search">Search My Payments</label><input id="resident-payment-search" type="search" placeholder="Search date, SI number, method, reference, description, amount, or status…" autocomplete="off"></div><span class="form-note">Click any transaction row to view its full details.</span></div>
<?php foreach([['Regular Payment','Collections Payments'],['Reservation Payment','Reservation Payments']] as $section): $sectionRows=array_values(array_filter($displayPayments,fn($p)=>$p['source_label']===$section[0])); ?>
<div class="payment-history-section"><div class="section-heading compact"><div><h3><?=e($section[1])?></h3><p><?=e($section[0]==='Regular Payment'?'Regular HOA collections and dues.':'Facility reservation payments.')?></p></div></div><div class="data-table-wrap"><table class="data-table resident-payment-subtable"><thead><tr><th>Date</th><th>SI Number</th><th>Amount</th><th>Method</th><th>Reference</th><th>Description</th><th>Proof</th><th>Status</th></tr></thead><tbody>
<?php foreach($sectionRows as $p): $detail=['Date'=>$p['payment_date'],'Record Type'=>$p['source_label'],'SI Number'=>$p['or_number'],'Amount'=>'₱'.number_format((float)$p['amount'],2),'Payment Method'=>$p['payment_method'],'Reference'=>$p['reference_number']?:'—','Description'=>$p['description']?:'—','Status'=>$p['status']]; ?><tr class="clickable-record-row" data-payment-search="<?=e(strtolower(implode(' ',array_map('strval',$detail))))?>" data-payment-detail="<?=e(json_encode($detail,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES))?>"><td><?=e($p['payment_date'])?></td><td><?=e($p['or_number'])?></td><td>₱<?=number_format((float)$p['amount'],2)?></td><td><?=e($p['payment_method'])?></td><td><?=e($p['reference_number']?:'—')?></td><td class="table-description"><?=e($p['description']?:'—')?></td><td><?=!empty($p['proof_image_path'])?'<a class="btn btn-secondary btn-small payment-proof-link" target="_blank" href="../payment_proof_download.php?id='.(int)$p['source_id'].'">View proof</a>':'<span class="form-note">—</span>'?></td><td><span class="status-pill <?=e(status_class($p['status']))?>"><?=e($p['status'])?></span></td></tr><?php endforeach; ?><?php if(!$sectionRows):?><tr><td colspan="8" class="empty-state">No <?=e(strtolower($section[1]))?> have been recorded.</td></tr><?php endif;?></tbody></table></div></div>
<?php endforeach; ?></section><div id="resident-payment-detail-modal" class="record-detail-overlay" hidden><div class="record-detail-modal" role="dialog" aria-modal="true" aria-labelledby="resident-payment-detail-title"><div class="section-heading"><div><span class="section-kicker">Private Transaction</span><h2 id="resident-payment-detail-title">Payment Details</h2></div><button type="button" class="btn btn-secondary btn-small" id="close-resident-payment-detail">Close</button></div><div id="resident-payment-detail-grid" class="record-detail-grid"></div></div></div>
<?php require __DIR__.'/../includes/footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded',function(){
 const input=document.getElementById('resident-payment-search'), tables=Array.from(document.querySelectorAll('.resident-payment-subtable')), modal=document.getElementById('resident-payment-detail-modal'), grid=document.getElementById('resident-payment-detail-grid'), close=document.getElementById('close-resident-payment-detail');
 if(!tables.length)return;
 const rows=tables.flatMap(t=>Array.from(t.querySelectorAll('tbody tr.clickable-record-row')));
 if(input) input.addEventListener('input',function(){const q=this.value.trim().toLowerCase();rows.forEach(r=>{r.style.display=!q||(r.dataset.paymentSearch||'').includes(q)?'':'none';});});
 rows.forEach(row=>row.addEventListener('click',function(e){if(e.target.closest('a,button,input,select'))return;try{const data=JSON.parse(this.dataset.paymentDetail||'{}');grid.innerHTML=Object.entries(data).map(([k,v])=>`<div><span>${k}</span><strong>${String(v).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}</strong></div>`).join('');modal.hidden=false;document.body.classList.add('modal-open');}catch(err){}}));
 const closeModal=()=>{modal.hidden=true;document.body.classList.remove('modal-open');}; if(close)close.addEventListener('click',closeModal); if(modal)modal.addEventListener('click',e=>{if(e.target===modal)closeModal();}); document.addEventListener('keydown',e=>{if(e.key==='Escape'&&modal&&!modal.hidden)closeModal();});
});
</script>
