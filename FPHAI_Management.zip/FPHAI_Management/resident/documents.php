<?php
require_once __DIR__ . '/../config/database.php'; require_once __DIR__ . '/../includes/auth.php'; require_once __DIR__ . '/../includes/functions.php';
require_role('Resident'); $pageTitle = 'Documents';
$documents=$pdo->query('SELECT d.*,u.username FROM documents d JOIN users u ON u.user_id=d.uploaded_by WHERE d.visibility IN ("Resident","All") ORDER BY d.created_at DESC')->fetchAll();
require __DIR__ . '/../includes/header.php';
?>
<section class="section-card"><div class="section-heading"><div><span class="section-kicker">HOA Resources</span><h2>Documents</h2><p>Templates, notices, forms, and other documents uploaded by the HOA office for Resident access.</p></div></div>
<div class="data-table-wrap"><table class="data-table"><thead><tr><th>Title</th><th>Category</th><th>Description</th><th>File</th><th>Uploaded</th></tr></thead><tbody>
<?php foreach($documents as $d):?><tr><td><strong><?=e($d['title'])?></strong></td><td><?=e($d['category'])?></td><td><?=e($d['description']?:'—')?></td><td><a class="btn btn-secondary btn-small" href="../document_download.php?id=<?=(int)$d['document_id']?>" target="_blank">View / Download</a></td><td><?=e(date('M j, Y',strtotime($d['created_at'])))?></td></tr><?php endforeach;?>
<?php if(!$documents):?><tr><td colspan="5" class="empty-state">No Resident documents are available yet.</td></tr><?php endif;?></tbody></table></div></section>
<?php require __DIR__.'/../includes/footer.php'; ?>
