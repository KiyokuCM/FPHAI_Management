<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('Resident');
$pageTitle='My Profile'; $error='';
$stmt=$pdo->prepare('SELECT h.*,u.username,u.email AS user_email,u.mobile_number,u.two_factor_enabled FROM homeowners h LEFT JOIN users u ON u.user_id=h.user_id WHERE h.user_id=:uid LIMIT 1');
$stmt->execute(['uid'=>current_user_id()]); $profile=$stmt->fetch();
if(!$profile){require __DIR__.'/../includes/header.php';echo '<div class="alert alert-warning">Your account is not linked to a homeowner profile. Please contact the HOA office.</div>';require __DIR__.'/../includes/footer.php';exit;}
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!verify_csrf($_POST['csrf_token']??'')){$error='Invalid request token. Please try again.';}else{try{
  $household=trim($_POST['household_name']??'');$address=trim($_POST['address']??'');$block=trim($_POST['block']??'');$lot=trim($_POST['lot']??'');$contact=trim($_POST['contact_number']??'');$email=trim($_POST['email']??'');$vehicles=max(0,(int)($_POST['no_of_vehicles']??0));$households=max(1,(int)($_POST['no_of_households']??1));$twoFactor=isset($_POST['two_factor_enabled'])?1:0;
  if($household===''||$address==='')throw new RuntimeException('Household name and address are required.');
  if($email!==''&&!filter_var($email,FILTER_VALIDATE_EMAIL))throw new RuntimeException('Please enter a valid email address.');
  $pdo->beginTransaction();
  $stmt=$pdo->prepare('UPDATE homeowners SET household_name=:household,address=:address,block=:block,lot=:lot,contact_number=:contact,email=:email,no_of_vehicles=:vehicles,no_of_households=:households WHERE homeowner_id=:id AND user_id=:uid');
  $stmt->execute(['household'=>$household,'address'=>$address,'block'=>$block?:null,'lot'=>$lot?:null,'contact'=>$contact?:null,'email'=>$email?:null,'vehicles'=>$vehicles,'households'=>$households,'id'=>$profile['homeowner_id'],'uid'=>current_user_id()]);
  $stmt=$pdo->prepare('UPDATE users SET email=:email,mobile_number=:mobile,two_factor_enabled=:two_factor WHERE user_id=:uid');$stmt->execute(['email'=>$email?:null,'mobile'=>$contact?:null,'two_factor'=>$twoFactor,'uid'=>current_user_id()]);
  create_notification($pdo,current_user_id(),'Profile updated','Your Resident profile was updated successfully.','Success','My Profile',(int)$profile['homeowner_id']);
  notify_staff($pdo,'Resident profile updated',$household.' updated their profile details. Please review the changes.','Info','Homeowners',(int)$profile['homeowner_id']);
  audit_log($pdo,current_user_id(),'Updated','My Profile',(int)$profile['homeowner_id'],'Resident updated their permitted profile details.');
  $pdo->commit(); flash('success','Your profile was updated. The HOA office has been notified.'); header('Location: profile.php'); exit;
 }catch(RuntimeException $ex){if($pdo->inTransaction())$pdo->rollBack();$error=$ex->getMessage();}catch(PDOException $ex){if($pdo->inTransaction())$pdo->rollBack();$error='Your profile could not be updated. Please try again.';}}
}
$flash=get_flash(); require __DIR__.'/../includes/header.php';
?>
<?php if($flash):?><div class="alert alert-<?=e($flash['type'])?>"><?=e($flash['message'])?></div><?php endif;?><?php if($error):?><div class="alert alert-error"><?=e($error)?></div><?php endif;?>
<section class="section-card"><div class="section-heading"><div><span class="section-kicker">Resident Account</span><h2>My Profile</h2><p>These details are shared with the linked homeowner record. Changes are visible to the HOA office.</p></div></div>
<form method="POST" class="form-grid"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>">
<div class="form-group"><label>Username</label><input value="<?=e($profile['username'])?>" readonly></div>
<div class="form-group"><label>Membership Status</label><input value="<?=e($profile['membership_status'])?>" readonly></div>
<div class="form-group"><label for="household_name">Household Name</label><input id="household_name" name="household_name" value="<?=e($profile['household_name'])?>" required></div>
<div class="form-group"><label for="address">Address</label><input id="address" name="address" value="<?=e($profile['address'])?>" required></div>
<div class="form-group"><label for="block">Block</label><input id="block" name="block" value="<?=e($profile['block']??'')?>"></div>
<div class="form-group"><label for="lot">Lot</label><input id="lot" name="lot" value="<?=e($profile['lot']??'')?>"></div>
<div class="form-group"><label for="contact_number">Mobile / Contact Number</label><input id="contact_number" name="contact_number" maxlength="50" value="<?=e($profile['contact_number']??$profile['mobile_number']??'')?>"></div>
<div class="form-group"><label for="email">Email Address</label><input id="email" name="email" type="email" value="<?=e($profile['email']??$profile['user_email']??'')?>"></div>
<div class="form-group"><label for="no_of_households">Number of Households</label><input id="no_of_households" name="no_of_households" type="number" min="1" value="<?=e((string)$profile['no_of_households'])?>"></div>
<div class="form-group"><label for="no_of_vehicles">Number of Vehicles</label><input id="no_of_vehicles" name="no_of_vehicles" type="number" min="0" value="<?=e((string)$profile['no_of_vehicles'])?>"></div>
<div class="form-group compact-checkbox-group"><label class="checkbox-label"><input type="checkbox" name="two_factor_enabled" value="1" <?=!empty($profile['two_factor_enabled'])?'checked':''?>> Enable two-factor authentication</label><p class="form-note">Optional. It works when your email or mobile number is available and configured by the system.</p></div>
<div class="full"><button class="btn btn-primary" type="submit">Save Profile Changes</button><a class="btn btn-secondary" href="../change-password.php">Change Password</a></div>
</form></section>
<section class="section-card" style="margin-top:22px"><div class="section-heading"><div><h2>Two-Factor Authentication</h2><p>Optional when a verified email address or mobile number is available.</p></div><span class="status-pill <?=!empty($profile['two_factor_enabled'])?'status-success':'status-neutral'?>"><?=!empty($profile['two_factor_enabled'])?'Enabled':'Off'?></span></div><p class="form-note">Your current contact details are used for verification when 2FA is enabled. If no contact method is available, password login continues without the second factor.</p></section>
<?php require __DIR__.'/../includes/footer.php'; ?>
