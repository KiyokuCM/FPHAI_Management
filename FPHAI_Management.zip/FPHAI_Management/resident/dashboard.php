<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('Resident');
$pageTitle = 'Resident Dashboard';

$stmt=$pdo->prepare('SELECT homeowner_id, household_name, address, membership_status, created_at FROM homeowners WHERE user_id=:user_id LIMIT 1');
$stmt->execute(['user_id'=>current_user_id()]); $homeowner=$stmt->fetch();
$paymentTotal=0.0; $paymentCount=0; $reservationTotal=0.0; $reservationCount=0; $memberSince=null; $nextDue=(new DateTimeImmutable('first day of next month'))->format('F j, Y'); $dueCreditMonths=0; $notifications=[]; $unread=0;
if ($homeowner) {
    $start=date('Y-m-01'); $next=date('Y-m-d',strtotime('+1 month',strtotime($start)));
    $stmt=$pdo->prepare('SELECT COALESCE(SUM(amount),0), COUNT(*) FROM payments WHERE homeowner_id=:homeowner_id AND status="Validated" AND payment_date>=:start AND payment_date<:next');
    $stmt->execute(['homeowner_id'=>$homeowner['homeowner_id'],'start'=>$start,'next'=>$next]); [$paymentTotal,$paymentCount]=$stmt->fetch(PDO::FETCH_NUM);
    $stmt=$pdo->prepare('SELECT COALESCE(SUM(amount),0), COUNT(*) FROM reservation_payments WHERE homeowner_id=:homeowner_id AND status="Validated" AND payment_date>=:start AND payment_date<:next');
    $stmt->execute(['homeowner_id'=>$homeowner['homeowner_id'],'start'=>$start,'next'=>$next]); [$reservationTotal,$reservationCount]=$stmt->fetch(PDO::FETCH_NUM);
    $stmt=$pdo->prepare('SELECT MIN(payment_date) FROM (SELECT payment_date FROM payments WHERE homeowner_id=:homeowner_id UNION ALL SELECT payment_date FROM reservation_payments WHERE homeowner_id=:homeowner_id2) x'); $stmt->execute(['homeowner_id'=>$homeowner['homeowner_id'],'homeowner_id2'=>$homeowner['homeowner_id']]); $memberSince=$stmt->fetchColumn();
    if (!$memberSince) $memberSince=$homeowner['created_at'];
    $dueInfo = calculate_homeowner_due_date($pdo, (int)$homeowner['homeowner_id']);
    $nextDue = date('F j, Y', strtotime($dueInfo['due_date']));
    $dueCreditMonths = (int)$dueInfo['credited_months'];
}
$stmt=$pdo->prepare('SELECT notification_id,title,message,type,created_at,is_read FROM notifications WHERE user_id=:uid ORDER BY created_at DESC, notification_id DESC LIMIT 8');
$stmt->execute(['uid'=>current_user_id()]); $notifications=$stmt->fetchAll();
$unread=unread_notification_count($pdo,current_user_id());
$durationText='—';
if($memberSince){$since=new DateTimeImmutable(substr((string)$memberSince,0,10));$now=new DateTimeImmutable('today');$diff=$since->diff($now);$parts=[];if($diff->y)$parts[]=$diff->y.' yr'.($diff->y===1?'':'s');if($diff->m)$parts[]=$diff->m.' mo'.($diff->m===1?'':'s');if(!$parts)$parts[]=$diff->d.' day'.($diff->d===1?'':'s');$durationText=implode(' · ',$parts);}
require __DIR__ . '/../includes/header.php';
?>
<section class="welcome-card"><div><span class="eyebrow">Resident Portal</span><h2>Welcome, <?= e($homeowner['household_name'] ?? current_username()) ?></h2><p>View your payment records, reservations, documents, profile, and HOA updates.</p></div></section>
<?php if (!$homeowner): ?><div class="alert alert-warning">Your user account is not yet linked to a homeowner record. Please contact the HOA office.</div><?php endif; ?>
<section class="stats-grid resident-stats-grid">
    <article class="stat-card"><span class="stat-label">Total Reservation This Month</span><strong class="resident-sensitive-amount" data-amount="₱<?= number_format((float)$reservationTotal,2) ?>">₱<?= number_format((float)$reservationTotal,2) ?></strong><button type="button" class="amount-eye" data-amount-target="reservation" aria-label="Hide reservation total" aria-pressed="false">👁</button><small><?= number_format((int)$reservationCount) ?> paid reservation<?= $reservationCount===1?'':'s' ?></small></article>
    <article class="stat-card"><span class="stat-label">Payment Total This Month</span><strong class="resident-sensitive-amount" data-amount="₱<?= number_format((float)$paymentTotal,2) ?>">₱<?= number_format((float)$paymentTotal,2) ?></strong><button type="button" class="amount-eye" data-amount-target="collection" aria-label="Hide collection total" aria-pressed="false">👁</button><small>Regular HOA collections only</small></article>
    <article class="stat-card"><span class="stat-label">Next Monthly Due</span><strong><?= e($nextDue) ?></strong><small>Current minimum: ₱<?= number_format(RESIDENT_MONTHLY_DUE,2) ?><?= $dueCreditMonths ? ' · '.$dueCreditMonths.' month'.($dueCreditMonths===1?'':'s').' credited' : '' ?></small></article>
    <article class="stat-card resident-membership-stat"><span class="stat-label">Membership</span><strong class="<?= ($homeowner['membership_status'] ?? '') === 'Delinquent' ? 'membership-delinquent' : '' ?>"><?= e($homeowner['membership_status'] ?? 'Not linked') ?></strong><small><?= $memberSince ? 'Member since '.e(date('F Y',strtotime((string)$memberSince))).' · '.e($durationText) : 'Membership duration unavailable' ?></small></article>
</section>
<section class="section-card resident-updates-card">
    <div class="section-heading"><div><span class="section-kicker">Notifications</span><h2>Recent Updates</h2></div><a class="btn btn-secondary btn-small" href="../notifications.php">View All<?= $unread ? ' ('.$unread.')' : '' ?></a></div>
    <?php if($notifications): ?><div class="resident-notification-scroll"><ul class="notification-list compact"><?php foreach($notifications as $n): ?><li class="notification-item <?= !$n['is_read']?'is-unread':'' ?>"><div><strong><?= e($n['title']) ?></strong><p><?= e($n['message']) ?></p><small><?= e(date('M j, Y g:i A',strtotime($n['created_at']))) ?></small></div></li><?php endforeach; ?></ul></div><?php else: ?><div class="request-empty">No notifications yet.</div><?php endif; ?>
</section>
<section class="dashboard-action-grid">
    <article class="request-panel"><div class="request-panel-header"><div><h2>Reservation Status</h2><span>Approved reservations are waiting for payment before use.</span></div></div><div class="request-empty">Check <a href="reservations.php">Reservations</a> for your current requests, approved schedules, and history.</div></article>
    <article class="request-panel"><div class="request-panel-header"><div><h2>Quick Access</h2><span>Common resident tasks.</span></div></div><ul class="request-list"><li class="request-item"><div class="request-main"><strong>My Payments</strong><span>Private transaction history and proof images.</span></div><a class="btn btn-secondary btn-small" href="payments.php">Open</a></li><li class="request-item"><div class="request-main"><strong>Documents</strong><span>View HOA templates and uploaded files.</span></div><a class="btn btn-secondary btn-small" href="documents.php">Open</a></li><li class="request-item"><div class="request-main"><strong>My Profile</strong><span>Edit your contact and registered details.</span></div><a class="btn btn-secondary btn-small" href="profile.php">Open</a></li></ul></article>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded',function(){document.querySelectorAll('.amount-eye').forEach(function(btn){const card=btn.closest('.stat-card');const amount=card&&card.querySelector('.resident-sensitive-amount');if(!amount)return;let key='fphai_hide_'+btn.dataset.amountTarget;let hidden=localStorage.getItem(key)==='1';function render(){amount.textContent=hidden?'₱••••••':amount.dataset.amount;btn.textContent='👁';btn.classList.toggle('is-hidden',hidden);btn.setAttribute('aria-pressed',hidden?'true':'false');btn.setAttribute('aria-label',hidden?'Show '+btn.dataset.amountTarget+' total':'Hide '+btn.dataset.amountTarget+' total');}btn.addEventListener('click',function(){hidden=!hidden;localStorage.setItem(key,hidden?'1':'0');render();});render();});});
</script>
