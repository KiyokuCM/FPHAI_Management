<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('Clerk');

$pageTitle = 'Documents';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request token. Please try again.';
    } else {
        try {
            $title = trim($_POST['title'] ?? '');
            $category = trim($_POST['category'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $visibility = $_POST['visibility'] ?? 'All';

            if ($title === '' || $category === '' || !in_array($visibility, ['Administrator','Clerk','Resident','All'], true)) {
                throw new RuntimeException('Title, category, and visibility are required.');
            }

            $uploaded = save_uploaded_document($_FILES['document'] ?? []);
            $stmt = $pdo->prepare(
                'INSERT INTO documents
                 (title,category,description,file_name,file_path,uploaded_by,visibility)
                 VALUES (:title,:category,:description,:file_name,:file_path,:uploaded_by,:visibility)'
            );
            $stmt->execute([
                'title'=>$title,'category'=>$category,'description'=>$description ?: null,
                'file_name'=>$uploaded['original_name'],'file_path'=>$uploaded['stored_name'],
                'uploaded_by'=>current_user_id(),'visibility'=>$visibility
            ]);

            $id = (int)$pdo->lastInsertId();
            audit_log($pdo, current_user_id(), 'Uploaded', 'Documents', $id, 'Uploaded and categorized a document.');
            if (in_array($visibility, ['Resident','All'], true)) { notify_staff($pdo, 'Resident document uploaded', $title.' is now available to Resident accounts.', 'Info', 'Documents', $id); $residents=$pdo->query('SELECT user_id FROM users WHERE role="Resident" AND status="Active"')->fetchAll(PDO::FETCH_COLUMN); foreach($residents as $residentId) create_notification($pdo,(int)$residentId,'New HOA document available',$title.' is now available in your Documents module.','Info','Documents',$id); }
            flash('success', 'Document uploaded.');
            header('Location: documents.php');
            exit;
        } catch (RuntimeException $ex) {
            $error = $ex->getMessage();
        }
    }
}

$documents = $pdo->query(
    'SELECT d.*, u.username
     FROM documents d
     JOIN users u ON u.user_id=d.uploaded_by
     ORDER BY d.created_at DESC'
)->fetchAll();

require __DIR__ . '/../includes/header.php';
$flash = get_flash();
?>
<?php if ($flash): ?><div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>

<details class="section-card foldable-panel">
    <summary><span><strong>Upload HOA Document</strong><small>Open this section when you need to upload a document.</small></span><span class="fold-chevron">⌄</span></summary>
    <div class="foldable-content">
    <h2>Upload HOA Document</h2>
    <p class="form-note">Allowed: PDF, JPG, PNG, DOC, DOCX. Maximum size: 10 MB.</p>

    <form method="POST" enctype="multipart/form-data" class="form-grid" onsubmit="return confirmDocumentUpload(this);">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">

        <div class="form-group">
            <label for="title">Document Title</label>
            <input id="title" name="title" type="text" maxlength="200" required>
        </div>

        <div class="form-group">
            <label for="category">Category</label>
            <input id="category" name="category" type="text" maxlength="100" required>
        </div>

        <div class="form-group">
            <label for="visibility">Visibility</label>
            <select id="visibility" name="visibility" required>
                <?php foreach (['All','Administrator','Clerk','Resident'] as $v): ?>
                    <option value="<?= e($v) ?>"><?= e($v) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="document">File</label>
            <input id="document" name="document" type="file" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx" required>
        </div>

        <div class="form-group full">
            <label for="description">Description</label>
            <textarea id="description" name="description" rows="3"></textarea>
        </div>

        <div class="full"><button class="btn btn-primary" type="submit">Upload Document</button></div>
    </form>
    </div>
</details>

<section class="section-card" style="margin-top:22px;">
    <h2>Document Repository</h2>
    <div class="data-table-wrap">
        <table class="data-table">
            <thead><tr><th>Title</th><th>Category</th><th>Visibility</th><th>File</th><th>Uploaded By</th><th>Date</th></tr></thead>
            <tbody>
            <?php foreach ($documents as $d): ?>
                <tr>
                    <td><?= e($d['title']) ?><br><small><?= e($d['description'] ?? '') ?></small></td>
                    <td><?= e($d['category']) ?></td>
                    <td><?= e($d['visibility']) ?></td>
                    <td><a class="link-button" href="../document_download.php?id=<?= (int)$d['document_id'] ?>">View / Download</a></td>
                    <td><?= e($d['username']) ?></td>
                    <td><?= e($d['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$documents): ?><tr><td colspan="6" class="empty-state">No documents uploaded.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
</section>

<script>
function confirmDocumentUpload(form){
    const title=form.querySelector('[name="title"]')?.value.trim() || '';
    const category=form.querySelector('[name="category"]')?.value.trim() || '';
    const file=form.querySelector('[name="document"]')?.files?.[0];
    const name=file ? file.name : '(no file selected)';
    return window.confirm('Please confirm this document upload.\n\nTitle: '+title+'\nCategory: '+category+'\nFile: '+name+'\n\nContinue with the upload?');
}
</script>
<?php require __DIR__ . '/../includes/footer.php'; ?>
