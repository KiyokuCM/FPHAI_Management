<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('Clerk');

$pageTitle = 'Reservations';
$error = '';
mark_completed_reservations($pdo);

function reservation_conflict_clerk(PDO $pdo, string $facility, string $date, string $start, string $end, int $ignoreId = 0): bool
{
    $s = $pdo->prepare('SELECT COUNT(*) FROM reservations WHERE facility=:facility AND reservation_date=:date AND status IN ("Pending","Approved") AND start_time < :end_time AND end_time > :start_time AND reservation_id<>:ignore_id');
    $s->execute(['facility'=>$facility,'date'=>$date,'start_time'=>$start,'end_time'=>$end,'ignore_id'=>$ignoreId]);
    return (int)$s->fetchColumn() > 0;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request token. Please try again.';
    } else {
        try {
            $action = $_POST['action'] ?? '';
            $id = (int)($_POST['reservation_id'] ?? 0);

            if ($action === 'create') {
                $facility = $_POST['facility'] ?? '';
                $type = $_POST['requester_type'] ?? '';
                $residentHomeownerId = (int)($_POST['resident_homeowner_id'] ?? 0);
                $name = trim($_POST['requester_name'] ?? '');
                $aff = trim($_POST['requester_affiliation'] ?? '');
                $contact = trim($_POST['requester_contact'] ?? '');
                $email = trim($_POST['requester_email'] ?? '');
                $date = $_POST['reservation_date'] ?? '';
                $start = $_POST['start_time'] ?? '';
                $end = $_POST['end_time'] ?? '';

                if (!in_array($facility, ['Court 1','Court 2'], true) || !in_array($type, ['Resident','Outside User'], true) || $date === '' || $start === '' || $end === '') {
                    throw new RuntimeException('Please complete all required reservation information.');
                }
                $homeownerId = null;
                if ($type === 'Resident') {
                    if ($residentHomeownerId < 1) throw new RuntimeException('Search for and select an existing Resident homeowner.');
                    $residentStmt=$pdo->prepare('SELECT h.homeowner_id,h.household_name,h.contact_number,h.email,u.user_id FROM homeowners h INNER JOIN users u ON u.user_id=h.user_id WHERE h.homeowner_id=:hid AND u.role="Resident" AND u.status="Active" LIMIT 1');
                    $residentStmt->execute(['hid'=>$residentHomeownerId]); $resident=$residentStmt->fetch();
                    if(!$resident) throw new RuntimeException('The selected Resident account is not active or is not linked to a homeowner profile.');
                    $homeownerId=(int)$resident['homeowner_id'];
                    // Keep the selected homeowner relationship, but allow staff to edit the
                    // requester name/contact for the actual facility booking.
                    $name = $name !== '' ? $name : (string)$resident['household_name'];
                    $aff = $aff !== '' ? $aff : (string)$resident['household_name'];
                    $contact = $contact !== '' ? $contact : trim((string)$resident['contact_number']);
                    $email = $email !== '' ? $email : trim((string)$resident['email']);
                    if($name==='') throw new RuntimeException('Requester name is required.');
                    if($contact==='') throw new RuntimeException('Contact number is required.');
                } else {
                    if ($name === '' || $aff === '' || $contact === '') throw new RuntimeException('Outside User requires name, affiliation/organization, and contact number.');
                    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Enter a valid email address or leave it blank.');
                }
                $pricing = calculate_reservation_charge($type, $start, $end);
                if (reservation_conflict_clerk($pdo, $facility, $date, $start, $end)) {
                    throw new RuntimeException('The requested facility and time overlap a pending or approved reservation.');
                }

                $stmt = $pdo->prepare('INSERT INTO reservations(homeowner_id,facility,requester_name,requester_type,requester_affiliation,requester_contact,requester_email,reservation_date,start_time,end_time,payment_amount,status,requested_by) VALUES(:homeowner_id,:facility,:name,:type,:aff,:contact,:email,:date,:start,:end,:amount,"Pending",:requested_by)');
                $stmt->execute([
                    'homeowner_id'=>$homeownerId,'facility'=>$facility,'name'=>$name,'type'=>$type,'aff'=>$aff,'contact'=>$contact,
                    'email'=>$email ?: null,'date'=>$date,'start'=>$start,'end'=>$end,'amount'=>$pricing['total'],
                    'requested_by'=>current_user_id()
                ]);
                $newId = (int)$pdo->lastInsertId();
                audit_log($pdo, current_user_id(), 'Created', 'Reservations', $newId, 'Created reservation request with automated facility rate.');
                if ($type === 'Resident' && $homeownerId) { $hid=$homeownerId; notify_homeowner($pdo,$hid,'Reservation request recorded','Your reservation request for '.$facility.' on '.$date.' was recorded and is awaiting approval.','Info','Reservations',$newId); }
                notify_staff($pdo,'Reservation request recorded',$name.' requested '.$facility.' on '.$date.'.','Info','Reservations',$newId);
                flash('success', 'Reservation request recorded. The system calculated the payment amount automatically.');
            } elseif ($action === 'record_payment') {
                $stmt = $pdo->prepare('SELECT reservation_id,homeowner_id,requester_name,status,payment_amount FROM reservations WHERE reservation_id=:id LIMIT 1');
                $stmt->execute(['id'=>$id]); $reservation=$stmt->fetch();
                if(!$reservation) throw new RuntimeException('Reservation record not found.');
                if(!in_array($reservation['status'],['Pending','Approved','Completed'],true)) throw new RuntimeException('Payment can only be recorded for a pending, approved, or completed reservation.');
                $method=$_POST['payment_method']??''; if($method!=='Cash') throw new RuntimeException('Reservation payment must be confirmed as Cash only.'); $reference=null;
                
                $existing=latest_reservation_payment($pdo,$id);
                if($existing && $existing['status']==='Validated') throw new RuntimeException('A validated payment already exists for this reservation.');
                $paymentId=record_reservation_payment($pdo,$id,!empty($reservation['homeowner_id'])?(int)$reservation['homeowner_id']:null,(float)$reservation['payment_amount'],'Cash',null,current_user_id());
                audit_log($pdo,current_user_id(),'Recorded','Reservation Payments',$paymentId,'Recorded facility reservation payment for reservation #'.$id.'.');
                if(!empty($reservation['homeowner_id'])) notify_homeowner($pdo,(int)$reservation['homeowner_id'],'Reservation payment recorded','Your payment of ₱'.number_format((float)$reservation['payment_amount'],2).' for '.$reservation['requester_name'].' / reservation #'.$id.' has been recorded by the HOA office.','Success','Reservations',$id);
                flash('success','Reservation payment recorded and linked to the Resident account.');
            } elseif (in_array($action, ['cancel','complete'], true)) {
                $stmt = $pdo->prepare('SELECT homeowner_id,requester_name,facility,reservation_date,start_time,end_time,status,payment_amount,cancellation_reason FROM reservations WHERE reservation_id=:id');
                $stmt->execute(['id'=>$id]);
                $reservation = $stmt->fetch();
                $status = $reservation['status'] ?? '';
                if (!$reservation) throw new RuntimeException('Reservation record not found.');
                if ($action === 'cancel') {
                    if (!in_array($status, ['Pending','Approved'], true)) throw new RuntimeException('Only pending or approved reservations can be cancelled.');
                    $reason=trim((string)($_POST['cancellation_reason']??'')); if($reason==='') throw new RuntimeException('A cancellation reason is required.'); if(mb_strlen($reason)>500) throw new RuntimeException('Cancellation reason must be 500 characters or fewer.'); $pdo->prepare('UPDATE reservations SET status="Cancelled", cancellation_reason=:reason WHERE reservation_id=:id')->execute(['reason'=>$reason,'id'=>$id]);
                    audit_log($pdo, current_user_id(), 'Cancelled', 'Reservations', $id, 'Cancelled reservation.');
                    if (!empty($reservation['homeowner_id'])) notify_homeowner($pdo,(int)$reservation['homeowner_id'],'Reservation cancelled','Your reservation for '.$reservation['facility'].' on '.$reservation['reservation_date'].' was cancelled by the HOA office.','Warning','Reservations',$id);
                    flash('success', 'Reservation cancelled and retained in history.');
                } else {
                    if ($status !== 'Approved') throw new RuntimeException('Only approved reservations can be marked completed.');
                    $pdo->prepare('UPDATE reservations SET status="Completed" WHERE reservation_id=:id')->execute(['id'=>$id]);
                    audit_log($pdo, current_user_id(), 'Completed', 'Reservations', $id, 'Marked reservation as completed after facility usage.');
                    flash('success', 'Reservation marked completed and retained in history.');
                }
            } else {
                throw new RuntimeException('Invalid reservation action.');
            }
            header('Location: reservations.php');
            exit;
        } catch (RuntimeException $ex) {
            $error = $ex->getMessage();
        }
    }
}

$recordRequest = (($_GET['record'] ?? '') === '1');
$recordFacility = in_array(($_GET['facility'] ?? ''), ['Court 1','Court 2'], true) ? (string)$_GET['facility'] : '';
$recordDate = (string)($_GET['date'] ?? '');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $recordDate) || $recordDate < date('Y-m-d')) $recordDate = '';

$monthRaw = $_GET['month'] ?? date('Y-m');
$month = preg_match('/^\d{4}-\d{2}$/', $monthRaw) ? $monthRaw : date('Y-m');
$monthStart = $month . '-01';
$monthEnd = (new DateTimeImmutable($monthStart))->modify('+1 month')->format('Y-m-d');
$calendarStmt = $pdo->prepare('SELECT reservation_id,facility,reservation_date,start_time,end_time,requester_name,requester_type,requester_affiliation,requester_contact,requester_email,payment_amount,status,requested_by FROM reservations WHERE reservation_date>=:start AND reservation_date<:end AND status IN ("Pending","Approved","Completed") ORDER BY reservation_date,start_time');
$calendarStmt->execute(['start'=>$monthStart,'end'=>$monthEnd]);
$calendarData = [];
foreach ($calendarStmt->fetchAll() as $b) $calendarData[$b['facility']][$b['reservation_date']][] = $b;
$statusFilter=$_GET['status']??'All';$validStatuses=['All','Pending','Approved','Completed','Cancelled','Rejected'];if(!in_array($statusFilter,$validStatuses,true))$statusFilter='All';$reservationSql='SELECT r.* FROM reservations r';$reservationParams=[];if($statusFilter!=='All'){ $reservationSql.=' WHERE r.status=:status_filter';$reservationParams['status_filter']=$statusFilter;}$reservationSql.=' ORDER BY r.reservation_date DESC,r.start_time DESC,r.reservation_id DESC';$reservationStmt=$pdo->prepare($reservationSql);$reservationStmt->execute($reservationParams);$reservations=$reservationStmt->fetchAll();

function render_clerk_calendar(string $month, array $data, string $facility): void
{
    $first = new DateTimeImmutable($month . '-01');
    $days = (int)$first->format('t');
    $offset = (int)$first->format('N') - 1;
    $prev = $first->modify('-1 month')->format('Y-m');
    $next = $first->modify('+1 month')->format('Y-m');
    echo '<div class="calendar-card"><div class="calendar-heading"><div><strong>'.e($facility).'</strong><span>Click a date to view the schedule.</span></div><div class="calendar-nav"><a class="btn btn-secondary btn-small" href="?month='.e($prev).'">‹</a><strong>'.e($first->format('F Y')).'</strong><a class="btn btn-secondary btn-small" href="?month='.e($next).'">›</a></div></div><div class="calendar-weekdays"><span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span>Sun</span></div><div class="calendar-grid">';
    for ($i=0;$i<$offset;$i++) echo '<div class="calendar-day is-empty"></div>';
    for ($d=1;$d<=$days;$d++) {
        $date = $first->setDate((int)$first->format('Y'),(int)$first->format('m'),$d)->format('Y-m-d');
        $rows = $data[$facility][$date] ?? [];
        $active = array_filter($rows, fn($x)=>in_array($x['status'],['Pending','Approved'],true));
        $today=date('Y-m-d'); $past=$date<$today; $cls=$past?'is-closed':($active?'is-booked':'is-available'); $label=$past?'Closed':($active?'Booked':'Open');
        echo '<button type="button" class="calendar-day '.$cls.' calendar-interactive-day" data-calendar-facility="'.e($facility).'" data-calendar-date="'.e($date).'" aria-label="'.e($facility.' '.$date.' '.$label).'"> <strong>'.$d.'</strong><span>'.$label.'</span></button>';
    }
    echo '</div><div class="calendar-legend"><span><i class="legend-dot available"></i> Open</span><span><i class="legend-dot booked"></i> Booked</span><span><i class="legend-dot closed"></i> Closed</span></div></div>';
}

$residentStmt = $pdo->query('SELECT h.homeowner_id,h.household_name,h.address,h.contact_number,h.email,u.username FROM homeowners h INNER JOIN users u ON u.user_id=h.user_id WHERE u.role="Resident" AND u.status="Active" AND h.membership_status<>"Inactive" ORDER BY h.household_name');
$residentOptions = $residentStmt->fetchAll();
$reservationPaymentRows=$pdo->query('SELECT * FROM reservation_payments ORDER BY reservation_payment_id DESC')->fetchAll();
$reservationPayments=[]; foreach($reservationPaymentRows as $rp){ if(!isset($reservationPayments[$rp['reservation_id']])) $reservationPayments[$rp['reservation_id']]=$rp; }

require __DIR__ . '/../includes/header.php';
$flash = get_flash();
?>
<?php if ($flash): ?><div class="alert alert-<?=e($flash['type'])?>"><?=e($flash['message'])?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-error"><?=e($error)?></div><?php endif; ?>

<section class="section-card">
    <div class="section-heading"><div><h2>Facility Availability Calendar</h2><p>Click a date to see the full schedule, current users, time slots, and payment. Completed reservations remain in history.</p></div></div>
    <div class="calendar-dual"><?php render_clerk_calendar($month,$calendarData,'Court 1'); render_clerk_calendar($month,$calendarData,'Court 2'); ?></div>
</section>

<details id="reservation-request" class="section-card foldable-panel" style="margin-top:22px;"<?= $recordRequest ? " open" : "" ?>>
    <summary><span><strong>Record Reservation Request</strong><small>Open this section only when you need to create a reservation.</small></span><span class="fold-chevron">⌄</span></summary>
    <div class="foldable-content">
        <div class="rate-schedule"><strong>Automatic rates:</strong> Resident — ₱150/hour day, ₱450/hour night. Outside User — ₱250/hour day, ₱600/hour night. Day is 6:00 AM–6:00 PM; night is 6:00 PM–10:00 PM. Mixed day/night reservations are allowed. The system charges Day (6:00 AM–6:00 PM) and Night (6:00 PM–10:00 PM) hours at their applicable rates.</div>
        <form method="POST" class="form-grid">
            <input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="create">
            <div class="form-group"><label for="facility">Facility</label><select id="facility" name="facility" required><option value="">Select facility</option><option value="Court 1" <?= $recordFacility==='Court 1' ? 'selected' : '' ?>>Court 1</option><option value="Court 2" <?= $recordFacility==='Court 2' ? 'selected' : '' ?>>Court 2</option></select></div>
            <div class="form-group"><label for="requester_type">Requester Type</label><select id="requester_type" name="requester_type" required><option value="">Select requester type</option><option value="Resident">Resident</option><option value="Outside User">Outside User</option></select></div>
            <div class="form-group resident-requester-field"><label for="resident_homeowner_search">Resident Name</label><input id="resident_homeowner_search" class="standard-input" name="resident_display_name" type="search" list="resident-homeowner-list" placeholder="Type household name to find a Resident…" autocomplete="off"><input type="hidden" id="resident_homeowner_id" name="resident_homeowner_id" value=""><datalist id="resident-homeowner-list"><?php foreach($residentOptions as $ro): ?><option value="<?=e($ro['household_name'])?>" data-homeowner-id="<?= (int)$ro['homeowner_id'] ?>"><?=e($ro['household_name'])?> — <?=e($ro['address']??'')?><?= !empty($ro['username']) ? ' — '.e($ro['username']) : '' ?></option><?php endforeach; ?></datalist><p class="form-note">Type the household name or select a suggestion. The system links the registered Resident to the reservation. Requester name and contact remain editable.</p></div>
            <div class="form-group"><label for="requester_name">Requester Name</label><input id="requester_name" class="standard-input" name="requester_name" maxlength="150" required></div>
            <div class="form-group"><label for="requester_affiliation">Affiliation / Organization / Household</label><input id="requester_affiliation" name="requester_affiliation" maxlength="200" required></div>
            <div class="form-group"><label for="requester_contact">Contact Number</label><input id="requester_contact" class="standard-input" name="requester_contact" maxlength="50" required></div>
            <div class="form-group"><label for="requester_email">Email Address</label><input id="requester_email" name="requester_email" type="email" maxlength="150"></div>
            <div class="form-group"><label for="reservation_date">Reservation Date</label><input id="reservation_date" name="reservation_date" type="date" min="<?=e(date('Y-m-d'))?>" value="<?=e($recordDate)?>" required></div>
            <div class="form-group"><label for="start_time">Start Time</label><input id="start_time" name="start_time" type="time" min="06:00" max="22:00" step="3600" required></div>
            <div class="form-group"><label for="end_time">End Time</label><input id="end_time" name="end_time" type="time" min="07:00" max="22:00" step="3600" required></div>
            <div class="full reservation-time-availability" id="reservation-time-availability"><div class="availability-heading"><strong>Time Availability</strong><span class="form-note">Select a facility and date to see available and occupied hours.</span></div><div id="reservation-time-slots" class="time-slot-grid"></div><div class="availability-legend"><span><i class="availability-dot available"></i> Available</span><span><i class="availability-dot occupied"></i> Occupied</span><span><i class="availability-dot closed"></i> Closed</span></div></div>
            <div class="form-group"><label for="payment_amount">Automated Payment Amount</label><input id="payment_amount" name="payment_amount" type="number" readonly step="0.01"><p id="rate-breakdown" class="form-note">Choose requester type and time to calculate the amount.</p></div>
            <div class="full"><button class="btn btn-primary" type="submit">Record Request</button></div>
        </form>
    </div>
</details>

<section class="section-card" style="margin-top:22px;"><div class="section-heading"><div><h2>Reservation Schedule and History</h2><p>Filter the list to quickly find pending requests and confirm cash payments from this table.</p></div></div><form method="GET" class="reservation-filter-bar"><input type="hidden" name="month" value="<?=e($month)?>"><div class="form-group"><label for="reservation-status-filter">Filter Status</label><select id="reservation-status-filter" name="status" onchange="this.form.submit()"><option value="All" <?=$statusFilter==='All'?'selected':''?>>All Statuses</option><?php foreach(array_slice($validStatuses,1) as $st): ?><option value="<?=e($st)?>" <?=$statusFilter===$st?'selected':''?>><?=e($st)?></option><?php endforeach; ?></select></div><a class="btn btn-secondary btn-small" href="reservations.php">Clear Filter</a></form><div class="data-table-wrap"><table class="data-table reservation-table"><thead><tr><th>Facility</th><th>Date</th><th>Time</th><th>Requester</th><th>Type</th><th>Reservation Fee</th><th>Payment</th><th>Status</th><th>Details</th></tr></thead><tbody><?php foreach($reservations as $r): $detail=['Facility'=>$r['facility'],'Date'=>$r['reservation_date'],'Time'=>date('g:i A',strtotime($r['start_time'])).'–'.date('g:i A',strtotime($r['end_time'])),'Requester'=>$r['requester_name'],'Requester Type'=>$r['requester_type'],'Affiliation / Household'=>$r['requester_affiliation']??'—','Contact'=>$r['requester_contact']??'—','Email'=>$r['requester_email']??'—','Reservation Fee'=>'₱'.number_format((float)$r['payment_amount'],2),'Automated Payment Amount'=>'₱'.number_format((float)$r['payment_amount'],2),'Status'=>$r['status'],'Cancellation Reason'=>$r['cancellation_reason'] ?: '—']; $rp=$reservationPayments[$r['reservation_id']]??null; $detail['Payment Record']=$rp?('Paid · '.$rp['or_number'].' · Cash'):(in_array($r['status'],['Approved','Completed'],true)?'Payment due / not recorded':'Not yet available'); if($rp && $r['status']==='Cancelled' && !empty($r['cancellation_reason']) && stripos($r['cancellation_reason'],'eligible for refund')!==false) $detail['Refund Eligibility']='Eligible for refund — contact the HOA office for refund processing.'; $actions=[]; if(in_array($r['status'],['Pending','Approved'],true)){$actions[]=['action'=>'cancel','label'=>'Cancel','class'=>'btn-secondary','confirm'=>'Cancel this reservation?','needsReason'=>true];} if(in_array($r['status'],['Pending','Approved','Completed'],true)&&!$rp){$actions[]=['action'=>'record_payment','label'=>'Confirm Cash Payment','class'=>'btn-primary','confirm'=>'Confirm that the cash reservation payment has been received?'];} $detailJson=e(json_encode($detail,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)); $actionsJson=e(json_encode($actions,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)); ?>
<tr class="clickable-reservation-row" tabindex="0" data-reservation-detail="<?=$detailJson?>" data-reservation-id="<?= (int)$r['reservation_id'] ?>" data-reservation-status="<?=e($r['status'])?>" data-reservation-actions="<?=$actionsJson?>"><td><?=e($r['facility'])?></td><td><?=e($r['reservation_date'])?></td><td><?=e(date('g:i A',strtotime($r['start_time'])))?>–<?=e(date('g:i A',strtotime($r['end_time'])))?></td><td><?=e($r['requester_name'])?></td><td><?=e($r['requester_type'])?></td><td>₱<?=number_format((float)$r['payment_amount'],2)?></td><td><?php if($rp):?><span class="status-pill status-success">Paid</span><?php elseif(in_array($r['status'],['Approved','Completed'],true)):?><span class="form-note">Payment due</span><?php else:?><span class="form-note">—</span><?php endif;?></td><td><span class="status-pill <?=e(status_class($r['status']))?>"><?=e($r['status'])?></span></td><td><button type="button" class="btn btn-secondary btn-small reservation-view-button">View Details</button></td></tr>
<?php endforeach;?><?php if(!$reservations):?><tr><td colspan="10" class="empty-state">No reservation records found for this filter.</td></tr><?php endif;?></tbody></table></div>
<div id="reservation-record-modal" class="reservation-record-overlay" hidden><div class="reservation-record-modal" role="dialog" aria-modal="true" aria-labelledby="reservation-record-title"><div class="section-heading"><div><span class="section-kicker">Reservation Record</span><h2 id="reservation-record-title">Full Reservation Details</h2><p>Review the complete request and use the available action below.</p></div><button type="button" class="btn btn-secondary btn-small" id="close-reservation-record">Close</button></div><div id="reservation-detail-grid" class="reservation-detail-grid"></div><div id="reservation-detail-actions" class="reservation-detail-actions"></div></div></div>
<script>
window.reservationCsrf=<?=json_encode(csrf_token())?>;
document.addEventListener('DOMContentLoaded',function(){const modal=document.getElementById('reservation-record-modal'),grid=document.getElementById('reservation-detail-grid'),actions=document.getElementById('reservation-detail-actions'),close=document.getElementById('close-reservation-record');if(!modal)return;const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));function formFor(action,id,label,cls,confirmText){const f=document.createElement('form');f.method='POST';f.innerHTML='<input type="hidden" name="csrf_token" value="'+esc(window.reservationCsrf)+'"><input type="hidden" name="action" value="'+esc(action)+'"><input type="hidden" name="reservation_id" value="'+id+'">'+(action==='record_payment'?'<input type="hidden" name="payment_method" value="Cash">':'')+(action==='cancel'?'<input type="hidden" name="cancellation_reason" value="">':'');const b=document.createElement('button');b.type='submit';b.className='btn '+cls;b.textContent=label;if(confirmText)b.onclick=(ev)=>{if(action==='cancel'){const reason=prompt('Please enter the reason for cancelling this reservation:');if(reason===null){ev.preventDefault();return false;}if(!reason.trim()){alert('A cancellation reason is required.');ev.preventDefault();return false;}f.querySelector('[name="cancellation_reason"]').value=reason.trim();}else if(!confirm(confirmText)){ev.preventDefault();return false;}};f.appendChild(b);return f;}function open(row){try{const d=JSON.parse(row.dataset.reservationDetail||'{}'),a=JSON.parse(row.dataset.reservationActions||'[]');grid.innerHTML=Object.entries(d).map(([k,v])=>'<div><span>'+esc(k)+'</span><strong>'+esc(v)+'</strong></div>').join('');actions.innerHTML='';if(a.length){a.forEach(x=>actions.appendChild(formFor(x.action,row.dataset.reservationId,x.label,x.class||'btn-secondary',x.confirm||'')));}else{actions.innerHTML='<span class="form-note">No action is currently available for this reservation.</span>';}modal.hidden=false;document.body.classList.add('modal-open');}catch(e){}}document.querySelectorAll('.clickable-reservation-row').forEach(row=>{row.addEventListener('click',e=>{if(e.target.closest('button,a,form')){if(e.target.closest('.reservation-view-button'))open(row);return;}open(row);});row.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();open(row);}});});function closeModal(){modal.hidden=true;document.body.classList.remove('modal-open');}close&&close.addEventListener('click',closeModal);modal.addEventListener('click',e=>{if(e.target===modal)closeModal();});document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!modal.hidden)closeModal();});});
</script></section>
<div id="reservation-calendar-modal" class="calendar-detail-overlay" hidden><div class="calendar-detail-modal" role="dialog" aria-modal="true" aria-labelledby="calendar-detail-title"><div class="calendar-detail-header"><div><span class="section-kicker">Facility Schedule</span><h2 id="calendar-detail-title">Bookings</h2><p id="calendar-detail-subtitle"></p></div><button type="button" class="btn btn-secondary btn-small" onclick="closeReservationCalendar()">Close</button></div><div id="calendar-detail-list" class="calendar-detail-list"></div></div></div>
<script>
window.reservationCalendarData=<?=json_encode($calendarData,JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT)?>; window.reservationCalendarPrivacy='staff'; window.reservationCurrentUserId=<?=current_user_id()?>; window.residentRequesterData=<?=json_encode(array_reduce($residentOptions,function($out,$r){$out[(string)$r['homeowner_id']]=['name'=>$r['household_name'],'contact'=>$r['contact_number']??'','email'=>$r['email']??''];return $out;},[]),JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT)?>;
(function(){const type=document.getElementById('requester_type'),field=document.querySelector('.resident-requester-field'),search=document.getElementById('resident_homeowner_search'),hidden=document.getElementById('resident_homeowner_id'),name=document.getElementById('requester_name'),aff=document.getElementById('requester_affiliation'),contact=document.getElementById('requester_contact'),email=document.getElementById('requester_email');if(!type||!field||!search||!hidden)return;const options=Array.from(document.querySelectorAll('#resident-homeowner-list option'));function clearResidentSelection(){search.value='';hidden.value='';}function setResidentVisibility(){field.style.display=type.value==='Resident'?'':'none';}function sync(){if(type.value!=='Resident'){hidden.value='';return;}const val=search.value.trim().toLowerCase();if(!val){hidden.value='';return;}const opt=options.find(o=>(o.value||'').toLowerCase()===val)||options.find(o=>(o.value||'').toLowerCase().includes(val));if(opt){hidden.value=opt.dataset.homeownerId||'';const d=window.residentRequesterData[hidden.value]||{};name.value=d.name||'';aff.value=d.name||'';contact.value=d.contact||'';email.value=d.email||'';}else{hidden.value='';}}type.addEventListener('change',()=>{if(type.value==='Outside User'||type.value===''){clearResidentSelection();name.value='';aff.value='';contact.value='';email.value='';}setResidentVisibility();if(type.value==='Resident'){search.focus();}sync();});search.addEventListener('input',sync);search.addEventListener('change',sync);setResidentVisibility();})();
(function(){const type=document.getElementById('requester_type'),start=document.getElementById('start_time'),end=document.getElementById('end_time'),amount=document.getElementById('payment_amount'),note=document.getElementById('rate-breakdown'),facility=document.getElementById('facility'),date=document.getElementById('reservation_date'),slots=document.getElementById('reservation-time-slots');if(!type||!start||!end)return;function calc(){if(!start.value||!end.value){amount.value='';note.textContent='Choose requester type and time to calculate the amount.';return;}const sm=parseInt(start.value.slice(0,2))*60+parseInt(start.value.slice(3,5)),em=parseInt(end.value.slice(0,2))*60+parseInt(end.value.slice(3,5));if(em<=sm||sm<360||em>1320||sm%60||em%60){amount.value='';note.textContent='Choose whole-hour slots between 6:00 AM and 10:00 PM.';return;}const resident=type.value==='Resident',dayRate=resident?150:250,nightRate=resident?450:600,dayMinutes=Math.max(0,Math.min(em,1080)-Math.max(sm,360)),nightMinutes=Math.max(0,em-Math.max(sm,1080)),dayHours=dayMinutes/60,nightHours=nightMinutes/60,total=dayHours*dayRate+nightHours*nightRate;amount.value=total.toFixed(2);const parts=[];if(dayHours)parts.push(dayHours+' hr Day × ₱'+dayRate+'/hour = ₱'+(dayHours*dayRate).toFixed(2));if(nightHours)parts.push(nightHours+' hr Night × ₱'+nightRate+'/hour = ₱'+(nightHours*nightRate).toFixed(2));note.textContent=parts.join(' + ')+' = ₱'+total.toFixed(2);}function updateSlots(){if(!slots||!facility||!date)return;const fac=facility.value,day=date.value;slots.innerHTML='';if(!fac||!day){slots.innerHTML='<span class="form-note">Select a facility and date first.</span>';return;}const rows=(window.reservationCalendarData[fac]&&window.reservationCalendarData[fac][day])||[];const now=new Date(),todayKey=now.toISOString().slice(0,10);const chosen=new Date(day+'T00:00:00');const past=chosen<new Date(todayKey+'T00:00:00');for(let h=6;h<22;h++){if(h===18){const sep=document.createElement('div');sep.className='time-period-separator';sep.innerHTML='<strong>Night Schedule</strong><span>6:00 PM–10:00 PM</span>';slots.appendChild(sep);}const slotStart=h*60,slotEnd=(h+1)*60;const occupied=rows.some(r=>['Pending','Approved'].includes(r.status)&&((parseInt(r.start_time.slice(0,2))*60+parseInt(r.start_time.slice(3,5)))<slotEnd)&&((parseInt(r.end_time.slice(0,2))*60+parseInt(r.end_time.slice(3,5)))>slotStart));const currentMinutes=now.getHours()*60+now.getMinutes();const closed=past||(day===todayKey&&slotEnd<=currentMinutes);const cls=closed?'is-closed':occupied?'is-occupied':'is-available';const label=closed?'Closed':occupied?'Occupied':'Available';const btn=document.createElement('button');btn.type='button';btn.className='time-slot '+cls;btn.textContent=(h%12||12)+':00 '+(h>=12?'PM':'AM')+'–'+((h+1)%12||12)+':00 '+(h+1>=12?'PM':'AM')+' · '+label;if(!closed&&!occupied)btn.addEventListener('click',()=>{if(!start.value){start.value=String(h).padStart(2,'0')+':00';end.value='';}else if(!end.value||parseInt(end.value.slice(0,2))*60<=h*60){end.value=String(h+1).padStart(2,'0')+':00';}else{start.value=String(h).padStart(2,'0')+':00';end.value='';}calc();});slots.appendChild(btn);}}[type,start,end].forEach(x=>x.addEventListener('input',calc));[facility,date].forEach(x=>x.addEventListener('change',updateSlots));updateSlots();calc();setInterval(updateSlots,60000);})();
</script>
<?php require __DIR__ . '/../includes/footer.php'; ?>
