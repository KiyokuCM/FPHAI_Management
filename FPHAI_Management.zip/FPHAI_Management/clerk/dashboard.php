<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

require_role('Clerk');

$pageTitle = 'Clerk Dashboard';
$homeowners = (int)$pdo->query('SELECT COUNT(*) FROM homeowners')->fetchColumn();
$pendingReservations = (int)$pdo->query('SELECT COUNT(*) FROM reservations WHERE status = "Pending"')->fetchColumn();
$paymentsToday = (int)$pdo->query('SELECT COUNT(*) FROM payments WHERE DATE(payment_date) = CURDATE()')->fetchColumn();
$pendingPayments = (int)$pdo->query('SELECT COUNT(*) FROM payments WHERE status = "Pending"')->fetchColumn();

$pendingCollectionRows = $pdo->query(
    'SELECT p.payment_id, p.or_number, p.payment_date, p.amount, p.payment_method, h.household_name
     FROM payments p INNER JOIN homeowners h ON h.homeowner_id=p.homeowner_id
     WHERE p.status="Pending" ORDER BY p.payment_date ASC, p.payment_id ASC LIMIT 5'
)->fetchAll();
$pendingReservationRows = $pdo->query(
    'SELECT reservation_id, requester_name, reservation_date, start_time, end_time, requester_type
     FROM reservations WHERE status="Pending"
     ORDER BY reservation_date ASC, start_time ASC, reservation_id ASC LIMIT 5'
)->fetchAll();

require __DIR__ . '/../includes/header.php';
?>
<section class="welcome-card dashboard-welcome">
    <div class="dashboard-welcome-copy">
        <span class="eyebrow">Welcome back</span>
        <h2>Hello, <?= e(current_username()) ?>.</h2>
        <p class="dashboard-role">Clerk</p>
        <p>Encode payments, update records, and process reservation requests.</p>
    </div>
</section>
<section class="stats-grid">
    <article class="stat-card"><span class="stat-label">Homeowners</span><strong><?= number_format($homeowners) ?></strong></article>
    <article class="stat-card"><span class="stat-label">Payments Today</span><strong><?= number_format($paymentsToday) ?></strong></article>
    <article class="stat-card"><span class="stat-label">Awaiting Collections</span><strong><?= number_format($pendingPayments) ?></strong></article>
    <article class="stat-card"><span class="stat-label">Awaiting Reservations</span><strong><?= number_format($pendingReservations) ?></strong></article>
</section>
<section class="dashboard-action-grid">
    <article class="request-panel">
        <div class="request-panel-header"><div><h2>Awaiting Collections</h2><span>Entries needing Administrator validation.</span></div><span class="status-pill status-pending"><?= number_format($pendingPayments) ?> pending</span></div>
        <?php if ($pendingCollectionRows): ?><ul class="request-list"><?php foreach ($pendingCollectionRows as $row): ?><li class="request-item"><div class="request-main"><strong><?= e($row['household_name']) ?></strong><span><?= e($row['or_number']) ?> · <?= e($row['payment_date']) ?> · <?= e($row['payment_method']) ?></span></div><strong>₱<?= number_format((float)$row['amount'],2) ?></strong></li><?php endforeach; ?></ul><?php else: ?><div class="request-empty">No pending collection entries.</div><?php endif; ?>
        <?php if ($pendingPayments > 5): ?><div class="request-more"><span class="form-note"><?= number_format($pendingPayments-5) ?> more pending entries</span></div><?php endif; ?>
        <div class="request-more"><a class="btn btn-primary btn-small" href="payments.php">Open Payments</a></div>
    </article>
    <article class="request-panel">
        <div class="request-panel-header"><div><h2>Awaiting Reservations</h2><span>Requests currently waiting for processing.</span></div><span class="status-pill status-pending"><?= number_format($pendingReservations) ?> pending</span></div>
        <?php if ($pendingReservationRows): ?><ul class="request-list"><?php foreach ($pendingReservationRows as $row): ?><li class="request-item"><div class="request-main"><strong><?= e($row['requester_name']) ?></strong><span><?= e($row['reservation_date']) ?> · <?= e(substr($row['start_time'],0,5)) ?>–<?= e(substr($row['end_time'],0,5)) ?> · <?= e($row['requester_type']) ?></span></div></li><?php endforeach; ?></ul><?php else: ?><div class="request-empty">No pending reservation requests.</div><?php endif; ?>
        <?php if ($pendingReservations > 5): ?><div class="request-more"><span class="form-note"><?= number_format($pendingReservations-5) ?> more pending requests</span></div><?php endif; ?>
        <div class="request-more"><a class="btn btn-primary btn-small" href="reservations.php">Open Reservations</a></div>
    </article>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
