<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_role('Clerk');
header('Content-Type: application/json; charset=utf-8');

$homeownerId = (int)($_GET['homeowner_id'] ?? 0);
$amount = (float)($_GET['amount'] ?? 0);
$paymentDate = trim((string)($_GET['payment_date'] ?? date('Y-m-d')));
if ($homeownerId < 1 || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $paymentDate)) {
    http_response_code(400);
    echo json_encode(['error'=>'Invalid preview request.']);
    exit;
}
$stmt = $pdo->prepare('SELECT homeowner_id FROM homeowners WHERE homeowner_id=:id LIMIT 1');
$stmt->execute(['id'=>$homeownerId]);
if (!$stmt->fetchColumn()) {
    http_response_code(404);
    echo json_encode(['error'=>'Homeowner not found.']);
    exit;
}
$preview = calculate_homeowner_due_date($pdo, $homeownerId, $paymentDate, max(0, $amount));
echo json_encode([
    'due_date' => $preview['due_date'],
    'credited_months' => (int)$preview['credited_months'],
    'payment_credited_months' => (int)floor(max(0, $amount) / RESIDENT_MONTHLY_DUE),
    'minimum_due' => RESIDENT_MONTHLY_DUE,
]);
