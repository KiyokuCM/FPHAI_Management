<?php
declare(strict_types=1);
require_once __DIR__ . '/config/database.php';
$id=(int)($_GET['id']??0);
$stmt=$pdo->prepare('SELECT image_path,title FROM login_slides WHERE slide_id=:id AND is_active=1 LIMIT 1');
$stmt->execute(['id'=>$id]);$row=$stmt->fetch();
if(!$row || empty($row['image_path'])){http_response_code(404);exit('Image not found.');}
$path=UPLOAD_DIR.str_replace(['..','\\'],['','/'],(string)$row['image_path']);
if(!is_file($path)){http_response_code(404);exit('Image not found.');}
$finfo=new finfo(FILEINFO_MIME_TYPE);$mime=$finfo->file($path)?:'application/octet-stream';
if(!in_array($mime,['image/jpeg','image/png','image/webp'],true)){http_response_code(415);exit('Unsupported image.');}
header('Content-Type: '.$mime);header('Content-Length: '.filesize($path));header('Cache-Control: public, max-age=3600');header('X-Content-Type-Options: nosniff');readfile($path);exit;
