<?php
require_once __DIR__ . '/config/database.php'; require_once __DIR__ . '/includes/auth.php'; require_once __DIR__ . '/includes/functions.php';
require_login(); $pageTitle='Notifications'; $error='';
if($_SERVER['REQUEST_METHOD']==='POST' && verify_csrf($_POST['csrf_token']??'')){
 $action=$_POST['action']??'';
 if($action==='read'){$id=(int)($_POST['notification_id']??0);$stmt=$pdo->prepare('UPDATE notifications SET is_read=1 WHERE notification_id=:id AND user_id=:uid');$stmt->execute(['id'=>$id,'uid'=>current_user_id()]);}
 if($action==='read_all'){$stmt=$pdo->prepare('UPDATE notifications SET is_read=1 WHERE user_id=:uid');$stmt->execute(['uid'=>current_user_id()]);}
 header('Location: notifications.php');exit;
}
$stmt=$pdo->prepare('SELECT * FROM notifications WHERE user_id=:uid ORDER BY created_at DESC,notification_id DESC LIMIT 100');$stmt->execute(['uid'=>current_user_id()]);$rows=$stmt->fetchAll();
require __DIR__.'/includes/header.php';
?>
<section class="section-card"><div class="section-heading"><div><span class="section-kicker">Updates</span><h2>Notifications</h2><p>Important updates about payments, reservations, and profile changes.</p></div><form method="POST"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="read_all"><button class="btn btn-secondary btn-small" type="submit">Mark All as Read</button></form></div>
<div class="notification-list full-notifications"><?php if($rows):foreach($rows as $n):?><article class="notification-item <?=!$n['is_read']?'is-unread':''?>"><div><div class="notification-heading"><strong><?=e($n['title'])?></strong><span class="status-pill <?=e(status_class($n['type']==='Success'?'Validated':($n['type']==='Warning'?'Pending':'Info')))?>"><?=e($n['type'])?></span></div><p><?=e($n['message'])?></p><small><?=e(date('F j, Y g:i A',strtotime($n['created_at'])))?></small></div><?php if(!$n['is_read']):?><form method="POST"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="read"><input type="hidden" name="notification_id" value="<?= (int)$n['notification_id']?>"><button class="btn btn-secondary btn-small">Mark Read</button></form><?php endif;?></article><?php endforeach;else:?><div class="request-empty">No notifications yet.</div><?php endif;?></div></section>
<?php require __DIR__.'/includes/footer.php'; ?>
