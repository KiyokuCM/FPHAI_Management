<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

$secureRequest = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ((int)($_SERVER['SERVER_PORT'] ?? 0) === 443);
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'");
if ($secureRequest) { header('Strict-Transport-Security: max-age=31536000; includeSubDomains'); }

$error = '';
$lockMessage = '';
$timeoutMessage = isset($_GET['timeout']) ? 'You were signed out automatically after 30 minutes of inactivity.' : '';
$expiredMessage = isset($_GET['expired']) ? 'This temporary password has expired. Please contact the HOA office to have the Resident account credentials regenerated.' : '';
$username = trim($_POST['username'] ?? '');
$ipAddress = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

function login_lock_seconds(int $failedAttempts): int
{
    if ($failedAttempts < 5) {
        return 0;
    }

    // 5th failure = 1 minute; each later failure doubles the lockout,
    // capped at 1 hour.
    return min(3600, 60 * (2 ** ($failedAttempts - 5)));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request token. Please refresh the login page and try again.';
    }
    $password = $_POST['password'] ?? '';

    if ($error !== '') {
        // CSRF validation failed; do not attempt authentication.
    } elseif ($username === '' || $password === '') {
        $error = 'Please enter your username and password.';
    } else {
        $attemptStmt = $pdo->prepare(
            'SELECT failed_attempts, locked_until
             FROM login_attempts
             WHERE username = :username AND ip_address = :ip_address
             LIMIT 1'
        );
        $attemptStmt->execute(['username' => $username, 'ip_address' => $ipAddress]);
        $attempt = $attemptStmt->fetch();

        if ($attempt && !empty($attempt['locked_until']) && strtotime($attempt['locked_until']) > time()) {
            $remaining = max(1, strtotime($attempt['locked_until']) - time());
            $minutes = intdiv($remaining, 60);
            $seconds = $remaining % 60;
            $lockMessage = $minutes > 0
                ? "Too many failed attempts. Please try again in {$minutes} minute(s) and {$seconds} second(s)."
                : "Too many failed attempts. Please try again in {$seconds} second(s).";
        } else {
            $stmt = $pdo->prepare(
                'SELECT user_id, username, password_hash, role, status, must_change_password, temporary_password_expires_at
                 FROM users
                 WHERE username = :username
                 LIMIT 1'
            );
            $stmt->execute(['username' => $username]);
            $user = $stmt->fetch();

            if ($user && $user['status'] === 'Active' && password_verify($password, $user['password_hash'])) {
                if ((int)$user['must_change_password'] === 1 && temporary_password_expired($user['temporary_password_expires_at'] ?? null)) {
                    $disable = $pdo->prepare('UPDATE users SET status="Inactive" WHERE user_id=:user_id AND account_source="Homeowner" AND must_change_password=1');
                    $disable->execute(['user_id'=>(int)$user['user_id']]);
                    $error = 'This temporary Resident password has expired. The account has been disabled. Please contact the HOA office to have the account regenerated.';
                } else {
                    $clear = $pdo->prepare('DELETE FROM login_attempts WHERE username = :username AND ip_address = :ip_address');
                    $clear->execute(['username' => $username, 'ip_address' => $ipAddress]);

                    // Password authentication succeeds first. If the account has 2FA enabled
                    // and a contact method is available, complete the second factor before
                    // creating the authenticated application session.
                    $twoFactor = user_two_factor_contacts($pdo, (int)$user['user_id']);
                    if (TWO_FACTOR_ENABLED && $twoFactor['enabled'] && ($twoFactor['email'] !== '' || $twoFactor['mobile'] !== '')) {
                        $challenge = create_and_send_2fa_challenge($pdo, (int)$user['user_id']);
                        if (!$challenge['sent']) {
                            $error = 'Your account has two-factor authentication enabled, but the verification code could not be delivered. Please contact the HOA office or configure the available email/SMS delivery service.';
                        } else {
                            session_regenerate_id(true);
                            $_SESSION['pending_2fa_user_id'] = (int)$user['user_id'];
                            $_SESSION['pending_2fa_username'] = $user['username'];
                            $_SESSION['pending_2fa_expires_at'] = time() + (TWO_FACTOR_CODE_MINUTES * 60);
                            $_SESSION['last_activity'] = time();
                            header('Location: two-factor.php');
                            exit;
                        }
                    } else {
                        session_regenerate_id(true);
                        $_SESSION['user_id'] = (int)$user['user_id'];
                        $_SESSION['username'] = $user['username'];
                        $_SESSION['role'] = $user['role'];
                        $_SESSION['last_activity'] = time();

                        if ((int)$user['must_change_password'] === 1) {
                            header('Location: change-password.php');
                            exit;
                        }

                        redirect_by_role();
                    }
                }
            }

            if ($error === '') {
                $failed = $attempt ? (int)$attempt['failed_attempts'] + 1 : 1;
                $lockSeconds = login_lock_seconds($failed);
                $lockedUntil = $lockSeconds > 0 ? date('Y-m-d H:i:s', time() + $lockSeconds) : null;

                $upsert = $pdo->prepare(
                    'INSERT INTO login_attempts
                        (username, ip_address, failed_attempts, locked_until, last_attempt_at)
                     VALUES (:username, :ip_address, :failed_attempts, :locked_until, NOW())
                     ON DUPLICATE KEY UPDATE
                        failed_attempts = VALUES(failed_attempts),
                        locked_until = VALUES(locked_until),
                        last_attempt_at = VALUES(last_attempt_at)'
                );
                $upsert->execute([
                    'username' => $username,
                    'ip_address' => $ipAddress,
                    'failed_attempts' => $failed,
                    'locked_until' => $lockedUntil,
                ]);

                if ($lockSeconds > 0) {
                    $minutes = intdiv($lockSeconds, 60);
                    $lockMessage = "Too many failed attempts. Login is temporarily locked for {$minutes} minute(s). The lockout increases after repeated failures.";
                } else {
                    $remainingAttempts = max(0, 5 - $failed);
                    $error = 'Invalid username or password.' . ($remainingAttempts > 0 ? " {$remainingAttempts} attempt(s) remaining before a temporary lockout." : '');
                }
            }
        }
    }
}

$loginSlides = $pdo->query('SELECT slide_id, image_path, title FROM login_slides WHERE is_active=1 ORDER BY sort_order, slide_id')->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-Content-Type-Options" content="nosniff">
    <meta http-equiv="X-Frame-Options" content="SAMEORIGIN">
    <meta name="referrer" content="strict-origin-when-cross-origin">
    <title>Login | Fairmont Park HOA</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="login-page">
    <div class="login-background" aria-hidden="true">
        <?php if ($loginSlides): ?>
            <?php foreach ($loginSlides as $index => $slide): ?>
                <div class="login-slide<?= $index === 0 ? ' is-visible' : '' ?>"><img src="login_slide.php?id=<?= (int)$slide['slide_id'] ?>" alt="<?= e($slide['title'] ?: 'FPHAI login background') ?>"></div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="login-slide is-visible login-default-slide"></div>
        <?php endif; ?>
        <div class="login-overlay"></div>
    </div>
    <main class="login-shell">
        <section class="login-card">
            <img src="assets/images/logo.png" alt="Fairmont Park Homeowners' Association logo" class="login-logo">
            <h1>Fairmont Park HOA</h1>
            <p class="login-subtitle">Centralized Management System</p>

            <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
            <?php if ($lockMessage): ?><div class="alert alert-warning"><?= e($lockMessage) ?></div><?php endif; ?>
            <?php if ($timeoutMessage): ?><div class="alert alert-warning"><?= e($timeoutMessage) ?></div><?php endif; ?>
            <?php if ($expiredMessage): ?><div class="alert alert-warning"><?= e($expiredMessage) ?></div><?php endif; ?>

            <form method="POST" action="login.php" class="form-stack" autocomplete="on">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input id="username" name="username" type="text" maxlength="100"
                           value="<?= e($username) ?>" autocomplete="username" required>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input id="password" name="password" type="password"
                           autocomplete="current-password" required>
                </div>

                <button type="submit" class="btn btn-primary btn-large">Sign In</button>
            </form>

            <p class="login-footer">Fairmont Park Homeowners' Association, Inc.</p>
            <a href="about.php" class="login-about-link">About FPHAI</a>
        </section>
    </main>
</body>
</html>
