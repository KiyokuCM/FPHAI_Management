<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

/*
 * MySQL connection.
 * Change these values to match the local XAMPP/WAMP MySQL setup.
 */
$dbHost = '127.0.0.1';
$dbName = 'fphai_management';
$dbUser = 'root';
$dbPass = '';

$dsn = "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    // Keep native prepared statements enabled. Search queries use unique placeholders.
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $dbUser, $dbPass, $options);
} catch (PDOException $exception) {
    http_response_code(500);
    exit(
        'Database connection failed. Check config/database.php and make sure MySQL is running.'
    );
}
