<?php
declare(strict_types=1);

/*
 * Application settings.
 * Update APP_URL to match the folder name used in XAMPP/WAMP.
 */
date_default_timezone_set('Asia/Manila');

define('APP_NAME', 'Fairmont Park HOA');
define('APP_FULL_NAME', "Fairmont Park Homeowners' Association, Inc.");
/*
 * Resolve the application's URL from the folder where this project is installed.
 * This keeps CSS, JavaScript, images, navigation, and uploads working when the
 * project is copied into a different XAMPP folder (for example /FPHAI_Management).
 */
if (PHP_SAPI !== 'cli' && isset($_SERVER['DOCUMENT_ROOT'], $_SERVER['SCRIPT_FILENAME'])) {
    $documentRoot = realpath($_SERVER['DOCUMENT_ROOT']);
    $projectRoot = realpath(dirname(__DIR__));
    if ($documentRoot && $projectRoot && str_starts_with($projectRoot, $documentRoot)) {
        $relative = str_replace('\\', '/', substr($projectRoot, strlen($documentRoot)));
        $relative = '/' . trim($relative, '/');
        define('APP_URL', $relative === '/' ? '' : $relative);
    } else {
        define('APP_URL', '/FPHAI_Management');
    }
} else {
    /* Default used for CLI tools/tests. */
    define('APP_URL', '/FPHAI_Management');
}

define('UPLOAD_DIR', dirname(__DIR__) . '/uploads/');
define('MAX_UPLOAD_SIZE', 10 * 1024 * 1024); // 10 MB

/* Optional two-factor delivery settings. Email uses PHP mail(); SMS uses a generic JSON webhook when configured. */
define('TWO_FACTOR_ENABLED', true);
define('TWO_FACTOR_CODE_MINUTES', 5);
define('TWO_FACTOR_MAX_ATTEMPTS', 5);
define('TWO_FACTOR_SMS_API_URL', '');
define('TWO_FACTOR_SMS_API_TOKEN', '');
define('TWO_FACTOR_SMS_SENDER', 'FPHAI');
define('TWO_FACTOR_EMAIL_FROM', 'no-reply@localhost');
/* SMTP is recommended for both localhost and a hosted domain. Leave blank to fall back to PHP mail(). */
define('TWO_FACTOR_SMTP_HOST', '');
define('TWO_FACTOR_SMTP_PORT', 587);
define('TWO_FACTOR_SMTP_USERNAME', '');
define('TWO_FACTOR_SMTP_PASSWORD', '');
define('TWO_FACTOR_SMTP_ENCRYPTION', 'tls'); // tls, ssl, or none

define('RESIDENT_MONTHLY_DUE', 400.00);
