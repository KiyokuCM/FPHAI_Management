<?php
declare(strict_types=1);
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';
require_login();
$id=(int)($_GET['id']??0);
$stmt=$pdo->prepare('SELECT p.proof_image_path,p.homeowner_id,h.user_id FROM payments p JOIN homeowners h ON h.homeowner_id=p.homeowner_id WHERE p.payment_id=:id LIMIT 1');
$stmt->execute(['id'=>$id]); $row=$stmt->fetch();
if(!$row || empty($row['proof_image_path'])) { http_response_code(404); exit('Proof of payment not found.'); }
if(current_role()==='Resident' && (int)$row['user_id']!==current_user_id()) { http_response_code(403); exit('403 Forbidden'); }
if(!in_array(current_role(),['Administrator','Clerk','Resident'],true)) { http_response_code(403); exit('403 Forbidden'); }
$path=UPLOAD_DIR.$row['proof_image_path']; if(!is_file($path)){http_response_code(404);exit('Proof image file not found.');}
$finfo=new finfo(FILEINFO_MIME_TYPE); $mime=$finfo->file($path); if(!in_array($mime,['image/jpeg','image/png','image/webp'],true)){http_response_code(415);exit('Unsupported proof image.');}
header('Content-Type: '.$mime); header('Content-Length: '.filesize($path)); header('X-Content-Type-Options: nosniff'); header('Content-Disposition: inline; filename="payment-proof-'.$id.'.'.pathinfo($path,PATHINFO_EXTENSION).'"'); readfile($path);
